#include <QTime>
#include <QDebug>
#include <QImage>
#include <QtGui>
#include <QSignalSpy>

#include "clsAesys.h"
#include "global.h"

QT_USE_NAMESPACE

clsAesys::clsAesys(QObject *parent) : QThread(parent), waitTimeout(0), quit(false)
{
    InitDevice = true;

    RxBuffer = QByteArray(256, 0);

    Enable485 = new TogglePin("rs485_ext_txen");

    Enable485->setValue(0);
}

/*********************************************************/
void clsAesys::Config(QList<clsDisplayAesys *> *Pannelli)
/*********************************************************/
{
    this->Pannelli = Pannelli;
}

/*********************************************************/
clsAesys::~clsAesys()
/*********************************************************/
{
    mutex.lock();
    quit = true;
    mutex.unlock();
    wait();
}

void clsAesys::startSlave(const QString &portName, int Speed)
{
    QMutexLocker locker(&mutex);

    this->portName = portName;
    this->waitTimeout = 300;        //Era 100
    this->Speed = Speed;

    if (!isRunning())
        start();
}

void clsAesys::StopThread()
{
    mutex.lock();
    quit = true;
    mutex.unlock();
}

void clsAesys::run()
{
    InitDevice = true;

    mutex.lock();

    int currentWaitTimeout = waitTimeout;

    mutex.unlock();

    Rs485 = &serial;

    while (!quit)
    {
        if (InitDevice)
        {
            qDebug() << "Init Device " << portName;

            serial.close();

            serial.setPortName(portName);
            serial.setBaudRate(Speed);
            serial.setDataBits(QSerialPort::Data8);
            serial.setParity(QSerialPort::NoParity);

            if (!serial.open(QIODevice::ReadWrite))
            {
                QString Err = QString("Can't open %1, error code %2").arg(portName).arg(serial.error());
                emit error(Err);
                return;
            }
            else
                InitDevice = false;
        }

        if (!InitDevice)
        {
            LoopPannelli();

            qSleep(50);
        }
    }

    serial.close();
}

/******************************************************************/
void clsAesys::LoopPannelli()
/******************************************************************/
{
    QSignalSpy Spy ( this, SIGNAL(EndTransmission()));

    QByteArray TxBuf;

    for (int k=0; k<Pannelli->count(); k++)
    {
        clsDisplayAesys *Pan = Pannelli->at(k);

        if (Pan->FL_Refresh)
        {
            QString Num = Pan->Num;

            if (Pan->NumFore != "#FFF")
            {
                if (!Num.contains("\\CR"))
                    Num = "\\CR" + Pan->NumFore.mid(1) + Num;
            }

            switch (Pan->nZone)
            {
                case 1:
                    TxBuf = BuildMessage( Pan->Adr, "VIS", Num, "", "", "", "", "");
                    break;
                case 2:
                    TxBuf = BuildMessage( Pan->Adr, "VIS", "", Pan->Sup, Pan->Inf, "", "", "");
                    break;
                case 3:
                    TxBuf = BuildMessage( Pan->Adr, "VIS", Num, Pan->Sup, Pan->Inf, "", "", "");
                    break;
            }

            qDebug() << Pan->Adr << "N:" << Num << " S:" << Pan->Sup << " I:" << Pan->Inf;

            int TxTime = (TxBuf.length() * 1150) / 1000;

            qDebug() << "TxTime: " << TxTime << " - " << TxBuf;

            Enable485->setValue(1);

            Rs485->write( TxBuf);

            Rs485->waitForBytesWritten(200);

            Spy.wait(TxTime);

            Enable485->setValue(0);

            Rs485->waitForReadyRead(1000);

            RxBuffer = Rs485->readAll();

            if (RxBuffer.count() >= 15)
            {
                qDebug() << "AESYS -> " << RxBuffer;

                QString Res = RxBuffer.mid( 2, 7);

                if (Res == "ACK0001")
                {
                    Pan->FL_Refresh = false;
                    Pan->Status = eStatus::Up;
                }
                else
                    Pan->Status = eStatus::Down;
            }
            else
                Pan->Status = eStatus::Down;

            qSleep(2000);
        }
    }

}
/******************************************************************/
void clsAesys::Automa(QByteArray Buffer)
/******************************************************************/
{
    static uint Ptr = 0;

    for(int i=0; i<Buffer.count(); i++)
    {
        quint8 Rx = Buffer.at(i);

        if (Rx==0x0A)
        {
            // emit Signal
            Ptr = 0;
        }
        else
        {
            if (Ptr < RxBuffer.length())
                RxBuffer[Ptr++] = Rx;
            else
                Ptr = 0;
        }
    }
}
/******************************************************************/
void clsAesys::Send_Command( QString Cmd, QString Param, int TimeOut = 0)
/******************************************************************/
{
    QSignalSpy Spy ( this, SIGNAL(Success()));

    if (TimeOut > 0)
        Rs485->readAll();

    qDebug() << "Send Command: " << Cmd;

    Cmd += "\n";

    Rs485->write( Cmd.toLocal8Bit(), Cmd.length() );

    bool Ok = Spy.wait(TimeOut);

    if (!Ok)
        qDebug() << "AESYS ERROR: Nessuna risposta";

}

/******************************************************************/
void clsAesys::ProcessCommand(QString Command)
/******************************************************************/
{
    qDebug() << "CUSTOM:" << Command;

    emit Success();
}

/**************************************/
void clsAesys::qSleep(int ms)
/**************************************/
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000 * 1000 };

    nanosleep(&ts, nullptr);
}

/***********************************************/
QByteArray clsAesys::CopyTo(QString Source, QByteArray Buffer, int Ptr)
/***********************************************/
{
    QByteArray Temp = Source.toLocal8Bit();

    for (int j=0; j<Temp.length(); j++)
        Buffer[Ptr+j] = Temp.at(j);

    return Buffer;
}
/***********************************************/
QByteArray clsAesys::BuildMessage(QString Dest, QString OpCode, QString Num, QString Sup, QString Inf, QString FC1, QString FC2, QString FC3)
/***********************************************/
{
    QByteArray resultByteArray;

    int bufferLength = 9;

    try
    {
        Num = Num.trimmed();
        Sup = Sup.trimmed();
        Inf = Inf.trimmed();

        if (Num.startsWith(" ")) Num = "!" + Num;
        if (Num.endsWith(" ")) Num = Num + "!";

        if (Sup.startsWith(" ")) Sup = "!" + Sup;
        if (Sup.endsWith(" ")) Sup = Sup + "!";

        if (Inf.startsWith(" ")) Inf = "!" + Inf;
        if (Inf.endsWith(" ")) Inf = Inf + "!";

        int LenN = Num.length();
        int LenS = Sup.length();
        int LenI = Inf.length();


        if (OpCode == "VIS")
        {
            resultByteArray[bufferLength] = 0x00;       //Activation Code 0=Immediate

            bufferLength += 1;
        }

        if (LenN > 0)
        {
            resultByteArray = CopyTo(Num, resultByteArray, bufferLength );
            bufferLength += LenN;
            resultByteArray[bufferLength] = 0x0B;
            bufferLength += 1;
        }

        if (LenS > 0 && LenI > 0)
        {
            resultByteArray = CopyTo(Sup, resultByteArray, bufferLength);
            bufferLength += LenS;

            resultByteArray[bufferLength] = 0x0A;
            bufferLength += 1;

            resultByteArray = CopyTo(Inf, resultByteArray, bufferLength);
            bufferLength += LenI;

            resultByteArray[bufferLength] = 0x0A;
            bufferLength += 1;
        }
        else
        {
            if (LenS > 0)
            {
                resultByteArray = CopyTo(Sup, resultByteArray, bufferLength);
                bufferLength += LenS;

                resultByteArray[bufferLength] = 0x0A;
                bufferLength += 1;
            }

            if (LenI > 0)
            {
                resultByteArray = CopyTo(Inf, resultByteArray, bufferLength);
                bufferLength += LenI;

                resultByteArray[bufferLength] = 0x0A;
                bufferLength += 1;
            }
        }

        resultByteArray[0] = STX;
        resultByteArray = CopyTo(Dest  , resultByteArray, 1);
        resultByteArray = CopyTo(OpCode, resultByteArray, 2);

        int DataLen = bufferLength - 9;

        QString Size = (QString("%1").arg(DataLen, 4, 16, QChar('0'))).toUpper();

        resultByteArray = CopyTo(Size, resultByteArray, 5);

        resultByteArray[bufferLength++] = ETX;

        Size = "ZZZZ";

        resultByteArray = CopyTo(Size, resultByteArray, bufferLength);

        bufferLength += Size.length();

        for (int j = 0; j < bufferLength; j++)
        {
            if (resultByteArray.at(j) == '!')
                resultByteArray[j] = 0xB1;
        }
    }
    catch (...)
    {
        //Logger.Error(this, $"BuilMessage error: {ex.Message}");
    }

    return resultByteArray;
}


#if false

if (serial.waitForReadyRead(currentWaitTimeout))
{
    RxBuffer = serial.readAll();

    qDebug() << "EASYS: Ricevuti " << RxBuffer.count() << " byte";

    for (int j=0; j<RxBuffer.count(); j++)
        qDebug() << "-> " << QString::number(RxBuffer[j], 16);

    emit Success();
}

#endif
