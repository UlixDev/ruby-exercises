// myserver.h
// Moved

#ifndef MYSERVER_H
#define MYSERVER_H

#include <QTcpServer>

#include "tcpclientman.h"

class TcpServer : public QTcpServer
{
    Q_OBJECT

public:
    explicit TcpServer(QObject *parent = 0);
    void startServer();

signals:
    void CommandReceived( int ClientID, QByteArray Message );
    void ForwardMessage ( int ClientID, QString Data);

public slots:
    void MessageReceived(int ClientID, QByteArray Message );
    void SendMessage    (int ClientID, QByteArray Data);

protected:
    void incomingConnection(qintptr socketDescriptor);

private:

};

#endif // MYSERVER_H
