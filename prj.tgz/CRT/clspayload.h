// moved to PayloadDispatcher
// other classes Moved to protocols folder
#ifndef CLSPAYLOAD_H
#define CLSPAYLOAD_H

#include <QThread>
#include <QDateTime>
#include <QMutex>
#include "dbmanager.h"
#include "clsVTec.h"

class TrackInfo;
class clsDevice;
class clsDiagnostica;

class clsPayload : public QThread
{

public:

    explicit clsPayload(QString s);
    void run();

    QDateTime LastNetSend;

    QList<clsVTec *> *VTecDevice;

private:

    QMutex *m_mx;
    bool Spooler();
    DBManager *DBase;
    QString name;

public slots:

    bool PushMessage(QString Command, TrackInfo Data);
    bool PushMessage(QString Command, QString   Data);

};

class TrackInfo
{
public:

    QDateTime Time;
    QString Imei    = "";
    QString Mezzo   = "";
    QString DutyID  = "";
    QString TripID  = "";
    QString StopID  = "";
    QString Event   = "";
    QString Cond    = "";
    QString Fore_Stop = "";

    double  Lat   = 0;
    double  Lng   = 0;
    double  Speed = 0;
    double  Ang   = 0;

    int     Odo   = 0;
    int     Fore_Time = 0;
    int     Rit   = 0;
    int     Sosta = 0;
    int     PassIN  = 0;
    int     PassOUT = 0;
    int     Batt  = 0;
    int     Motore = 0;

    bool    Porte = false;
    bool    Sinc  = false;
};

class clsDevice
{
public:

    QString Code;
    QString Id;
    int Status;
};


class clsDiagnostica
{
public:

    QString VehicleId;
    float   Lat;
    float   Lng;
    float   Heading;
    float   Speed;
    QDateTime TimeStamp;
    QString TripId;
    QString StopId;
    QString AgencyId;
    clsDevice Devices[1];
};

Q_DECLARE_METATYPE(TrackInfo)
Q_DECLARE_METATYPE(clsDiagnostica)
Q_DECLARE_METATYPE(clsDevice)


#endif // CLSPAYLOAD_H
