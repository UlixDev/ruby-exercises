#include "clshella.h"
#include "global.h"
#include "logger.h"

clsHella::clsHella()
{

}

/*****************************************************************/
void clsHella::SetHellaGroup(QString IP1, QString IP2, QString IP3)
/*****************************************************************/
{
    Lista = new QMap<QString, HellaInfo *>();

    if (IP1.length() > 0) Lista->insert(IP1, new HellaInfo(IP1, 1));
    if (IP2.length() > 0) Lista->insert(IP2, new HellaInfo(IP2, 2));
    if (IP3.length() > 0) Lista->insert(IP3, new HellaInfo(IP3, 3));

    HellaPort = 10076;

    if (Lista->keys().count() > 0)
    {
        DBase = new DBManager( this, "DB_Hella");

        DBase->Open();

        PaxOft = DBase->GetParam("PaxOft", 0);

        Socket = new QUdpSocket(this);

        Socket->bind(QHostAddress::Any, HellaPort);

        connect(Socket, SIGNAL(readyRead()), this, SLOT(Receiver()));
    }
}

/*****************************************************************/
void clsHella::Receiver(void)
/*****************************************************************/
{
    QByteArray Buffer;

    Buffer.resize(Socket->pendingDatagramSize());

    QHostAddress Sender;

    quint16 SenderPort;

    Socket->readDatagram(Buffer.data(), Buffer.size(), &Sender, &SenderPort);

    //qDebug() << "Rx from " << Sender.toString() << " Data: " << Buffer;

    Pending = true;
}
/*****************************************************************/
void clsHella::run()
/*****************************************************************/
{
    QDateTime OpenDoorTime = QDateTime::fromMSecsSinceEpoch(0);

    eDoorStatus StatoPorte;
    eDoorStatus oStatoPorte = eDoorStatus::Unknow;

    int TWait = 5000;
    int PSal;
    int PDis;
    int oTot = 0;

    while (Global::Running)
    {
        StatoPorte = eDoorStatus::Unknow;

        for (int j=0; j < Lista->count(); j++)
        {
            HellaInfo *Hella = Lista->values().at(j);

            bool Ok = SendMessage(Hella->IP, QString("%1%2").arg(READ_DOOR).arg("1"));

            Hella->Stato = Ok;

            if (Ok)
            {
                if (Hella->Resp.startsWith(READ_DOOR) && Hella->Resp.length() == READ_DOOR.length() + 1)
                {
                    Hella->StatoPorte = Hella->Resp.mid(READ_DOOR.length(), 1);

                    if (Hella->StatoPorte == "0")
                        StatoPorte = eDoorStatus::Opened;
                    else if (Hella->StatoPorte == "1")
                        StatoPorte = eDoorStatus::Closed;
                    else
                        StatoPorte = eDoorStatus::Unknow;
                }
            }
        }

        PSal = 0;
        PDis = 0;

        for (int j=0; j < Lista->count(); j++)
        {
            HellaInfo *Hella = Lista->values().at(j);

            bool Ok = SendMessage(Hella->IP, QString("%1%2").arg(READ_COUNTER).arg("1"));

            Hella->Stato = Ok;

            if (Ok)
            {
                if (Hella->Resp.startsWith("VDV2b") && Hella->Resp.length() == 5 + 16)
                {
                    QString TempS = Hella->Resp.mid(5, 8);
                    QString TempD = Hella->Resp.mid(5 + 8, 8);

                    TempS = TempS.replace(":", "A");
                    TempS = TempS.replace(";", "B");
                    TempS = TempS.replace("<", "C");
                    TempS = TempS.replace("=", "D");
                    TempS = TempS.replace(">", "E");
                    TempS = TempS.replace("?", "F");

                    Hella->PassIn = TempS.toInt(nullptr, 16);

                    TempD = TempD.replace(":", "A");
                    TempD = TempD.replace(";", "B");
                    TempD = TempD.replace("<", "C");
                    TempD = TempD.replace("=", "D");
                    TempD = TempD.replace(">", "E");
                    TempD = TempD.replace("?", "F");

                    Hella->PassOut = TempD.toInt(nullptr, 16);

                    PSal += Hella->PassIn;
                    PDis += Hella->PassOut;
                }
            }
        }

        FL_SalDis = true;

        if (PDis > (PSal + PaxOft))
        {
            PaxOft += (PDis - PSal);

            Logger::Info("HELLA", QString("CONTAPAX: Saliti=%1 Discesi=%2 Correttore=%3").arg(PSal).arg(PDis).arg(PaxOft));

            DBase->WriteParam("PaxOft", PaxOft);
        }

        Global::PeopleIN  = PSal + PaxOft;
        Global::PeopleOUT = PDis;

        int Tot = (Global::PeopleIN - Global::PeopleOUT);

        if (Tot != oTot)
        {
            Global::ABordo += (Tot - oTot);

            oTot = Tot;

            if (Global::ABordo < 0)
                Global::ABordo = 0;
        }

        if (oStatoPorte != StatoPorte)
        {
            if (StatoPorte == eDoorStatus::Opened)
            {
                Logger::Info("HELLA", "Apertura porte");

                OpenDoorTime = QDateTime::currentDateTime();
            }
            else if (StatoPorte == eDoorStatus::Closed)
            {
                Logger::Info("HELLA", "Chiusura porte");

                //if (OpenDoorTime != QDateTime::fromSecsSinceEpoch(0) )
                //    Global::TempoAperturaPorte = (int)DateTime.Now.Subtract(OpenDoorTime).TotalSeconds;
            }

            emit DoorStatusChanged(StatoPorte);

            oStatoPorte = StatoPorte;
        }

        /********************************
         * DIAGNOSTICA
         ********************************/

        bool Down = false;

        for (int j=0; j < Lista->count(); j++)
        {
            HellaInfo *Hella = Lista->values().at(j);

            if (Hella->Stato != Hella->oStato)
            {
                Hella->oStato = Hella->Stato;

                qDebug() << "HELLA: " << Hella->DeviceID << " Status: " << Hella->Stato;

                emit CpxStatusChanged( DeviceType, Hella->DeviceID, Hella->Stato );
            }

            if (Hella->Stato == 0)
                Down = true;
        }

        Global::DoorStatus = !Down;

        QThread::msleep(TWait);
    }

    Logger::Info("HELLA", "EXIT Thread Hella");
}

/*****************************************************************/
bool clsHella::SendMessage(QString Key, QString Command)
/*****************************************************************/
{
    bool Ret = false;

    int Timeout = 3000;

    HellaInfo *Hella = Lista->value(Key);

    Pending = false;

    QByteArray Data = Command.toLocal8Bit();

    Socket->writeDatagram(Data, QHostAddress(Hella->IP), HellaPort);

    QDateTime T0 = QDateTime::currentDateTime();

    Hella->LastTx = T0;

    while ( T0.msecsTo(QDateTime::currentDateTime()) < Timeout )
    {
        if (Pending)
            break;
        else
            QThread::msleep(10);

    };

    Ret = Pending;

    if (!Pending)
        Logger::Info("HELLA", "Nessuna risposta dall' IP " + Hella->IP);

    return Ret;
}


