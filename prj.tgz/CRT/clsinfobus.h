//moved to forms/ui renamed in TransitInformations
#ifndef CLSINFOBUS_H
#define CLSINFOBUS_H

#include <QWidget>

namespace Ui {
class clsInfoBus;
}

class clsInfoBus : public QWidget
{
    Q_OBJECT

public:
    explicit clsInfoBus(QWidget *parent = nullptr);
    ~clsInfoBus();

private:
    Ui::clsInfoBus *ui;
};

#endif // CLSINFOBUS_H
