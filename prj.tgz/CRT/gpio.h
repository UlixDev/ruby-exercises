// moved
#ifndef GPIO_H
#define GPIO_H

#include <QString>

class GPIO
{
protected:
    /** Identificativo GPIO */
    QString pinName;

private:
    /** Pin attivo */
    bool exported;

public:
    /**
     * @brief Costruttore: in di I/O
     */
    GPIO(const QString &pinName);

    /**
     * @brief Distruttore: rimuove esportazione pin di I/O
     */
    ~GPIO();

    /**
     * @brief Imposta lo stato del pin
     * @return -1 in caso di errore
     */
    int  setValue       (int value);
    int  setBrightness  (int value);
    void resetBrightness();
};

#endif // GPIO_H
