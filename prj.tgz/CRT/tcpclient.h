//moved
#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QObject>
#include <QThread>
#include <QTcpSocket>
#include <QHostAddress>

class TcpClient : public QThread
{
    Q_OBJECT

public:

    explicit TcpClient(QObject *parent = nullptr);

     ~TcpClient();

    void run() Q_DECL_OVERRIDE;
    void StartThread();
    void StopThread();
    bool Quit;

    void StartConnection(QString IP, int Port);
    void qSleep         (int ms);

    QAbstractSocket::SocketState GetState();

    QByteArray RxBuffer;
    QByteArray EuroBuf;

private:

    QTcpSocket *Socket = nullptr;
    QString    RemoteIP;
    int        RemotePort;

    int        EuroPtr = 0;
    int        EuroRxWait;
    bool       EuroPending = false;

private slots:

    void onReadyRead    ();
    void onDisconnected ();
    void onConnected    ();
    void onError        (QAbstractSocket::SocketError error);
    void Reconnect  ();

public slots:

    int SendMessage(QString Message, int Len, int Timeout);
    int Eurotech_SendMessage(QString Message, int Len, int RxLen, int Timeout);

signals:

    void Signal_DataReceived    (QByteArray Rx);
    void Signal_EuroDataReceived();

};

#endif // TCPCLIENT_H
