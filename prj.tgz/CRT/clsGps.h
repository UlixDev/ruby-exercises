// Moved
#ifndef CLSGPS_H
#define CLSGPS_H

#include <QMutex>
#include <QThread>
#include <QTime>
#include <QUdpSocket>
#include "Positioning/qgeocoordinate.h"

class clsGps : public QThread
{
    Q_OBJECT

public:
    explicit clsGps(QObject *parent = nullptr);
    ~clsGps();

    void startSlave(const QString &portName, int waitTimeout);
    void run() Q_DECL_OVERRIDE;
    void StopThread();

    QDateTime LastGpsRx;

    void StartUDPReceiver();

    QDateTime GpsTime;
    QDateTime SatelliteTime;

    double pDop;
    double hDop;
    double vDop;

    double Kmh;
    double Alt;
    double Lat;
    double Lng;
    double Course;
    int   nSat;
    const float KMHPerKnot = 1.6;

    const quint16 Port = 8500;

private slots:

    void on_UDPReadyRead();

signals:

    void request    (const QString &s);
    void error      (const QString &s);
    void timeout    (const QString &s);
    void OnLocation (QGeoCoordinate Geo);

private:

    QString portName;
    QString response;
    int waitTimeout;
    QMutex mutex;
    bool   quit;
    QTime  T0;
    QTime  LastUpdate;
    QGeoCoordinate Geo;

    static const int BufSize = 256;

    void    Gps_Automa  (QByteArray Data);
    bool    Analize     (QString nMea);
    bool    IsValid     (QString sentence);
    QString GetChecksum (QString sentence);
    float   Normalize   (float Polar);

    bool ParseGPVTG(QString Sentence);
    bool ParseGPRMC(QString Sentence);
    bool ParseGPGGA(QString Sentence);
    bool ParseGPGSA(QString sentence);

    bool   RxErr  = false;
    int    RxPtr  = 0;

    QByteArray RxBuffer;

    /************************/

    QUdpSocket *Socket = nullptr;

};

#endif // CLSGPS_H
