#include "global.h"

QString     Global::MqttUser        = "Riccardo";
QString     Global::MqttPsw         = "bigo+2019";
QString     Global::MqttServer      = "mqtt.bigosolutions.it";
int         Global::MqttPort        = 1883;

QString Global::PortalBigo      = PORTAL_BIGO;
QString Global::PortalApiKey    = APIKEY_BIGO;

QString Global::BigoPoint   = "http://dev.bigosolutions.it";
QString Global::EndPoint    = "https://web.bigosolutions.it/start_ws/";
QString Global::ApiKey      = "";
QString Global::Imei        = "1234567890";
QString Global::Conducente  = "";
QString Global::Mezzo       = "";
QString Global::StopID      = "";
QString Global::DutyID      = "";
QString Global::TripID      = "";
QString Global::LineaSN     = "";
QString Global::Fore_Stop   = "";
QString Global::PanelCode   = "";
QString Global::VTecStatus  = "";
QString Global::ElmecStatus = "";
QString Global::AesysStatus = "";
QString Global::Versione    = "1.23";

int     Global::IDAgenzia   = 0;
int     Global::nAgenzia    = 0;
QString Global::Agenzia     = "";
QString Global::Rev         = "1.0";

bool  Global::EnableSimulatore  = false;
bool  Global::FL_FineCorsa      = false;
bool  Global::FL_Change         = false;
bool  Global::Door              = false;
bool  Global::Running           = false;
bool  Global::VTecMaster        = false;
bool  Global::EnableVTec1       = true;
bool  Global::EnableVTec2       = true;
bool  Global::SpegniLCD         = true;


bool  Global::GpsStatus         = false;
bool  Global::NetStatus         = false;
bool  Global::DoorStatus        = false;
bool  Global::PanelStatus       = false;

float Global::IntornoDeposito    = 30;
float Global::Distanza_Capolinea = 100;
float Global::Distanza_Palina    = 30;
float Global::DistanzaDaFermata  = 0;
float Global::SogliaSpeed        = 5;

int Global::TempoAperturaPorte = 0;

int Global::OutOfSyncTime    = 300;
int Global::RitardoCorsa     = 0;
int Global::Seconds_per_Lost = 300;
int Global::Odometro         = 0;
int Global::PeopleIN         = 0;
int Global::PeopleOUT        = 0;
int Global::ABordo           = 0;
int Global::Fore_Time        = 0;
int Global::Lumin            = 50;

int  Global::TimeOffset       = 0;
bool Global::FL_Utc           = false;

QString Global::ContaPaxModel = "";
int     Global::ContaPaxPort  = 0;

int     Global::XiboStatus    = 1;
QString Global::XiboIP        = "192.168.1.200";


QGeoCoordinate Global::Proiezione;
QGeoCoordinate Global::Posizione;

QMutex Global::LK_ClearTurni;

QList<QString> *Global::TurniFatti = new QList<QString>();

QGeoCoordinate Proiezione;

Global::Global()
{
}

QDateTime Global::CurrentTime(void)
{
    if (Global::FL_Utc)
        return QDateTime::currentDateTime().addSecs(Global::TimeOffset);
    else
        return QDateTime::currentDateTime();
}
