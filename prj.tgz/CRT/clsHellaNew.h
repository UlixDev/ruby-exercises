//moved
#ifndef CLSHELLANEW_H
#define CLSHELLANEW_H

#include <QObject>
#include <QDateTime>
#include <QUdpSocket>
#include <QThread>
#include <QList>
#include "global.h"
#include "dbmanager.h"

class HellaInfo;

class clsHellaNew : public QThread
{
    Q_OBJECT

public:

    explicit clsHellaNew();

    void     Config                 (QList<QString> Pax, int Port);
    void     SendMessageBroadcast   (QString Command);

    QDateTime LastHellaRes;

    eDoorStatus StatoPorte = eDoorStatus::Unknow;

    eDoorStatus oStatoPorte = eDoorStatus::Unknow;

    QMap<QString, HellaInfo *> *Lista = nullptr;

    eStatus  Status = eStatus::Init;

    eStatus oStatus = eStatus::Init;

    void     run();

private:

    QUdpSocket *Socket = nullptr;

    //int HellaPort= 10076;
    int HellaPort= 5400;

    const QString READ_COUNTER = "VDV2b";
    const QString READ_DOOR    = "VDV2bW";
    bool  Flip = false;
    int  oTot      = 0;
    int  PaxOft    = 0;
    bool FL_SalDis = false;
    bool Pending   = false;



    QString DeviceType = "CPX";

    DBManager *DBase;

    void qSleep(int ms);

public slots:
    void ReadyRead(void);

signals:

    void DoorStatusChanged( int DoorStatus );
    void CpxStatusChanged ( int Status );
    void PeopleCountChange( int PassIn, int PassOut, int ABordo );

};

class HellaInfo
{
public:


    int       ID;
    int       PassIn;
    int       PassOut;
    QString   IP;
    QString   Resp;
    QString   DeviceID;
    int       StatoPorte;
    QDateTime LastRx;
    QDateTime LastTx;
    bool      Pending = false;
    eStatus   Stato;

    HellaInfo(QString IP, int ID)
    {
        this->IP = IP;
        this->ID = ID;
        PassIn   = 0;
        PassOut  = 0;
        LastRx   = QDateTime::fromMSecsSinceEpoch(0);
        LastTx   = QDateTime::fromMSecsSinceEpoch(0);
        DeviceID = QString("CPX_%1").arg(ID);
    }
};

#endif // CLSHELLANEW_H
