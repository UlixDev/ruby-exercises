//moved
#ifndef LOGGER_H
#define LOGGER_H

#include <QString>

class Logger
{

public:

    Logger();

    static void Info    (QString Cat, QString Message);
    static void Purge   (int nDay);


    static QString  RemoteLogIP;
    static int      RemoteLogPort;
    static QString  Root;
    static bool     EnUDP;
};

#endif // LOGGER_H
