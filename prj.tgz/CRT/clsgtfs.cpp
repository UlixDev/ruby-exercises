#include "clsgtfs.h"
#include "clswebservice.h"
#include "json.h"
#include "dbmanager.h"
#include "global.h"

#include <QVariantMap>
#include <QFile>
#include <QMap>
#include <QSqlError>
#include <QCoreApplication>

#define READ_ALL    1

using QtJson::JsonObject;
using QtJson::JsonArray;

clsGtfs::clsGtfs()
{
    DBase = new DBManager( 0, "DB_Gtfs");

    DBase->Open();
}

bool clsGtfs::Read_Gtfs(bool FL_New, QString Agenzia)
{
    bool Ok = false;
    bool Down;
    GRepo *MyRepo;
    GRepo *Repo;

    Busy = true;

    this->Agenzia = Agenzia;

    if (FL_New)
        DBase->ExecuteQuery("DELETE From Repo");

    Load_Repo();

    Ok = Read_Repo(Agenzia, 1);

    if (Ok)
    {
        Ok = (GTFS_Repo->count() > 0);
    }

    if (Ok)
    {
        /**************************
         * PULIZIA DATABASE
         **************************/

        foreach ( QString Key, GTFS_MyRepo->keys() )
        {
            if (Key.startsWith("SH_"))
            {
                MyRepo = GTFS_MyRepo->value(Key);
                Repo   = GTFS_Repo  ->value(Key);

                if (Repo == nullptr)
                {
                    DBase->ExecuteQuery( QString("DELETE FROM Shape WHERE ShapeID='%1'").arg(Key.mid(3)) );

                    MyRepo->Action = GRepo::Delete;
                }
            }
        }

        /**************************
         * LETTURA CARTELLI
         **************************/

        MyRepo = GTFS_MyRepo->value("CARTELLI");

        Repo   = GTFS_Repo->value("CARTELLI");

        Down = ( Repo != nullptr && MyRepo == nullptr);

        if (!Down)
        {
            if (Repo != nullptr)
                Down = Repo->LastUpdate.secsTo(MyRepo->LastUpdate) != 0;
        }
        else
        {
            GTFS_MyRepo->insert("CARTELLI", Repo);

            MyRepo = GTFS_MyRepo->value("CARTELLI");
        }

        if (Down)
        {

#ifdef CARTELLI_OLDMODE

            Ok = Read_Cartelli(Agenzia);

            if (Ok)
            {
                Ok = Save_Cartelli();
#else
            Ok = Read_Velette(Agenzia, 0);

            if (Ok)
            {
                Ok = Save_Velette();
#endif
                if (Ok)
                {
                    MyRepo->LastUpdate = Repo->LastUpdate;
                    MyRepo->Action = GRepo::Update;
                }
            }
        }

#ifdef ENABLE_GTFS

        /**************************
         * LETTURA STOPS
         **************************/

        MyRepo = GTFS_MyRepo->value("STOPS");

        Repo   = GTFS_Repo->value("STOPS");

        Down = (MyRepo == nullptr);

        if (!Down)
        {
            if (Repo != nullptr)
                Down = Repo->LastUpdate.secsTo(MyRepo->LastUpdate) != 0;
        }
        else
        {
            GTFS_MyRepo->insert("STOPS", Repo);

            MyRepo = GTFS_MyRepo->value("STOPS");
        }

        if (Down)
        {
            Ok = Read_Stops(Agenzia);

            if (Ok)
            {
                Ok = Save_Stops();

                if (Ok)
                {
                    MyRepo->LastUpdate = Repo->LastUpdate;
                    MyRepo->Action = GRepo::Update;
                }
            }
        }

        /**************************
         * LETTURA TRIPS
         **************************/

        MyRepo = GTFS_MyRepo->value("TRIPS");

        Repo   = GTFS_Repo->value("TRIPS");

        Down = (MyRepo == nullptr);

        if (!Down)
        {
            if (Repo != nullptr)
                Down = Repo->LastUpdate.secsTo(MyRepo->LastUpdate) != 0;
        }
        else
        {
            GTFS_MyRepo->insert("TRIPS", Repo);

            MyRepo = GTFS_MyRepo->value("TRIPS");
        }

        if (Down)
        {
            Ok = Read_Trips(Agenzia);

            if (Ok)
            {
                Ok = Save_Trips();

                if (Ok)
                {
                    MyRepo->LastUpdate = Repo->LastUpdate;
                    MyRepo->Action = GRepo::Update;
                }
            }
        }

        /**************************
         * LETTURA STOPTIMES
         **************************/

        Repo   = GTFS_Repo->value("STOPSTIME");

        if (Repo == nullptr)
        {
            Repo   = GTFS_Repo->value  ("STOPTIMES");
            MyRepo = GTFS_MyRepo->value("STOPTIMES");
        }
        else
            MyRepo = GTFS_MyRepo->value("STOPSTIME");

        Down = (MyRepo == nullptr);

        if (!Down)
        {
            if (Repo != nullptr)
                Down = Repo->LastUpdate.secsTo(MyRepo->LastUpdate) != 0;
        }
        else
        {
            GTFS_MyRepo->insert(Repo->Object, Repo);

            MyRepo = GTFS_MyRepo->value(Repo->Object);
        }

        if (Down)
        {
            Ok = Read_StopsTime(Agenzia);

            if (Ok)
            {
                Ok = Save_StopsTime();

                if (Ok)
                {
                    MyRepo->LastUpdate = Repo->LastUpdate;
                    MyRepo->Action = GRepo::Update;
                }
            }
        }

        /**************************
         * LETTURA ROUTES
         **************************/

        MyRepo = GTFS_MyRepo->value("ROUTES");

        Repo   = GTFS_Repo->value("ROUTES");

        Down = (MyRepo == nullptr);

        if (!Down)
        {
            if (Repo != nullptr)
                Down = Repo->LastUpdate.secsTo(MyRepo->LastUpdate) != 0;
        }
        else
        {
            GTFS_MyRepo->insert("ROUTES", Repo);

            MyRepo = GTFS_MyRepo->value("ROUTES");
        }

        if (Down)
        {
            Ok = Read_Routes(Agenzia);

            if (Ok)
            {
                Ok = Save_Routes();

                if (Ok)
                {
                    MyRepo->LastUpdate = Repo->LastUpdate;
                    MyRepo->Action = GRepo::Update;
                }
            }
        }

        /**************************
         * LETTURA SHAPE
         **************************/

        foreach ( QString Key, GTFS_Repo->keys() )
        {
            if (Key.startsWith("SH_"))
            {
                MyRepo = GTFS_MyRepo->value(Key);
                Repo   = GTFS_Repo  ->value(Key);

                Down = (MyRepo == nullptr);

                if (!Down)
                    Down = Repo->LastUpdate.secsTo(MyRepo->LastUpdate) != 0;
                else
                {
                    GTFS_MyRepo->insert(Key, Repo);

                    MyRepo = GTFS_MyRepo->value(Key);
                }

                if (Down)
                {
                    Ok = Read_Shapes(false, Key.mid(3), Agenzia );

                    if (Ok)
                    {
                        Ok = Save_Shape( Key.mid(3) );

                        if (Ok)
                        {
                            MyRepo->LastUpdate = Repo->LastUpdate;
                            MyRepo->Action = GRepo::Update;
                        }
                    }
                }
            }
        }

        /**************************
         * LETTURA TURNI
         **************************/

        Ok = Read_Turni(Agenzia);

        if (Ok)
            Save_Turni();

#endif

        /**************************
         * AGGIORNAMENTO REPOSITORY
         **************************/

        foreach ( QString Key, GTFS_MyRepo->keys() )
        {
            MyRepo = GTFS_MyRepo->value(Key);

            if (MyRepo->Action == GRepo::Delete)
            {
                DBase->ExecuteQuery( QString("DELETE FROM Repo WHERE Object='%1'").arg(MyRepo->Object));
                continue;
            }

            if (MyRepo->Action == GRepo::Update)
            {
                QString Sql = QString("INSERT OR REPLACE INTO Repo (Object, LastUpdate) VALUES ('%1', '%2')")
                        .arg( MyRepo->Object)
                        .arg( MyRepo->LastUpdate.toString("yyyy-MM-dd HH:mm:ss"));

                DBase->ExecuteQuery( Sql );
            }
        }

        DBase->WriteParam("Agenzia", Agenzia);
    }

    Busy = false;

    return Ok;
}

/******************************************************/
bool clsGtfs::Read_Repo(QString Agenzia, int Tipo = 0)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::EndPoint + QString("gtfs.asmx/Get_GtfsRepo?Azienda=%1").arg(Agenzia);

    bool Ok = WS->WSCall( Path );

    GTFS_Repo = new QMap<QString, GRepo *>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GRepo *S = new GRepo();

                if (Tipo==0)
                    S->Object     = map["Object"].toString().toUpper();
                else
                    S->Object     = map["Oggetto"].toString().toUpper();

                S->Rev        = map["Revision"].toString();
                S->LastUpdate = map["PublishDate"].toDateTime();
                S->ID         = -1;
                S->Action     = GRepo::Update;

                GTFS_Repo->insert( S->Object, S);
            }
        }
    }

    return Ok;
}

/******************************************************/
bool clsGtfs::Read_Cartelli(QString Agenzia)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::EndPoint + QString("gtfs.asmx/Get_Cartelli?Azienda=%1").arg(Agenzia);

    bool Ok = WS->WSCall( Path );

    GTFS_Pannelli = new QMap<QString, GPannelli *>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GPannelli *S = new GPannelli();

                S->Codice      = map["Codice"].toString().trimmed();
                S->Descrizione = map["Descrizione"].toString();
                S->Num         = map["Num"].toString();
                S->Sup         = map["Sup"].toString();
                S->Inf         = map["Inf"].toString();

                GTFS_Pannelli->insert( S->Codice, S);
            }
        }
    }

    return Ok;
}

/******************************************************/
bool clsGtfs::Read_Velette(QString Agenzia, int Brand)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::BigoPoint + QString("/api/tracker/%1/panels/%2").arg(Agenzia).arg(Brand);

    bool Ok = WS->WSCall( Path );

    GTFS_Velette = new QList< clsPanel* >();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                QVariantList Rec = map["rowPanels"].toList();

                for (int k=0; k<Rec.length(); k++)
                {
                    QMap<QString, QVariant> Elem = Rec.at(k).toMap();

                    clsPanel *P = new clsPanel();

                    P->code      = map ["code"   ].toString();
                    P->brandId   = map ["brandId"].toInt();
                    P->bgColor   = Elem["bgColor"].toString();
                    P->color     = Elem["color"].toString();
                    P->fontId    = Elem["fontId"].toInt();
                    P->modelId   = Elem["modelId"].toInt();
                    P->rowTypeId = Elem["rowTypeId"].toInt();
                    P->panelText = Elem["panelText"].toString();
                    P->slide     = Elem["slide"].toBool();

                    GTFS_Velette->append(P);
                }
            }
        }
    }

    qDebug() << "Velette lenght = " << GTFS_Velette->count();

    return Ok;
}


/******************************************************/
bool clsGtfs::Read_Stops(QString Agenzia)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::EndPoint + QString("gtfs.asmx/Get_Stops?Azienda=%1&Rev=%2").arg(Agenzia).arg(Global::Rev);

    bool Ok = WS->WSCall( Path );

    GTFS_Stops = new QMap<QString, GStops *>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GStops *S = new GStops();

                S->Lat              = map["Stop_Lat"].toFloat();
                S->Lng              = map["Stop_Lon"].toFloat();
                S->Location_Type    = map["Location_Type"].toString();
                S->Parent_Station   = map["Parent_Station"].toString();
                S->Stop_Code        = map["Stop_Code"].toString();
                S->Stop_Desc        = map["Stop_Desc"].toString();
                S->Stop_ID          = map["Stop_ID"].toString();
                S->Stop_Name        = map["Stop_Name"].toString();
                S->Stop_TimeZone    = map["Stop_TimeZone"].toString();
                S->Stop_Url         = map["Stop_Url"].toString();
                S->Radius           = map["Radius"].toInt();

                GTFS_Stops->insert( S->Stop_ID, S);
            }
        }
    }

    return Ok;
}


/******************************************************/
bool clsGtfs::Read_StopsTime(QString Agenzia)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::EndPoint + QString("gtfs.asmx/Get_StopTime_All?Azienda=%1&Rev=%2").arg(Agenzia).arg(Global::Rev);

    bool Ok = WS->WSCall( Path );

    GTFS_StopTimes = new QList<GStopTimes *>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GStopTimes *S = new GStopTimes();

                QDateTime A = map["Arrival_Time"].toDateTime();
                QDateTime D = map["Departure_Time"].toDateTime();

                S->Trip_Id          = map["Trip_Id"].toString();
                S->Stop_Id          = map["Stop_Id"].toString();
                S->Arrival_Time     = A.toString("hh:mm:ss");
                S->Departure_Time   = D.toString("hh:mm:ss");
                S->Stop_Sequence    = map["Stop_Sequence"].toInt();

                GTFS_StopTimes->append(S);
            }
        }
    }

    return Ok;
}

/******************************************************/
bool clsGtfs::Read_Trips(QString Agenzia)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::EndPoint + QString("gtfs.asmx/Get_Trips?Azienda=%1&Rev=%2").arg(Agenzia).arg(Global::Rev);

    bool Ok = WS->WSCall( Path );

    GTFS_Trips = new QMap< QString, GTrips *>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GTrips *S = new GTrips();

                S->Route_ID             = map["Route_ID"].toString();
                S->Service_Id           = map["Service_Id"].toString();
                S->Trip_Id              = map["Trip_Id"].toString();
                S->Trip_Headsign        = map["Trip_Headsign"].toString();
                S->Trip_Short_Name      = map["Trip_Short_Name"].toString();
                S->Direction_Id         = map["Direction_Id"].toString();
                S->Block_Id             = map["Block_Id"].toString();
                S->Shape_Id             = map["Shape_Id"].toString();
                S->Wheelchair_Accessible= map["Wheelchair_Accessible"].toString();
                S->Bikes_Allowed        = map["Bikes_Allowed"].toString();

                GTFS_Trips->insert( S->Trip_Id, S);
            }
        }
    }

    return Ok;
}

/******************************************************/
bool clsGtfs::Read_Routes(QString Agenzia)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::EndPoint + QString("gtfs.asmx/Get_Routes?Azienda=%1&Rev=%2").arg(Agenzia).arg(Global::Rev);

    bool Ok = WS->WSCall( Path );

    GTFS_Routes = new QMap< QString, GRoute *>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GRoute *S = new GRoute();

                S->routeId          = map["routeId"].toString();
                S->routeShortName   = map["routeShortName"].toString();
                S->routeLongName    = map["routeLongName"].toString();
                S->agencyId         = map["agencyId"].toString();
                S->routeDesc        = map["routeDesc"].toString();
                S->routeUrl         = map["routeUrl"].toString();
                S->routeColor       = map["routeColor"].toString();
                S->routeTextColor   = map["routeTextColor"].toString();
                S->routeType        = map["routeType"].toString();
                S->trips            = map["trips"].toInt();

                GTFS_Routes->insert( S->routeId, S);
            }
        }
    }

    return Ok;
}

/******************************************************/
bool clsGtfs::Read_Shapes(bool FL_All, QString ShapeID, QString Agenzia)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path;

    if (FL_All)
        Path = Global::EndPoint + QString("gtfs.asmx/Get_Shape_All?Azienda=%1&Rev=%2").arg(Agenzia).arg(Global::Rev);
    else
        Path = Global::EndPoint + QString("gtfs.asmx/Get_Shape?Azienda=%1&Rev=%2&ShapeID=%3").arg(Agenzia).arg(Global::Rev).arg(ShapeID);

    qDebug() << "Download shape:" << ShapeID;

    bool Ok = WS->WSCall( Path );

    GTFS_Shapes = new QList< GShape *>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GShape *S = new GShape();

                S->ShapeID  = map["ShapeID"].toString();
                S->Lat      = map["Lat"].toFloat();
                S->Lng      = map["Lng"].toFloat();
                S->Marker   = map["Marker"].toInt();
                S->Seq      = map["Seq"].toInt();

                GTFS_Shapes->append(S);
            }
        }
    }

    return Ok;
}

/******************************************************/
bool clsGtfs::Read_Turni(QString Agenzia)
/******************************************************/
{
    clsWebService *WS = new clsWebService();

    QString Path = Global::EndPoint + QString("gtfs.asmx/Get_DutyOfDay?Azienda=%1&Rev=%2&").arg(Agenzia).arg(Global::Rev);

    qDebug() << Path;

    bool Ok = WS->WSCall( Path );

    GTFS_Turni = new QMap<QString, GTurni*>();

    if (Ok)
    {
        JsonArray list = QtJson::parse( WS->Web_Response, Ok).toList();

        if (Ok)
        {
            for (int j=0; j<list.length(); j++)
            {
                QMap<QString, QVariant> map = list[j].toMap();

                GTurni *S = new GTurni();

                S->ID               = map["ID"].toInt();
                S->BColor           = map["BColor"].toString();
                S->SingleTrip       = map["CorsaSingola"].toBool();
                S->Data_Arrivo      = map["Data_Arrivo"].toDateTime();
                S->Data_Partenza    = map["Data_Partenza"].toDateTime();
                S->DutyID           = map["DutyID"].toString();
                S->DutyName         = map["DutyName"].toString();
                S->Loc_Arrivo       = map["Loc_Arrivo"].toString();
                S->Loc_Partenza     = map["Loc_Partenza"].toString();
                S->Planned_Length   = map["Planned_Length"].toFloat();
                S->Route_ID         = map["Route_ID"].toString();
                S->Route_Long_Name  = map["Route_Long_Name"].toString();
                S->ServiceID        = map["ServiceID"].toString();
                S->ShapeID          = map["ShapeID"].toString();
                S->TripID           = map["TripID"].toString();

                GTFS_Turni->insert( QString::number(S->ID), S);

                qDebug() << "ID:" << S->ID << " " << S->TripID << " " << QDateTime(S->Data_Partenza).toString("dd/MM/yyyy HH:mm:ss");
            }
        }
    }

    return Ok;
}

/*********************************************/
bool clsGtfs::Save_Shape(QString ShapeID)
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if (DBase->m_db.transaction())
    {
        QSqlQuery Qry(DBase->m_db);

        if (ShapeID.length() == 0)
            Sql = QString("DELETE FROM Shape");
        else
            Sql = QString("DELETE FROM Shape WHERE ShapeID='%1'").arg(ShapeID);

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {
            for (int j=0; j<GTFS_Shapes->length(); j++)
            {
                GShape *S = GTFS_Shapes->at(j);

                if (ShapeID.length() > 0)
                    if (S->ShapeID != ShapeID)
                        continue;

                Sql = QString("INSERT INTO Shape (ShapeID, Seq, Lat, Lng, Marker) "
                              "VALUES ('%1', %2, %3, %4, '%5')")
                .arg(S->ShapeID)
                .arg(S->Seq)
                .arg(S->Lat)
                .arg(S->Lng)
                .arg(S->Marker);

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }

        if (Ret)
        {
            if (!DBase->m_db.commit())
            {
                DBase->m_db.rollback();
            }
        }
        else
            DBase->m_db.rollback();

    }

    return Ret;
}

/*********************************************/
bool clsGtfs::Save_Routes()
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if (DBase->m_db.transaction())
    {
        QSqlQuery Qry(DBase->m_db);

        Sql = QString("DELETE FROM Routes");

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {
            foreach( QString key, GTFS_Routes->keys() )
            {
                GRoute *S = GTFS_Routes->value(key);

                qDebug() << "Save routes " << S->routeId;

                Sql = QString("INSERT INTO Routes (RouteID, RouteShortName, RouteLongName, AgencyID, RouteDesc, RouteUrl, RouteColor, RouteTextColor, RouteType, Trips) "
                              "VALUES ('%1', '%2', '%3', '%4', '%5', '%6', '%7', '%8', '%9', %10)")
                .arg(S->routeId)
                .arg(S->routeShortName.replace("'", "''"))
                .arg(S->routeLongName.replace("'", "''"))
                .arg(S->agencyId)
                .arg(S->routeDesc.replace("'", "''"))
                .arg(S->routeUrl)
                .arg(S->routeColor)
                .arg(S->routeTextColor)
                .arg(S->routeType)
                .arg(S->trips);

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }

        if (Ret)
        {
            if (!DBase->m_db.commit())
            {
                DBase->m_db.rollback();
            }
        }
        else
            DBase->m_db.rollback();

    }

    return Ret;
}

/*********************************************/
bool clsGtfs::Save_Cartelli()
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if (DBase->m_db.transaction())
    {
        QSqlQuery Qry(DBase->m_db);

        Sql = QString("DELETE FROM Cartelli");

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {
            foreach( QString key, GTFS_Pannelli->keys() )
            {
                GPannelli *S = GTFS_Pannelli->value(key);

                qDebug() << "Save Cartelli " + S->Codice;

                Sql = QString("INSERT INTO Cartelli (Codice,Descrizione,Num,Sup,Inf) "
                              "VALUES ('%1', '%2', '%3', '%4', '%5')")
                .arg(S->Codice)
                .arg(S->Descrizione.replace("'", "''"))
                .arg(S->Num.replace("'", "''"))
                .arg(S->Sup.replace("'", "''"))
                .arg(S->Inf.replace("'", "''"));

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }

        if (Ret)
        {
            if (!DBase->m_db.commit())
            {
                DBase->m_db.rollback();
            }
        }
        else
            DBase->m_db.rollback();
    }

    return Ret;
}

/*********************************************/
bool clsGtfs::Save_Velette()
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if (DBase->m_db.transaction())
    {
        QSqlQuery Qry(DBase->m_db);

        Sql = QString("DELETE FROM Velette");

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {
            int ID = 0;

            for (int j=0; j<GTFS_Velette->count(); j++ )
            {
                clsPanel *S = GTFS_Velette->at(j);

                qDebug() << "Save Cartelli " + S->code;

                Sql = QString("INSERT INTO Velette ([code],[brandId],[modelId],[rowTypeId],[panelText],[fontId],[color],[bgcolor],[slide],ID) VALUES ( '%1',%2,%3,%4,'%5',%6,'%7','%8',%9,%10)")
                        .arg(S->code)
                        .arg(S->brandId)
                        .arg(S->modelId)
                        .arg(S->rowTypeId)
                        .arg(S->panelText.replace("'", "''"))
                        .arg(S->fontId)
                        .arg(S->color)
                        .arg(S->bgColor)
                        .arg(S->slide)
                        .arg(ID++);

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }

        if (Ret)
        {
            if (!DBase->m_db.commit())
            {
                DBase->m_db.rollback();
            }
        }
        else
            DBase->m_db.rollback();
    }

    return Ret;
}

/*********************************************/
bool clsGtfs::Save_Stops()
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if (DBase->m_db.transaction())
    {
        QSqlQuery Qry(DBase->m_db);

        Sql = QString("DELETE FROM Stops");

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {
            foreach( QString key, GTFS_Stops->keys() )
            {
                GStops *S = GTFS_Stops->value(key);

                qDebug() << "Save Stops " + S->Stop_ID;

                Sql = QString("INSERT INTO Stops (Stop_ID,Stop_Code,Stop_Name,Stop_Desc,Lat,Lon,Zone_ID,Location_Type,Stop_Url,Parent_Station,Stop_TimeZone,Wheelchair_Boarding,Stop_Index,Radius) "
                              "VALUES ('%1', '%2', '%3', '%4', %5, %6, '%7', '%8', '%9', '%10', '%11', '%12', %13, %14)")
                .arg(S->Stop_ID)
                .arg(S->Stop_Code)
                .arg(S->Stop_Name.replace("'", "''"))
                .arg(S->Stop_Desc.replace("'", "''"))
                .arg(S->Lat)
                .arg(S->Lng)
                .arg(S->Zone_ID)
                .arg(S->Location_Type)
                .arg(S->Stop_Url)
                .arg(S->Parent_Station)
                .arg(S->Stop_TimeZone)
                .arg(S->Wheelchair_Boarding)
                .arg(S->StopIndex)
                .arg(S->Radius);

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    DBase->m_db.rollback();
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }
    }

    if (Ret)
    {
        if (!DBase->m_db.commit())
        {
            DBase->m_db.rollback();
        }
    }
    else
        DBase->m_db.rollback();


    return Ret;
}

/*********************************************/
bool clsGtfs::Save_Trips()
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if ( DBase->m_db.transaction() )
    {
        QSqlQuery Qry(DBase->m_db);

        Sql = QString("DELETE FROM Trips");

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {
            foreach( QString key, GTFS_Trips->keys() )
            {
                GTrips *S = GTFS_Trips->value(key);

                qDebug() << "Save Trips " + S->Trip_Id;

                Sql = QString("INSERT INTO Trips (Route_ID, Service_Id, Trip_Id, Trip_Headsign, Trip_Short_Name, Direction_Id, Block_Id, Shape_Id, Wheelchair_Accessible, Bikes_Allowed, nStop) "
                              "VALUES ('%1', '%2', '%3', '%4', '%5', '%6', '%7', '%8', '%9', '%10', %11) ")
                .arg(S->Route_ID)
                .arg(S->Service_Id)
                .arg(S->Trip_Id)
                .arg(S->Trip_Headsign)
                .arg(S->Trip_Short_Name)
                .arg(S->Direction_Id)
                .arg(S->Block_Id)
                .arg(S->Shape_Id)
                .arg(S->Wheelchair_Accessible)
                .arg(S->Bikes_Allowed)
                .arg(S->nStop);

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }
    }

    if (Ret)
    {
        if (!DBase->m_db.commit())
        {
            DBase->m_db.rollback();
        }
    }
    else
        DBase->m_db.rollback();

    return Ret;
}

/*********************************************/
bool clsGtfs::Save_StopsTime()
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if (DBase->m_db.transaction())
    {
        QSqlQuery Qry(DBase->m_db);

        Sql = QString("DELETE FROM StopsTime");

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {

            for( int j=0; j<GTFS_StopTimes->count(); j++ )
            {
                GStopTimes *S = GTFS_StopTimes->at(j);

                qDebug() << "Save StopTime " + S->Trip_Id;

                Sql = QString("INSERT INTO StopsTime (Trip_Id, Stop_Id, Arrival_Time, Departure_Time, Stop_Sequence) "
                              "VALUES ('%1', '%2', '%3', '%4', %5)")
                .arg(S->Trip_Id)
                .arg(S->Stop_Id)
                .arg(S->Arrival_Time)
                .arg(S->Departure_Time)
                .arg(S->Stop_Sequence);

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }
    }

    if (Ret)
    {
        if (!DBase->m_db.commit())
        {
            DBase->m_db.rollback();
        }
    }
    else
        DBase->m_db.rollback();


    return Ret;
}

/*********************************************/
bool clsGtfs::Save_Turni()
/*********************************************/
{
    bool Ret = true;

    QString Sql;

    if (DBase->m_db.transaction())
    {
        QSqlQuery Qry(DBase->m_db);

        Sql = QString("DELETE FROM TurniMacchina");

        bool Ok = Qry.exec(Sql);

        if (Ok)
        {
            qDebug() << "nTurni=" << GTFS_Turni->keys().count();

            foreach( QString Key, GTFS_Turni->keys() )
            {
                GTurni *S = GTFS_Turni->value(Key);

                qDebug() << "Save turno: " << S->TripID;

                Sql = QString("INSERT INTO TurniMacchina (DutyID, Loc_Partenza, Loc_Arrivo, Data_Partenza, Data_Arrivo, Route_ID, Route_Long_Name, Planned_Length, SingleTrip, ServiceID, ShapeID, TripID, DutyName, BColor) "
                              "VALUES ('%1', '%2', '%3', '%4', '%5', '%6', '%7', %8, %9, '%10', '%11', '%12', '%13', '%14')")
                .arg(S->DutyID)
                .arg(S->Loc_Partenza.replace("'", "''"))
                .arg(S->Loc_Arrivo.replace("'", "''"))
                .arg(S->Data_Partenza.toString("yyyy-MM-dd HH:mm:ss"))
                .arg(S->Data_Arrivo.toString("yyyy-MM-dd HH:mm:ss"))
                .arg(S->Route_ID)
                .arg(S->Route_Long_Name.replace("'", "''"))
                .arg(S->Planned_Length)
                .arg(S->SingleTrip)
                .arg(S->ServiceID)
                .arg(S->ShapeID)
                .arg(S->TripID)
                .arg(S->DutyName.replace("'", "''"))
                .arg(S->BColor);

                Ok = Qry.exec(Sql);

                if (!Ok)
                {
                    qDebug() << "> Query exec() error." << Qry.lastError().text();
                    Ret = false;
                    break;
                }
            }
        }
    }

    if (Ret)
    {
        if (!DBase->m_db.commit())
        {
            DBase->m_db.rollback();
        }
    }
    else
        DBase->m_db.rollback();

    return Ret;
}

/******************************************************/
bool clsGtfs::Write_Stops()
/******************************************************/
{
    QString FileName = QCoreApplication::applicationDirPath() + "/stops.txt" ;

    QFile Out(FileName);

    if (Out.open( QIODevice::WriteOnly | QIODevice::Truncate ))
    {
        QTextStream OutS(&Out);

        QString Txt = QString("stop_id;stop_name;stop_desc;stop_lat;stop_lng\n");

        OutS << Txt;

        foreach( QString key, GTFS_Stops->keys() )
        {
            GStops *S = GTFS_Stops->value(key);

            Txt = QString("%1;%2;%3;%4;%5\n").arg(S->Stop_ID).arg(S->Stop_Name).arg(S->Stop_Desc).arg(S->Lat).arg(S->Lng);

            OutS << Txt;
        }

        Out.close();

        return true;
    }

    return false;
}

/******************************************************/
bool clsGtfs::Load_Stops()
/******************************************************/
{
    bool Ok = true;

    GTFS_Stops = new QMap<QString, GStops *>();

    QSqlQuery Query = DBase->GetRecord("SELECT * FROM Stops ORDER BY Stop_ID");

    if (Query.isSelect())
    {
        int Index = 0;

        while (Query.next())
        {
            GStops *S = new GStops();

            S->Lat              = DBase->GetFFromName( Query, "Lat" );
            S->Lng              = DBase->GetFFromName( Query, "Lon" );
            S->Location_Type    = DBase->GetSFromName( Query, "Location_Type" );
            S->Parent_Station   = DBase->GetSFromName( Query, "Parent_Station" );
            S->Stop_Code        = DBase->GetSFromName( Query, "Stop_Code" );
            S->Stop_Desc        = DBase->GetSFromName( Query, "Stop_Desc" );
            S->Stop_ID          = DBase->GetSFromName( Query, "Stop_ID" );
            S->Stop_Name        = DBase->GetSFromName( Query, "Stop_Name" );
            S->Stop_TimeZone    = DBase->GetSFromName( Query, "Stop_TimeZone" );
            S->Stop_Url         = DBase->GetSFromName( Query, "Stop_Url" );
            S->Radius           = DBase->GetIFromName( Query, "Radius" );

            S->StopIndex = Index++;

            GTFS_Stops->insert( S->Stop_ID, S);
        }
    }
    else Ok = false;

    return Ok;
}

/******************************************************/
bool clsGtfs::Load_Cartelli()
/******************************************************/
{
    bool Ok = true;

    GTFS_Pannelli = new QMap<QString, GPannelli *>();

    QSqlQuery Query = DBase->GetRecord("SELECT * FROM Cartelli ORDER BY LENGTH(Codice), Codice");

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GPannelli *S = new GPannelli();

            S->Codice      = DBase->GetSFromName( Query, "Codice" );
            S->Descrizione = DBase->GetSFromName( Query, "Descrizione" );
            S->Num         = DBase->GetSFromName( Query, "Num" );
            S->Sup         = DBase->GetSFromName( Query, "Sup" );
            S->Inf         = DBase->GetSFromName( Query, "Inf" );

            GTFS_Pannelli->insert( S->Codice, S);
        }
    }
    else Ok = false;

    return Ok;
}


/******************************************************/
int clsGtfs::Load_Velette(QString Filtro, int Brand, int Model)
/******************************************************/
{
    QString Sql = QString("SELECT * FROM Velette WHERE code like '%1' and brandId=%2 and modelId=%3 order by ID LIMIT 600")
            .arg(Filtro)
            .arg(Brand)
            .arg(Model);

    qDebug() << Sql;

    if (GTFS_Velette == nullptr)
        GTFS_Velette = new QList< clsPanel *>();
    else
        GTFS_Velette->clear();

    QSqlQuery Query = DBase->GetRecord(Sql);

    if (Query.isSelect())
    {
        while (Query.next())
        {
            clsPanel *S = new clsPanel();

            S->code     = DBase->GetSFromName( Query, "code" );
            S->bgColor  = DBase->GetSFromName( Query, "bgColor" );
            S->brandId  = DBase->GetIFromName( Query, "brandId" );
            S->color    = DBase->GetSFromName( Query, "color" );
            S->fontId   = DBase->GetIFromName( Query, "fontId" );
            S->modelId  = DBase->GetIFromName( Query, "modelId" );
            S->panelText= DBase->GetSFromName( Query, "panelText" );
            S->rowTypeId= DBase->GetIFromName( Query, "rowTypeId" );
            S->slide    = DBase->GetBFromName( Query, "slide" );

            // qDebug() << S->code;

            GTFS_Velette->append(S);
        }
    }

    return GTFS_Velette->count();
}


/******************************************************/
bool clsGtfs::Load_StopsTime(QString TripID)
/******************************************************/
{
    bool Ok = true;
    QSqlQuery Query;

    GTFS_StopTimes = new QList<GStopTimes *>();

    if (TripID.length() > 0)
        Query = DBase->GetRecord( QString("SELECT * FROM StopsTime WHERE Trip_id = '%1' ORDER BY Stop_Sequence").arg(TripID));
    else
        Query = DBase->GetRecord( QString("SELECT * FROM StopsTime ORDER BY Trip_ID, Stop_Sequence"));

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GStopTimes *S = new GStopTimes();

            S->Trip_Id          = DBase->GetSFromName( Query, "Trip_Id" );
            S->Stop_Id          = DBase->GetSFromName( Query, "Stop_Id" );
            S->Arrival_Time     = DBase->GetSFromName( Query, "Arrival_Time" );
            S->Departure_Time   = DBase->GetSFromName( Query, "Departure_Time" );
            S->Stop_Sequence    = DBase->GetIFromName( Query, "Stop_Sequence" );

            S->Enabled  = true;
            S->TrackPtr = -1;

            GTFS_StopTimes->append(S);
        }
    }
    else Ok = false;

    return Ok;
}

/******************************************************/
int clsGtfs::Load_Trips(QString TripID)
/******************************************************/
{
    QSqlQuery Query;

    int nRec = 0;

    GTFS_Trips = new QMap< QString, GTrips *>();

    if (TripID.length() > 0)
        Query = DBase->GetRecord( QString("SELECT * FROM Trips WHERE Trip_ID='%1'").arg(TripID));
    else
        Query = DBase->GetRecord("SELECT * FROM Trips ORDER BY Trip_ID");

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GTrips *S = new GTrips();

            S->Bikes_Allowed    = DBase->GetSFromName( Query, "Bikes_Allowed" );
            S->Block_Id         = DBase->GetSFromName( Query, "Block_Id" );
            S->Direction_Id     = DBase->GetSFromName( Query, "Direction_Id" );
            S->nStop            = DBase->GetIFromName( Query, "nStop" );
            S->Route_ID         = DBase->GetSFromName( Query, "Route_ID" );
            S->Service_Id       = DBase->GetSFromName( Query, "Service_Id" );
            S->Shape_Id         = DBase->GetSFromName( Query, "Shape_Id" );
            S->Trip_Headsign    = DBase->GetSFromName( Query, "Trip_Headsign" );
            S->Trip_Id          = DBase->GetSFromName( Query, "Trip_Id" );
            S->Trip_Short_Name  = DBase->GetSFromName( Query, "Trip_Short_Name" );
            S->Wheelchair_Accessible = DBase->GetSFromName( Query, "Wheelchair_Accessible" );

            GTFS_Trips->insert( S->Trip_Id, S);
        }

        nRec = GTFS_Trips->count();
    }
    else nRec = -1;

    return nRec;
}

/******************************************************/
int clsGtfs::Load_Repo()
/******************************************************/
{
    QSqlQuery Query;

    int nRec = 0;

    GTFS_MyRepo = new QMap< QString, GRepo *>();

    Query = DBase->GetRecord("SELECT * FROM Repo ORDER BY Object");

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GRepo *S = new GRepo();

            S->Object       = DBase->GetSFromName( Query, "Object" ).toUpper();
            S->LastUpdate   = DBase->GetDFromName( Query, "LastUpdate" );
            S->Action       = GRepo::None;

            GTFS_MyRepo->insert( S->Object, S);
        }

        nRec = GTFS_MyRepo->count();
    }
    else nRec = -1;

    return nRec;
}


/******************************************************/
bool clsGtfs::Load_Routes()
/******************************************************/
{
    bool Ok = true;

    GTFS_Routes = new QMap< QString, GRoute *>();

    QSqlQuery Query = DBase->GetRecord("SELECT * FROM Routes ORDER BY routeId");

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GRoute *S = new GRoute();

            S->agencyId         = DBase->GetSFromName( Query, "agencyId" );
            S->routeColor       = DBase->GetSFromName( Query, "routeColor" );
            S->routeDesc        = DBase->GetSFromName( Query, "routeDesc" );
            S->routeId          = DBase->GetSFromName( Query, "routeId" );
            S->routeLongName    = DBase->GetSFromName( Query, "routeLongName" );
            S->routeShortName   = DBase->GetSFromName( Query, "routeShortName" );
            S->routeTextColor   = DBase->GetSFromName( Query, "routeTextColor" );
            S->routeType        = DBase->GetSFromName( Query, "routeType" );
            S->routeUrl         = DBase->GetSFromName( Query, "routeUrl" );
            S->trips            = DBase->GetIFromName( Query, "trips" );

            GTFS_Routes->insert( S->routeId, S);
        }
    }
    else Ok = false;

    return Ok;
}

/******************************************************/
bool clsGtfs::Load_Shapes(QString ShapeID)
/******************************************************/
{
    bool Ok = true;
    QSqlQuery Query;

    GTFS_Shapes = new QList<GShape *>();

    if (ShapeID.length() > 0)
        Query = DBase->GetRecord( QString("SELECT * FROM Shape WHERE ShapeID = '%1' ORDER BY Seq").arg(ShapeID));
    else
        Query = DBase->GetRecord( QString("SELECT * FROM Shape ORDER BY ShapeID, Seq"));

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GShape *S = new GShape();

            S->Lat      = DBase->GetFFromName( Query, "Lat" );
            S->Lng      = DBase->GetFFromName( Query, "Lng" );
            S->Marker   = DBase->GetIFromName( Query, "Marker" );
            S->Seq      = DBase->GetIFromName( Query, "Seq" );
            S->ShapeID  = DBase->GetSFromName( Query, "ShapeID" );

            GTFS_Shapes->append(S);
        }
    }
    else Ok = false;

    return Ok;
}

/******************************************************/
QList<QString> *clsGtfs::Load_ElencoTurni( QDateTime Data )
/******************************************************/
{
    QList<QString> *Lista = new QList<QString>();

    QString Sql = QString("SELECT DISTINCT [DutyID] FROM [TurniMacchina] where DATE(Data_Partenza) = '%1' ORDER BY [DutyID]").arg(Data.toString("yyyy-MM-dd"));

    QSqlQuery Query = DBase->GetRecord(Sql);

    if (Query.isSelect())
    {
        while (Query.next())
        {
            QString S = DBase->GetSFromName( Query, "DutyID" );

            Lista->append(S);
        }
    }

    return Lista;
}

/******************************************************/
bool clsGtfs::Load_Turni(QString Duty, QDateTime Data)
/******************************************************/
{
    bool Ok = true;

    GTFS_Turni = new QMap<QString, GTurni *>();

    QString Sql = "SELECT * FROM TurniMacchina ";

    if (Duty != "")
        Sql += QString("WHERE DutyID='%1' AND ").arg(Duty);
    else
        Sql += "WHERE ";

    Sql += QString("DATE(Data_Partenza) = '%1' ").arg(Data.toString("yyyy-MM-dd"));

    Sql += "ORDER BY DutyID, Data_Partenza ASC";

    QSqlQuery Query = DBase->GetRecord(Sql);

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GTurni *S = new GTurni();

            S->ID               = DBase->GetIFromName( Query, "ID");
            S->SingleTrip       = DBase->GetIFromName( Query, "SingleTrip" );
            S->ServiceID        = DBase->GetFFromName( Query, "ServiceID" );
            S->BColor           = DBase->GetFFromName( Query, "BColor" );
            S->Data_Arrivo      = DBase->GetDFromName( Query, "Data_Arrivo" );
            S->Data_Partenza    = DBase->GetDFromName( Query, "Data_Partenza" );
            S->Done             = false;
            S->DutyID           = DBase->GetSFromName( Query, "DutyID" );
            S->DutyName         = DBase->GetFFromName( Query, "DutyName" );
            S->Km_Reali         = 0;
            S->Loc_Arrivo       = DBase->GetSFromName( Query, "Loc_Arrivo" );
            S->Loc_Partenza     = DBase->GetSFromName( Query, "Loc_Partenza" );
            S->nFermate         = 0;
            S->Planned_Length   = DBase->GetFFromName( Query, "Planned_Length" );
            S->Route_ID         = DBase->GetSFromName( Query, "Route_ID" );
            S->Route_Long_Name  = DBase->GetSFromName( Query, "Route_Long_Name" );
            S->ShapeID          = DBase->GetSFromName( Query, "ShapeID" );
            S->TripID           = DBase->GetSFromName( Query, "TripID" );

            GTFS_Turni->insert( S->TripID, S);

            qDebug() << "Load Turni: " << S->ID << " DEL " << S->Data_Partenza;
        }
    }
    else Ok = false;

    return Ok;
}

/******************************************************/
bool clsGtfs::Load_Track(QString ShapeID)
/******************************************************/
{
    bool Ok = true;

    QSqlQuery Query(DBase->m_db);

    GTFS_Track = new QList<GTrack *>();

    Query = DBase->GetRecord( QString("SELECT * FROM Shape WHERE ShapeID = '%1' ORDER BY Seq").arg(ShapeID));

    if (Query.isSelect())
    {
        while (Query.next())
        {
            GTrack *S = new GTrack();

            S->Lat      = DBase->GetFFromName( Query, "Lat" );
            S->Lng      = DBase->GetFFromName( Query, "Lng" );
            S->Marker   = (eMarker)DBase->GetIFromName( Query, "Marker" );
            S->Seq      = DBase->GetIFromName( Query, "Seq" );
            S->ShapeID  = DBase->GetSFromName( Query, "ShapeID" );

            S->Angolo = 0;
            S->Arrival_Time = 0;
            S->Departure_Time = 0;
            S->Distance = 0;
            S->Metri = 0;
            S->Orario_Statico = QDateTime();
            S->Prevision_Time = 0;
            S->StopID = "";
            S->Stop_Index = 0;
            S->TripSeq = 0;
            S->Velocita_Media = 0;

            qDebug() << "Load track: " << S->Seq;

            GTFS_Track->append(S);
        }
    }
    else Ok = false;

    return Ok;
}

