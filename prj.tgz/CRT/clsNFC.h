//moved
#ifndef CLSNFC_H
#define CLSNFC_H

#include <QMutex>
#include <QtSerialPort/QSerialPort>
#include <QThread>
#include <QTime>

class clsNfc : public QThread
{
    Q_OBJECT

public:

    explicit clsNfc(QObject *parent = nullptr);
    ~clsNfc();

    void startSlave(const QString &portName, int waitTimeout);
    void run() Q_DECL_OVERRIDE;
    void StopThread();

    void    begin();
    void    wakeup();
    quint32 getFirmwareVersion(void);

    qint8   writeCommand(const quint8 *header, quint8 hlen, const quint8 *body = 0, quint8 blen = 0);
    qint16  readResponse(quint8 *buf, quint8 len, quint16 timeout = 1000);


private slots:

signals:

    void request    (const QString &s);
    void error      (const QString &s);
    void timeout    (const QString &s);

private:

    QString portName;
    QString response;
    int waitTimeout;
    QMutex mutex;
    bool   quit;
    QTime  T0;
    QTime  LastUpdate;

    static const int BufSize = 256;

    void  Automa        (QByteArray Data);
    void  writeByte     (quint8 Dato);
    qint8 readAckFrame  ();

    bool   RxErr  = false;
    int    RxPtr  = 0;
    quint8 command;

    QByteArray RxBuffer;

    QSerialPort serial;
};

#endif // CLSGPS_H
