#include "clsrepository.h"
#include <QCoreApplication>
#include <QUrl>
#include <QNetworkRequest>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QDebug>
#include <QCryptographicHash>
#include <QProcess>

QtDownload::QtDownload() : QObject(0)
{
    QObject::connect(&manager, SIGNAL(finished(QNetworkReply*)),this, SLOT(downloadFinished(QNetworkReply*)));
}

QtDownload::~QtDownload()
{

}

/********************************************************************/
void QtDownload::setTarget(const QString &Url, const QString &FileName, const QString &md5)
/********************************************************************/
{
    this->target = Url;
    this->RemoteMd5 = md5;
    this->LocalFile = FileName;
}

/********************************************************************/
void QtDownload::downloadFinished(QNetworkReply *data)
/********************************************************************/
{
    QString Root = QCoreApplication::applicationDirPath();

    QString TempFile = QString(Root + "/tmp/%1.tmp").arg(LocalFile);
    QString DestFile = QString(Root + "/%1").arg(LocalFile);

    QString Path = TempFile.section("/", 0, -2);
    if (!QDir(Path).exists()) QDir().mkdir(Path);

    Path = DestFile.section("/", 0, -2);
    if (!QDir(Path).exists()) QDir().mkdir(Path);

    QFile localFile(TempFile);

    const QByteArray sdata = data->readAll();

    QString MD5 = QString( QCryptographicHash::hash( sdata, QCryptographicHash::Md5).toHex() ).toUpper();

    if (MD5 == RemoteMd5)
    {
        qDebug() << "Download effettutato correttamente";

        if (localFile.open( QIODevice::WriteOnly ))
        {
            localFile.write(sdata);

            localFile.flush();
            localFile.close();

            /************************************************
             * Controllo il file dopo la scrittura sul disco
             ************************************************/

            MD5 = File_ReadMd5(TempFile);

            if (MD5 == RemoteMd5)
            {
                qDebug() << "Nuovo eseguibile pronto nella cartella temp";

                QString Cmd = QString("mv %1 %2").arg(TempFile).arg(DestFile);

                QProcess::execute(Cmd);

                emit done();
            }
            else
                qDebug() << "Errore scrittura file (CRC) " << TempFile;
        }
        else
            qDebug() << "Errore scrittura file " << TempFile;
    }
    else
        qDebug() << "Download error CRC differenti";
}

/********************************************************************/
void QtDownload::download()
/********************************************************************/
{
    QUrl url = QUrl::fromEncoded(this->target.toLocal8Bit());
    QNetworkRequest request(url);
    QObject::connect(manager.get(request), SIGNAL(downloadProgress(qint64,qint64)), this, SLOT(downloadProgress(qint64,qint64)));

}

/********************************************************************/
void QtDownload::downloadProgress(qint64 recieved, qint64 total)
/********************************************************************/
{
    // qDebug() << recieved << total;
}

/******************************************/
QString QtDownload::File_ReadMd5(QString FileName)
/******************************************/
{
    QString Ret = "";

    QFile file(FileName);

    if(file.exists())
    {
        if(file.open(QIODevice::ReadOnly))
        {
            QByteArray Data = file.readAll();

            Ret = QString( QCryptographicHash::hash( Data, QCryptographicHash::Md5).toHex() ).toUpper();

            file.close();
        }
    }

    return Ret;
}

