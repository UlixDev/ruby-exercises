#include "togglepin.h"

#include <QDebug>
#include <QTimer>

void TogglePin::on()
{
    // Attiva il pin
    this->setValue(1);

    // Stato corrente
    this->activated = true;
}

void TogglePin::off()
{
    // Disattiva il pin, tramite /sys/class/gpio/gpioXX/value
    this->setValue(0);

    // Stato corrente
    this->activated = false;
}

void TogglePin::toggle()
{
    if (this->activated)
    {
        this->off();
    } else {
        this->on();
    }
}

bool TogglePin::isOn()
{
    return this->activated;
}

void TogglePin::Beep(int nBeep)
{
    int p = 0;

    for (int j=0; j < nBeep; j++)
    {
        Wave[p++] = 1;
        Wave[p++] = 4;
    }

    this->WavePtr = nBeep * 2;

    this->setBrightness(100);
}


