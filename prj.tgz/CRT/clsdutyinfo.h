// moved to forms/ui renamed in some more self-speaking thing like DisplayDuty
#ifndef CLSDUTYINFO_H
#define CLSDUTYINFO_H

#include <QWidget>

namespace Ui
{
    class clsDutyInfo;
}

class clsDutyInfo : public QWidget
{
    Q_OBJECT

public:
    explicit clsDutyInfo(QWidget *parent = nullptr);
    ~clsDutyInfo();

private:
    Ui::clsDutyInfo *ui;
};

#endif // CLSDUTYINFO_H
