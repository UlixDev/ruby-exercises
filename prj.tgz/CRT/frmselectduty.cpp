#include "frmselectduty.h"
#include "ui_frmselectduty.h"

#include <QLabel>
#include <QDebug>
//#include <algorithm>
#include "global.h"

frmSelectDuty::frmSelectDuty(QWidget *parent) :  QWidget(parent), ui(new Ui::frmSelectDuty)
{
    ui->setupUi(this);

    /***********************
     * LABEL WARNING
     ***********************/

    ui->L_Warning->setVisible(false);

    int W = ui->L_Warning->width();
    int H = ui->L_Warning->height();

    W = (this->width() - W ) / 2;
    H = (this->height() - H) / 2;

    ui->L_Warning->move(W, H);

    /***********************
     * SLOT SETTING
     ***********************/

    Slot[0] = ui->Slot_1;
    Slot[1] = ui->Slot_2;
    Slot[2] = ui->Slot_3;
    Slot[3] = ui->Slot_4;
    Slot[4] = ui->Slot_5;
    Slot[5] = ui->Slot_6;
    Slot[6] = ui->Slot_7;
    Slot[7] = ui->Slot_8;
    Slot[8] = ui->Slot_9;
    Slot[9] = ui->Slot_10;
    Slot[10]= ui->Slot_11;
    Slot[11]= ui->Slot_12;

    for (int j=0; j < nSlot; j++)
    {
        QLabel *L_Desc   = Slot[j]->findChild<QLabel *>("L_Desc");
        QPushButton *Btn = Slot[j]->findChild<QPushButton *>("cmd_Duty");

        connect (Btn, SIGNAL(clicked()), this, SLOT(on_cmd_Duty()));

        Btn->setVisible(false);
        L_Desc->setVisible(false);
    }

    Gtfs = new clsGtfs();

    Gtfs->Load_Turni( "", Global::CurrentTime() );

    Duty = new QMap<QString, DutyInfo *>();

    DutyInfo *Info = nullptr;

    for (int j=0; j<Gtfs->GTFS_Turni->count(); j++)
    {
        QString Key = Gtfs->GTFS_Turni->keys().at(j);

        GTurni *T = Gtfs->GTFS_Turni->value(Key);

        if (!Duty->contains(T->DutyID))
            Duty->insert(T->DutyID, new DutyInfo());

        Info = Duty->value(T->DutyID);

        Info->DutyID    = T->DutyID;
        Info->DutyDesc  = T->Loc_Arrivo + "\n" + T->Loc_Arrivo;

        if (T->Data_Partenza < Info->DutyStart || !Info->DutyStart.isValid() )
            Info->DutyStart = T->Data_Partenza;

        if (T->Data_Partenza > Info->DutyEnd || !Info->DutyEnd.isValid() )
            Info->DutyEnd = T->Data_Partenza;
    }

    if (Gtfs->GTFS_Turni->count() > 0)
        ShowDuty();
    else
        ui->L_Warning->setVisible(true);
}

frmSelectDuty::~frmSelectDuty()
{
    delete ui;
}

void frmSelectDuty::ShowDuty()
{
    ViewMode = eViewMode::Duty;

    QList<DutyInfo*> Elenco = Duty->values();

    std::sort(Elenco.begin(), Elenco.end(), [](const DutyInfo* a, const DutyInfo* b) -> bool { return a->DutyID < b->DutyID; });

    if (Ptr >= Elenco.length())
        Ptr -= (nSlot / 2);

    for (int j=0; j < nSlot; j++)
    {
        int Index = Ptr + j;

        QLabel *L_Desc   = Slot[j]->findChild<QLabel *>("L_Desc");
        QPushButton *Btn = Slot[j]->findChild<QPushButton *>("cmd_Duty");

        L_Desc->setVisible(Index < Elenco.length());

        Btn->setVisible(Index < Elenco.length());

        if (Index < Elenco.length())
        {
            DutyInfo *D = Elenco.at(Index);

            L_Desc->setText(D->DutyDesc);

            Btn->setText(D->DutyID);
        }
    }
}

void frmSelectDuty::ShowTrip(QString DutyID)
{
    CurrentDuty = DutyID;

    ViewMode = eViewMode::Trip;

    QList<GTurni*> Elenco;

    foreach( GTurni *T, Gtfs->GTFS_Turni->values() )
    {
        if (T->DutyID == DutyID)
            Elenco.append(T);
    }

    std::sort ( Elenco.begin(), Elenco.end(), [](const GTurni* a, const GTurni* b) -> bool { return a->Data_Partenza < b->Data_Partenza; });

    if (Ptr >= Elenco.length())
        Ptr -= (nSlot / 2);

    for (int j=0; j < nSlot; j++)
    {
        int Index = Ptr + j;

        QLabel *L_Desc   = Slot[j]->findChild<QLabel *>("L_Desc");

        QPushButton *Btn = Slot[j]->findChild<QPushButton *>("cmd_Duty");

        L_Desc->setVisible(Index < Elenco.length());

        Btn->setVisible(Index < Elenco.length());

        if (Index < Elenco.length())
        {
            GTurni *T = Elenco.at(Index);

            L_Desc->setText(T->Loc_Partenza);

            Btn->setText   (T->Data_Partenza.toString("HH:mm"));

            Btn->setProperty("TripID", T->TripID);
        }
    }
}

void frmSelectDuty::on_cmd_Duty()
{
    QPushButton* buttonSender = qobject_cast<QPushButton*>(sender());

    qDebug() << buttonSender->text();

    if (ViewMode==eViewMode::Duty)
    {
        ShowTrip(buttonSender->text());
    }
    else
    {
        if (ViewMode==eViewMode::Trip)
        {
            QString TripID = buttonSender->property("TripID").toString();

            qDebug() << TripID;

            emit NewTrips(CurrentDuty, TripID);
        }
    }
}

void frmSelectDuty::on_cmd_Back_clicked()
{
    if (Ptr == 0)
    {
        if (ViewMode==eViewMode::Trip)
            ShowDuty();
    }
    else
    {
        Ptr -= (nSlot / 2);

        if (ViewMode==eViewMode::Trip)
            ShowTrip(CurrentDuty);

        if (ViewMode==eViewMode::Duty)
            ShowDuty();
    }
}

void frmSelectDuty::on_cmd_Next_clicked()
{
    Ptr += (nSlot / 2);

    if (ViewMode==eViewMode::Trip)
        ShowTrip(CurrentDuty);

    if (ViewMode==eViewMode::Duty)
        ShowDuty();
}

void frmSelectDuty::ResizeFont( QLabel *Lab, QString Text)
{
    QFont Font = Lab->font();

    QRect availablerect = Lab->rect();

    QRect textrect   = QFontMetrics(Font).boundingRect(Text);

    if(!textrect.isValid() || !availablerect.isValid()) return; //not initalized yet, return

    float factorh = availablerect.width() / (float)textrect.width();
    float factorw = availablerect.height() / (float)textrect.height();
    float factor = std::min(factorh, factorw);

    if (factor < 0.95 || factor > 1.05)
    {
      float fontSize = Font.pointSizeF() * factor;

      QString Style = QString("color: rgb(255, 255, 255); background-color: rgb(0, 170, 255); font: %1pt 'MS Shell Dlg 2';").arg((int)fontSize);

      Lab->setStyleSheet(Style);
      Lab->setText(Text);
    }
}

void frmSelectDuty::on_cmd_Close_clicked()
{
    close();
}
