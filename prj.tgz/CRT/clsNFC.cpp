#include "clsNFC.h"
#include "global.h"

#include <QTimeZone>
#include <QDebug>
#include <QString>

#define PN532_PREAMBLE                (0x00)
#define PN532_STARTCODE1              (0x00)
#define PN532_STARTCODE2              (0xFF)
#define PN532_POSTAMBLE               (0x00)

#define PN532_HOSTTOPN532             (0xD4)
#define PN532_PN532TOHOST             (0xD5)

#define PN532_ACK_WAIT_TIME           (1000)  // ms, timeout of waiting for ACK

#define PN532_INVALID_ACK             (-1)
#define PN532_TIMEOUT                 (-2)
#define PN532_INVALID_FRAME           (-3)
#define PN532_NO_SPACE                (-4)

#define REVERSE_BITS_ORDER(b)         b = (b & 0xF0) >> 4 | (b & 0x0F) << 4; \
                                      b = (b & 0xCC) >> 2 | (b & 0x33) << 2; \
                                      b = (b & 0xAA) >> 1 | (b & 0x55) << 1


// PN532 Commands
#define PN532_COMMAND_DIAGNOSE              (0x00)
#define PN532_COMMAND_GETFIRMWAREVERSION    (0x02)
#define PN532_COMMAND_GETGENERALSTATUS      (0x04)
#define PN532_COMMAND_READREGISTER          (0x06)
#define PN532_COMMAND_WRITEREGISTER         (0x08)
#define PN532_COMMAND_READGPIO              (0x0C)
#define PN532_COMMAND_WRITEGPIO             (0x0E)
#define PN532_COMMAND_SETSERIALBAUDRATE     (0x10)
#define PN532_COMMAND_SETPARAMETERS         (0x12)
#define PN532_COMMAND_SAMCONFIGURATION      (0x14)
#define PN532_COMMAND_POWERDOWN             (0x16)
#define PN532_COMMAND_RFCONFIGURATION       (0x32)
#define PN532_COMMAND_RFREGULATIONTEST      (0x58)
#define PN532_COMMAND_INJUMPFORDEP          (0x56)
#define PN532_COMMAND_INJUMPFORPSL          (0x46)
#define PN532_COMMAND_INLISTPASSIVETARGET   (0x4A)
#define PN532_COMMAND_INATR                 (0x50)
#define PN532_COMMAND_INPSL                 (0x4E)
#define PN532_COMMAND_INDATAEXCHANGE        (0x40)
#define PN532_COMMAND_INCOMMUNICATETHRU     (0x42)
#define PN532_COMMAND_INDESELECT            (0x44)
#define PN532_COMMAND_INRELEASE             (0x52)
#define PN532_COMMAND_INSELECT              (0x54)
#define PN532_COMMAND_INAUTOPOLL            (0x60)
#define PN532_COMMAND_TGINITASTARGET        (0x8C)
#define PN532_COMMAND_TGSETGENERALBYTES     (0x92)
#define PN532_COMMAND_TGGETDATA             (0x86)
#define PN532_COMMAND_TGSETDATA             (0x8E)
#define PN532_COMMAND_TGSETMETADATA         (0x94)
#define PN532_COMMAND_TGGETINITIATORCOMMAND (0x88)
#define PN532_COMMAND_TGRESPONSETOINITIATOR (0x90)
#define PN532_COMMAND_TGGETTARGETSTATUS     (0x8A)

#define PN532_RESPONSE_INDATAEXCHANGE       (0x41)
#define PN532_RESPONSE_INLISTPASSIVETARGET  (0x4B)


#define PN532_MIFARE_ISO14443A              (0x00)

// Mifare Commands
#define MIFARE_CMD_AUTH_A                   (0x60)
#define MIFARE_CMD_AUTH_B                   (0x61)
#define MIFARE_CMD_READ                     (0x30)
#define MIFARE_CMD_WRITE                    (0xA0)
#define MIFARE_CMD_WRITE_ULTRALIGHT         (0xA2)
#define MIFARE_CMD_TRANSFER                 (0xB0)
#define MIFARE_CMD_DECREMENT                (0xC0)
#define MIFARE_CMD_INCREMENT                (0xC1)
#define MIFARE_CMD_STORE                    (0xC2)

// FeliCa Commands
#define FELICA_CMD_POLLING                  (0x00)
#define FELICA_CMD_REQUEST_SERVICE          (0x02)
#define FELICA_CMD_REQUEST_RESPONSE         (0x04)
#define FELICA_CMD_READ_WITHOUT_ENCRYPTION  (0x06)
#define FELICA_CMD_WRITE_WITHOUT_ENCRYPTION (0x08)
#define FELICA_CMD_REQUEST_SYSTEM_CODE      (0x0C)

// Prefixes for NDEF Records (to identify record type)
#define NDEF_URIPREFIX_NONE                 (0x00)
#define NDEF_URIPREFIX_HTTP_WWWDOT          (0x01)
#define NDEF_URIPREFIX_HTTPS_WWWDOT         (0x02)
#define NDEF_URIPREFIX_HTTP                 (0x03)
#define NDEF_URIPREFIX_HTTPS                (0x04)
#define NDEF_URIPREFIX_TEL                  (0x05)
#define NDEF_URIPREFIX_MAILTO               (0x06)
#define NDEF_URIPREFIX_FTP_ANONAT           (0x07)
#define NDEF_URIPREFIX_FTP_FTPDOT           (0x08)
#define NDEF_URIPREFIX_FTPS                 (0x09)
#define NDEF_URIPREFIX_SFTP                 (0x0A)
#define NDEF_URIPREFIX_SMB                  (0x0B)
#define NDEF_URIPREFIX_NFS                  (0x0C)
#define NDEF_URIPREFIX_FTP                  (0x0D)
#define NDEF_URIPREFIX_DAV                  (0x0E)
#define NDEF_URIPREFIX_NEWS                 (0x0F)
#define NDEF_URIPREFIX_TELNET               (0x10)
#define NDEF_URIPREFIX_IMAP                 (0x11)
#define NDEF_URIPREFIX_RTSP                 (0x12)
#define NDEF_URIPREFIX_URN                  (0x13)
#define NDEF_URIPREFIX_POP                  (0x14)
#define NDEF_URIPREFIX_SIP                  (0x15)
#define NDEF_URIPREFIX_SIPS                 (0x16)
#define NDEF_URIPREFIX_TFTP                 (0x17)
#define NDEF_URIPREFIX_BTSPP                (0x18)
#define NDEF_URIPREFIX_BTL2CAP              (0x19)
#define NDEF_URIPREFIX_BTGOEP               (0x1A)
#define NDEF_URIPREFIX_TCPOBEX              (0x1B)
#define NDEF_URIPREFIX_IRDAOBEX             (0x1C)
#define NDEF_URIPREFIX_FILE                 (0x1D)
#define NDEF_URIPREFIX_URN_EPC_ID           (0x1E)
#define NDEF_URIPREFIX_URN_EPC_TAG          (0x1F)
#define NDEF_URIPREFIX_URN_EPC_PAT          (0x20)
#define NDEF_URIPREFIX_URN_EPC_RAW          (0x21)
#define NDEF_URIPREFIX_URN_EPC              (0x22)
#define NDEF_URIPREFIX_URN_NFC              (0x23)

#define PN532_GPIO_VALIDATIONBIT            (0x80)
#define PN532_GPIO_P30                      (0)
#define PN532_GPIO_P31                      (1)
#define PN532_GPIO_P32                      (2)
#define PN532_GPIO_P33                      (3)
#define PN532_GPIO_P34                      (4)
#define PN532_GPIO_P35                      (5)


QT_USE_NAMESPACE

clsNfc::clsNfc(QObject *parent) : QThread(parent), waitTimeout(0), quit(false)
{
    RxBuffer.resize(BufSize);

    command = 0;
}

clsNfc::~clsNfc()
{
    mutex.lock();
    quit = true;
    mutex.unlock();
    wait();
}

void clsNfc::startSlave(const QString &portName, int waitTimeout )
{
    QMutexLocker locker(&mutex);

    this->portName    = portName;
    this->waitTimeout = waitTimeout;

    LastUpdate = QTime::currentTime();

    if (!isRunning())
        start();
}

void clsNfc::StopThread()
{
    mutex.lock();
    quit = true;
    mutex.unlock();
}

void clsNfc::run()
{
    bool currentPortNameChanged = false;

    mutex.lock();

    QString currentPortName;

    if (currentPortName != portName)
    {
        currentPortName = portName;
        currentPortNameChanged = true;
    }

    int currentWaitTimeout = waitTimeout;

    mutex.unlock();

    while (!quit)
    {
        if (currentPortNameChanged)
        {
            currentPortNameChanged = false;

            serial.close();

            qDebug() << "Open Device: " << currentPortName;

            serial.setPortName(currentPortName);
            serial.setBaudRate(115200);
            serial.setDataBits(QSerialPort::Data8);
            serial.setParity(QSerialPort::NoParity);

            if (!serial.open(QIODevice::ReadWrite))
            {
                QString Err = QString("Can't open %1, error code %2").arg(portName).arg(serial.error());
                emit error(Err);
                return;
            }
            else
            {
                wakeup();

                getFirmwareVersion();
            }
        }
    }

    serial.close();
}

/******************************************************************/
void clsNfc::Automa(QByteArray Buffer)
/******************************************************************/
{
    for(int i=0; i<Buffer.count(); ++i)
    {
        quint8 Rx = Buffer.at(i);
    }
}

/******************************************************************/
void clsNfc::wakeup()
/******************************************************************/
{
    writeByte(0x55);
    writeByte(0x55);
    writeByte(0x00);
    writeByte(0x00);
    writeByte(0x00);

    if(serial.bytesAvailable() > 0)
        serial.readAll();
}

/******************************************************************/
void clsNfc::writeByte(quint8 Dato)
/******************************************************************/
{
    QByteArray Buf;
    Buf[0] = Dato;

    char *S = (char*)&Dato;

    serial.write(S, 1);
    serial.waitForBytesWritten(1000);
}

/******************************************************************/
qint8 clsNfc::writeCommand(const quint8 *header, quint8 hlen, const quint8 *body, quint8 blen)
/******************************************************************/
{
    if(serial.bytesAvailable() > 0)
        serial.readAll();

    command = header[0];

    writeByte(PN532_PREAMBLE);
    writeByte(PN532_STARTCODE1);
    writeByte(PN532_STARTCODE2);

    quint8 length = hlen + blen + 1;   // length of data field: TFI + DATA

    writeByte(length);
    writeByte(~length + 1);           // checksum of length

    writeByte(PN532_HOSTTOPN532);

    quint8 sum = PN532_HOSTTOPN532;    // sum of TFI + DATA

    serial.write((char*)header, hlen);

    for (quint8 i = 0; i < hlen; i++)
        sum += header[i];

    if (blen != 0)
    {
        serial.write((char*)body, blen);

        for (quint8 i = 0; i < blen; i++)
            sum += body[i];
    }

    quint8 checksum = ~sum + 1;            // checksum of TFI + DATA

    writeByte(checksum);

    writeByte(PN532_POSTAMBLE);

    return readAckFrame();
}

/******************************************************************/
qint8 clsNfc::readAckFrame()
/******************************************************************/
{
    QByteArray PN532_ACK;

    PN532_ACK[0] = 0x00;
    PN532_ACK[1] = 0x00;
    PN532_ACK[2] = 0xFF;
    PN532_ACK[3] = 0x00;
    PN532_ACK[4] = 0xFF;
    PN532_ACK[5] = 0x00;

    QByteArray ackBuf;

    QDateTime T0 = Global::CurrentTime();

    if (serial.bytesAvailable() > 0 )
        ackBuf = serial.readAll();


    do
    {
        if (serial.bytesAvailable() == PN532_ACK.length())
        {
            ackBuf = serial.readAll();
            break;
        }
        else
        {
            quint64 Elapsed = T0.msecsTo(Global::CurrentTime());

            if (Elapsed >= PN532_ACK_WAIT_TIME )
                break;
        }

    } while (true);

    if (ackBuf.length() == 0 )
        return PN532_TIMEOUT;

    if( ackBuf != PN532_ACK )
    {
        return PN532_INVALID_ACK;
    }

    return 0;
}

/******************************************************************/
quint32 clsNfc::getFirmwareVersion(void)
/******************************************************************/
{
    quint8 pn532_packetbuffer[1];

    quint32 response;

    pn532_packetbuffer[0] = PN532_COMMAND_GETFIRMWAREVERSION;

    if (writeCommand(pn532_packetbuffer, 1))
    {
        return 0;
    }

    // read data packet

    qint16 status = readResponse(pn532_packetbuffer, sizeof(pn532_packetbuffer));

    if (0 > status) {
        return 0;
    }

    response = (quint32)pn532_packetbuffer[0];
    response <<= 8;
    response |= (quint32)pn532_packetbuffer[1];
    response <<= 8;
    response |= (quint32)pn532_packetbuffer[2];
    response <<= 8;
    response |= (quint32)pn532_packetbuffer[3];

    return response;
}

/******************************************************************/
qint16 clsNfc::readResponse(quint8 *buf, quint8 len, quint16 timeout)
/******************************************************************/
{
    quint8 tmp[3];

    return 0;

#if false

    /** Frame Preamble and Start Code */

    if(receive(tmp, 3, timeout)<=0){
        return PN532_TIMEOUT;
    }
    if(0 != tmp[0] || 0!= tmp[1] || 0xFF != tmp[2]){
        DMSG("Preamble error");
        return PN532_INVALID_FRAME;
    }

    /** receive length and check */
    uint8_t length[2];
    if(receive(length, 2, timeout) <= 0){
        return PN532_TIMEOUT;
    }
    if( 0 != (uint8_t)(length[0] + length[1]) ){
        DMSG("Length error");
        return PN532_INVALID_FRAME;
    }
    length[0] -= 2;
    if( length[0] > len){
        return PN532_NO_SPACE;
    }

    /** receive command byte */
    uint8_t cmd = command + 1;               // response command
    if(receive(tmp, 2, timeout) <= 0){
        return PN532_TIMEOUT;
    }
    if( PN532_PN532TOHOST != tmp[0] || cmd != tmp[1]){
        DMSG("Command error");
        return PN532_INVALID_FRAME;
    }

    if(receive(buf, length[0], timeout) != length[0]){
        return PN532_TIMEOUT;
    }
    uint8_t sum = PN532_PN532TOHOST + cmd;
    for(uint8_t i=0; i<length[0]; i++){
        sum += buf[i];
    }

    /** checksum and postamble */
    if(receive(tmp, 2, timeout) <= 0){
        return PN532_TIMEOUT;
    }
    if( 0 != (uint8_t)(sum + tmp[0]) || 0 != tmp[1] ){
        DMSG("Checksum error");
        return PN532_INVALID_FRAME;
    }

    return length[0];
#endif
}

