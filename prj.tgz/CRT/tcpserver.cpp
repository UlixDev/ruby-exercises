#include "tcpserver.h"

TcpServer::TcpServer(QObject *parent) : QTcpServer(parent)
{
}

void TcpServer::startServer()
{
    int port = 3000;

    if(!this->listen(QHostAddress::Any, port))
    {
        qDebug() << QString("Error listening on port %1").arg(port);
    }
}

void TcpServer::incomingConnection(qintptr socketDescriptor)
{
    TcpClientMan *Client = new TcpClientMan(socketDescriptor, 0);

    connect(Client, SIGNAL(finished()), Client, SLOT(deleteLater()));

    connect(Client, SIGNAL(MessageReceived(int, QByteArray)), this, SLOT(MessageReceived(int, QByteArray)), Qt::DirectConnection);

    connect( this, SIGNAL(ForwardMessage(int, QString)), Client, SLOT(sendMsgDelayed(int,QString)), Qt::QueuedConnection);

    Client->start();
}

void TcpServer::MessageReceived(int ClientID, QByteArray Message)
{
    emit CommandReceived(ClientID, Message);
}

void TcpServer::SendMessage(int ClientID, QByteArray Data)
{
    QByteArray sData = QString(Data).toLocal8Bit();

    emit ForwardMessage(ClientID, sData);
}

