// moved
#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>

#include <QDebug>
#include <QDateTime>

#include "dbmanager.h"
#include "logger.h"
#include "global.h"

#include <QCoreApplication>
#include <QThread>

DBManager::DBManager(QObject *parent, QString ConnectionName)
{
    this->ConnectioName = ConnectionName;
}

QSqlDatabase DBManager::GetDatabase()
{
    QString DBPath = QCoreApplication::applicationDirPath() + "/XTracker.db";

    //QString DBPath = QString(":memory:");

    //auto name = "my_db_" + QString::number((quint64)QThread::currentThread(), 16);

    auto name = ConnectioName;

    if(QSqlDatabase::contains(name))
    {
        return QSqlDatabase::database(name);
    }
    else
    {
        auto db = QSqlDatabase::addDatabase( "QSQLITE", name);

        db.setDatabaseName(DBPath);

        return db;
    }
}

bool DBManager::Open()
{
    bool Ret = false;

    QStringList list = QSqlDatabase::drivers();

    QStringList::Iterator it = list.begin();

    while( it != list.end() )
    {
        ++it;
    }

    if(QSqlDatabase::isDriverAvailable("QSQLITE"))
    {
        m_db = GetDatabase();

        if (!m_db.isOpen())
        {
            qDebug() << "Open database " << m_db.connectionName();

            Ret = m_db.open();
        }

        Ret = m_db.isOpen();

        DBaseOk = Ret;
    }

    return Ret;
}

bool DBManager::Init()
{
    bool Ret = false;

    if (m_db.isOpen())
    {
        Logger::Info( "DBM", "Init database");

        if ( !m_db.tables().contains( QLatin1String("Config") ))
            CreateTable_Config();

        if ( !m_db.tables().contains( QLatin1String("TurniMacchina") ))
            CreateTable_TurniMacchina();

        if ( !m_db.tables().contains( QLatin1String("Repo") ))
            CreateTable_Repo();

        if ( !m_db.tables().contains( QLatin1String("Store") ))
            CreateTable_Store();

        if ( !m_db.tables().contains( QLatin1String("Trips") ))
            CreateTable_Trips();

        if ( !m_db.tables().contains( QLatin1String("Vestizione") ))
            CreateTable_Vestizione();

        if ( !m_db.tables().contains( QLatin1String("StopsTime") ))
            CreateTable_StopsTime();

        if ( !m_db.tables().contains( QLatin1String("Stops") ))
            CreateTable_Stops();

        if ( !m_db.tables().contains( QLatin1String("Shape") ))
            CreateTable_Shapes();

        if ( !m_db.tables().contains( QLatin1String("Routes") ))
            CreateTable_Routes();

        if ( !m_db.tables().contains( QLatin1String("Payload") ))
            CreateTable_Payload();

        if ( !m_db.tables().contains( QLatin1String("Cartelli") ))
            CreateTable_Cartelli();

        if ( !m_db.tables().contains( QLatin1String("Velette") ))
            CreateTable_Velette();

        // Modify_Table();

        Ret = true;
    }

    return Ret;
}


/*******************************************************************************/
bool DBManager::Modify_Table()
/*******************************************************************************/
{
    QSqlQuery Query;

    QString Sql("ALTER TABLE Stops ADD COLUMN Radius int default 30");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}

/*******************************************************************************/
bool DBManager::CreateTable_Cartelli()
/*******************************************************************************/
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE[Cartelli]("
                "[Codice] ntext,"
                "[Descrizione] ntext,"
                "[Num] ntext,"
                "[Sup] ntext,"
                "[Inf] ntext)");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}

/*******************************************************************************/
bool DBManager::CreateTable_Store()
/*******************************************************************************/
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Store (Param ntext PRIMARY KEY, Valore ntext, Descrizione ntext)");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}

/*******************************************************************************/
bool DBManager::CreateTable_Trips()
/*******************************************************************************/
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Trips ( ID INTEGER PRIMARY KEY AUTOINCREMENT, Route_ID ntext, Service_Id ntext, Trip_Id ntext, Trip_Headsign ntext, Trip_Short_Name ntext, Direction_Id ntext, Block_Id ntext, Shape_Id ntext, Wheelchair_Accessible ntext, Bikes_Allowed ntext, nStop integer )");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}

bool DBManager::CreateTable_Vestizione()
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Vestizione (ID integer NOT NULL PRIMARY KEY AUTOINCREMENT, Data date, Seq int, Turno ntext )");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}

bool DBManager::CreateTable_StopsTime()
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE StopsTime ( ID integer NOT NULL PRIMARY KEY AUTOINCREMENT, Trip_Id ntext, Stop_Id ntext, Arrival_Time TEXT, Departure_Time TEXT, Stop_Sequence int )");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}


bool DBManager::CreateTable_Stops()
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Stops ( ID integer NOT NULL PRIMARY KEY AUTOINCREMENT, Stop_ID ntext, Stop_Code ntext, Stop_Name ntext, Stop_Desc ntext, Lat single, Lon single, Zone_ID ntext, Location_Type ntext, Stop_Url ntext, Parent_Station ntext, Stop_TimeZone ntext, Wheelchair_Boarding ntext, Stop_Index int, Radius int )");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;

}

bool DBManager::CreateTable_Shapes()
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Shape ( ID integer NOT NULL PRIMARY KEY AUTOINCREMENT, ShapeID ntext, Seq int, Lat single, Lng single, Marker int )");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}


bool DBManager::CreateTable_Routes()
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Routes ( ID integer NOT NULL PRIMARY KEY AUTOINCREMENT, routeId ntext, routeShortName ntext, routeLongName ntext, agencyId ntext, routeDesc ntext, routeUrl ntext, routeColor ntext, routeTextColor ntext, routeType ntext, trips int )");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return true;
}


bool DBManager::CreateTable_Payload()
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Payload (ID INTEGER PRIMARY KEY AUTOINCREMENT, Command ntext, Payload ntext, Done integer)");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;


    return true;
}


bool DBManager::CreateTable_Repo()
{
    QSqlQuery Query(m_db);

    QString Sql("CREATE TABLE Repo ( Object ntext NOT NULL UNIQUE, LastUpdate datetime NOT NULL, Firma ntext, PRIMARY KEY(Object) )");

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;


    return true;
}

bool DBManager::CreateTable_Config()
{
    QSqlQuery Query(m_db);

    Query.prepare("CREATE TABLE Config ("
                    "id INTEGER, "
                    "Param  TEXT NOT NULL UNIQUE PRIMARY KEY,"
                    "Valore TEXT,"
                    "Descr  TEXT)"
                    );

    Query.exec();

    return true;
}

bool DBManager::CreateTable_TurniMacchina()
{
    QSqlQuery Query(m_db);

    Query.prepare("CREATE TABLE [TurniMacchina] ([ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, [DutyID] ntext, [Loc_Partenza] ntext, [Loc_Arrivo] ntext, [Data_Partenza] datetime, [Data_Arrivo] datetime, [Route_ID] ntext, [Route_Long_Name] ntext, [Planned_Length] float, [SingleTrip] bit, [ServiceID] ntext, [ShapeID] ntext, [TripID] ntext , [DutyName] ntext NULL, [BColor] ntext NULL)");

    Query.exec();

    return true;
}

bool DBManager::CreateTable_Velette()
{
    QSqlQuery Query(m_db);

    Query.prepare("CREATE TABLE[Velette]("
        "[ID]       int,"
        "[code]     ntext,"
        "[brandId]  int,"
        "[Logo]     ntext,"
        "[modelId]  int,"
        "[rowTypeId] int,"
        "[panelText] ntext,"
        "[fontId]   int,"
        "[color]    ntext,"
        "[bgColor]  ntext,"
        "[slide]    boolean)" );

    bool Ret = Query.exec();

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text();

    return Ret;
}

/*******************************************************/
int DBManager::GetParam(QString Param, int Default)
/*******************************************************/
{
    int Ret = Default;

    QString Sql = QString("SELECT * FROM Config WHERE Param='%1'").arg(Param);

    QSqlQuery Query(m_db);

    Query.prepare(Sql);

    Query.exec();

    if (Query.next())
    {
        int fieldNo = Query.record().indexOf("Valore");

        QSqlRecord record = Query.record();

        Ret = record.value(fieldNo).toInt();
    }

    return Ret;
}

/*******************************************************/
QString DBManager::GetParam(QString Param, QString Default)
/*******************************************************/
{
    QString Ret = Default;

    QString Sql = QString("SELECT * FROM Config WHERE Param='%1'").arg(Param);

    QSqlQuery Query(m_db);

    Query.prepare(Sql);

    Query.exec();

    if (Query.next())
    {
        int fieldNo = Query.record().indexOf("Valore");

        QSqlRecord record = Query.record();

        Ret = record.value(fieldNo).toString();
    }

    return Ret;
}


/*******************************************************/
bool DBManager::WriteParam(QString Param, int Value)
/*******************************************************/
{
    QString Sql = QString("REPLACE INTO Config (Param, Valore) VALUES('%1', '%2')").arg(Param).arg(Value);

    QSqlQuery Query(m_db);

    return Query.exec(Sql);
}

/*******************************************************/
bool DBManager::WriteParam(QString Param, QString Value)
/*******************************************************/
{
    QString Sql = QString("REPLACE INTO Config (Param, Valore) VALUES('%1', '%2')").arg(Param).arg(Value);

    QSqlQuery Query(m_db);

    bool Ret = Query.exec(Sql);

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return Ret;
}

/*******************************************************/
QSqlQuery DBManager::GetRecord(QString Sql)
/*******************************************************/
{
    QSqlQuery Query(m_db);

    Query.prepare(Sql);

    bool Ret = Query.exec();

    if (!Ret)
        qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;

    return Query;
}

/*******************************************************/
int DBManager::GetIFromName(QSqlQuery Qry, QString Name)
/*******************************************************/
{
    int fieldNo = Qry.record().indexOf(Name);

    QSqlRecord record = Qry.record();

    return record.value(fieldNo).toInt();
}

/*******************************************************/
bool DBManager::GetBFromName(QSqlQuery Qry, QString Name)
/*******************************************************/
{
    int fieldNo = Qry.record().indexOf(Name);

    QSqlRecord record = Qry.record();

    return record.value(fieldNo).toBool();
}

/*******************************************************/
QString DBManager::GetSFromName(QSqlQuery Qry, QString Name)
/*******************************************************/
{
    int fieldNo = Qry.record().indexOf(Name);

    QSqlRecord record = Qry.record();

    QString Ret = record.value(fieldNo).toString();

    return Ret;
}

/*******************************************************/
QDateTime DBManager::GetDFromName(QSqlQuery Qry, QString Name)
/*******************************************************/
{
    int fieldNo = Qry.record().indexOf(Name);

    QSqlRecord record = Qry.record();

    QString A = record.value(fieldNo).toString();

    QDateTime Ret = QDateTime::fromString(A, "yyyy-MM-dd HH:mm:ss");

    return Ret;
}

/*******************************************************/
float DBManager::GetFFromName(QSqlQuery Qry, QString Name)
/*******************************************************/
{
    int fieldNo = Qry.record().indexOf(Name);

    QSqlRecord record = Qry.record();

    float Ret = record.value(fieldNo).toFloat();

    return Ret;
}


/*******************************************************/
bool DBManager::ExecuteQuery(QString Sql )
/*******************************************************/
{
    bool Ret = false;

    if (DBaseOk)
    {
        QSqlQuery Query(m_db);

        Ret = Query.exec(Sql);

        if (!Ret)
            qDebug() << "> Query exec() error." << Query.lastError().text() << Sql;
    }
    else
        qDebug() << "Database is closed";

    return Ret;
}

