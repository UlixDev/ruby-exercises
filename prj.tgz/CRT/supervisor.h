#ifndef SUPERVISOR_H
#define SUPERVISOR_H

#include <QObject>
#include <QThread>

#include "clssimulatore.h"
#include "clspayload.h"
#include "Positioning/qgeocoordinate.h"
#include "clsnavigator.h"
#include "tcpserver.h"
#include "json.h"


class Supervisor : public QThread
{
    Q_OBJECT

public:
    explicit Supervisor(QObject *parent = nullptr);

    void Start();

private slots:

    void DataReady      ( GpsData Data );
    void CommandReceived( int ClientID, QByteArray Datagram );
    void BroacastMessage( int ClientID, QByteArray Datagram );
    void BroacastMessage( int ClientID, QString    Datagram );

signals:

    void NewTrip(QString DutyID, QString TripID);
    void NewLoc (GpsData Loc);
    void SendMessage( int ClientID, QByteArray Data);
    void LocReceived (GpsData Loc);

private:

    void SendProcessStatus( QString Status );

    clsNavigator  *Nav;
    clsPayload    *ThPay;
    QDateTime      LastTrackSendTime;
    QDateTime      LastDutyCheck;
    QGeoCoordinate  LastPosition;
    TcpServer     *TCPServer;
    clsGtfs       *Gtfs;

    bool oDoor = false;
};

#endif // SUPERVISOR_H
