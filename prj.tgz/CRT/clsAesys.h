// Moved
#ifndef AESYS_H
#define AESYS_H

#include <QMutex>
#include <QThread>
#include <QTime>
#include <QtSerialPort/QSerialPort>
#include <QList>

#include "logger.h"
#include "dbmanager.h"
#include "global.h"
#include "togglepin.h"

#include "clsDisplayAesys.h"

class clsAesys : public QThread
{
    Q_OBJECT

public:

    explicit clsAesys(QObject *parent = nullptr);
    ~clsAesys();

    // Moved in enumerations.h in the new prj
    enum eMargin
    {
        SX,
        DX,
        CX
    };

    // Already defined in enumerations.h in the new prj
    enum eStatus
    {
        Init = 2,
        Up   = 1,
        Down = 0
    };

    Q_ENUM(eStatus)

    void startSlave(const QString &portName, int Speed);
    void run() Q_DECL_OVERRIDE;
    void StopThread();
    void qSleep      (int ms);
    void Send_Command(QString Cmd, QString Param, int TimeOut);
    void SetPanel    (QString Num, QString NumFore, QString NumBack, QString Sup, QString SupFore, QString SupBack, QString Inf, QString InfFore, QString InfBack);
    void LoopPannelli();
    void Config(QList<clsDisplayAesys *> *Pannelli);

    QByteArray  BuildMessage(QString Dest, QString OpCode, QString Num, QString Sup, QString Inf, QString FC1, QString FC2, QString FC3);
    QByteArray  CopyTo      (QString Source, QByteArray Buffer, int Ptr);

    int     TipoPannello;
    int     Modello;
    int     Brand;
    eStatus Status;

    TogglePin    *Enable485;

    QList<clsDisplayAesys *> *Pannelli;

signals:

    void request    (const QString &s);
    void error      (const QString &s);
    void timeout    (const QString &s);
    void DataReady  ();
    void Success    ();
    void SignalLog  (quint32 Event, QString Msg);

private:

    QString     portName;
    int         waitTimeout;
    QMutex      mutex;
    bool        quit;
    int         Speed;

    void Automa (QByteArray Buffer);

    bool   RxErr      = false;
    int    RxPtr      = 0;
    int    Step       = 0;

    QByteArray   RxBuffer;

    QSerialPort *Rs485;
    QSerialPort serial;

    DBManager   *DBase;

    /************************/

public:

    bool   InitDevice;

public slots:

private slots:

    void ProcessCommand      (QString Command);

signals:

    void EndTransmission();
};

#endif
