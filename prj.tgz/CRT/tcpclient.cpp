#include "tcpclient.h"
#include "global.h"

#include <QThread>
#include <QTimer>
#include <QSignalSpy>

TcpClient::TcpClient(QObject *parent) : QThread(parent), Quit(false)
{

}

/*********************************************************/
TcpClient::~TcpClient()
/*********************************************************/
{
    Quit = true;

    wait();
}

/*********************************************************/
void TcpClient::StartConnection(QString IP, int Port)
/*********************************************************/
{
    this->RemoteIP = IP;
    this->RemotePort = Port;

    if (Socket == nullptr)
    {
        Socket = new QTcpSocket();

        connect(Socket, SIGNAL(readyRead()), this, SLOT( onReadyRead() ));

        connect(Socket, SIGNAL(disconnected()), this, SLOT (onDisconnected()));

        connect(Socket, SIGNAL(connected()), this, SLOT (onConnected()));

        connect(Socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(onError(QAbstractSocket::SocketError)));
    }

    if (Socket != nullptr)
    {
        qDebug() << "Start connection " << RemoteIP << " port " << RemotePort;

        Socket->connectToHost(QHostAddress(RemoteIP), RemotePort);

        if (!isRunning())
            start();
    }
}

/*********************************************************/
void TcpClient::StartThread()
/*********************************************************/
{
    Quit = false;

    if (!isRunning())
        start();
}

/*********************************************************/
void TcpClient::StopThread()
/*********************************************************/
{
    Quit = true;
}

/*************************************/
void TcpClient::run()
/*************************************/
{
    qDebug() << "Start TCP client";

    while (!Quit)
    {

        qSleep(10);
    }
}

/*************************************/
void TcpClient::onError(QAbstractSocket::SocketError Error)
/*************************************/
{
    int WTime = 5000;

    qDebug() << "Error: " << this->RemoteIP << " " << Socket->errorString();

    switch (Error)
    {
    case QAbstractSocket::AddressInUseError:
        WTime = 60000;
        break;
    case QAbstractSocket::ConnectionRefusedError:
        WTime = 5000;
        break;
    case QAbstractSocket::HostNotFoundError:
        WTime = 10000;
        break;
    case QAbstractSocket::RemoteHostClosedError:
        WTime = 1000;
        break;
    default:
        break;
    }

    Socket->abort();
    Socket->close();

    QTimer::singleShot(WTime, this, SLOT(Reconnect()));
}

/*************************************/
void TcpClient::onReadyRead()
/*************************************/
{
    RxBuffer = Socket->readAll();

    if (EuroPending)
    {
        for (int j=0; j<RxBuffer.length(); j++)
            EuroBuf[EuroPtr++] = RxBuffer[j];

        if (EuroPtr == EuroRxWait)
        {
            EuroPending = false;

            emit Signal_EuroDataReceived();
        }
    }
    else
    {
        emit Signal_DataReceived(RxBuffer);

        qDebug() << "Rx: " << RxBuffer;
    }
}

/*************************************/
void TcpClient::onConnected()
/*************************************/
{
    qDebug() << "Connected";
}

/*************************************/
void TcpClient::onDisconnected()
/*************************************/
{
    qDebug() << "Disconnected";

    //TCPClient->abort();
    //TCPClient->close();
    //QTimer::singleShot(1000, this, SLOT(Reconnect()));
}
/*************************************/
void TcpClient::Reconnect()
/*************************************/
{
    StartConnection( RemoteIP, RemotePort );
}

/*************************************/
QAbstractSocket::SocketState TcpClient::GetState()
/*************************************/
{
    return Socket->state();
}

/*************************************/
int TcpClient::SendMessage(QString Message, int Len, int Timeout)
/*************************************/
{
    int Ret = 0;

    if (Socket != nullptr)
    {
        QAbstractSocket::SocketState Stato = Socket->state();

        if (Stato==QAbstractSocket::ConnectedState)
        {
            Ret = Socket->write( Message.toLocal8Bit(), Len );

            Socket->waitForBytesWritten(1000);

            qDebug() << "Send TCP Message " << Message;

            if (Timeout > 0)
            {
                QSignalSpy Spy ( this, SIGNAL(Signal_DataReceived(QByteArray)));

                bool Ok = Spy.wait(Timeout);

                if (Ok)
                    Ret = RxBuffer.length();
                else
                    Ret = -3;
            }
        }
        else
            Ret = -2;
    }
    else
        Ret = -1;

    return Ret;
}

/*************************************/
int TcpClient::Eurotech_SendMessage(QString Message, int Len, int RxLen, int Timeout)
/*************************************/
{
    int Ret = 0;

    if (Socket != nullptr)
    {
        QAbstractSocket::SocketState Stato = Socket->state();

        if (Stato==QAbstractSocket::ConnectedState)
        {
            EuroPtr     = 0;
            EuroRxWait  = RxLen;
            EuroPending = true;

            Ret = Socket->write( Message.toLocal8Bit(), Len );

            Socket->waitForBytesWritten(1000);

            qDebug() << "Send TCP Message " << Message;

            if (Timeout > 0)
            {
                QSignalSpy Spy ( this, SIGNAL(Signal_EuroDataReceived()));

                bool Ok = Spy.wait(Timeout);

                if (Ok)
                    Ret = EuroBuf.length();
                else
                    Ret = -3;
            }
        }
        else
            Ret = -2;
    }
    else
        Ret = -1;

    return Ret;
}


/**************************************/
void TcpClient::qSleep(int ms)
/**************************************/
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000 * 1000 };
    nanosleep(&ts, nullptr);
}
