// Moved to RideManager.
// Other classes moved to types folder
// Check for clsWinner class
#ifndef CLSNAVIGATOR_H
#define CLSNAVIGATOR_H

#include <QObject>
#include <QThread>
#include <QMutex>
#include <QTcpSocket>

#include "Positioning/qgeocoordinate.h"
#include "clsgtfs.h"
#include "clsbusinfo.h"
#include "clsforecast.h"
#include "clssimulatore.h"

class clsWinner;
class clsClass;

class clsNavigator : public QThread
{
    Q_OBJECT

public:

    explicit clsNavigator(QObject *parent = nullptr);

    ~clsNavigator();

    void run() Q_DECL_OVERRIDE;

    // Moved to enumerations.h in the new prj
    enum eNavState
    {
        Waiting = 0,
        Navigation,
        Lost,
        InDeposito,
        AttesaPartenza,
        FineCorsa,
        FuoriServizio,
        Apprendimento

    };
    Q_ENUM(eNavState)

    enum eDutyType
    {
        OPR,
        CNT,
        BRD
    };
    Q_ENUM(eDutyType)

    eNavState       NavState = eNavState::FuoriServizio;
    eNavState      oNavState = eNavState::FuoriServizio;

    clsForecast    *Forecast;
    clsBusInfo     *BusInfo;

private:

    int     Localize            ( int FirstPoint, QGeoCoordinate Loc);
    void    BuildMessage        (QGeoCoordinate Loc, clsBusInfo *BusInfo);
    QString SetNavigationData(QString DutyID, QString TripID );
    QString FindTrip            ( QMap <QString,GTurni*> *Turni, QString TurnoMacchina, eDutyType DutyType );
    void    SendEvent           (QString Evento, QString StopID , double Lat, double Lng);

    QGeoCoordinate   CurrentPosition;
    QGeoCoordinate   Deposito;

    QDateTime       LastStateChange = QDateTime();

    QDateTime       LastMeterOk = QDateTime();
    QDateTime       LastLocalizationTime = QDateTime();
    QDateTime       LastForecast = QDateTime();
    QDateTime       InizioSosta = QDateTime();

    QList<GTrack*>          *CurTrip;

    QMap <QString,GStops*>  *CurStops;

    clsGtfs *GTFS;

    QMutex  ChangeTrip;
    QMutex  ChangeLoc;

    bool    FL_NewPosition  = false;
    bool    FL_NewTrip      = true;
    bool    FL_Cap_Arm      = false;

    int     CurrentPalina   = -1;
    float   LastMetri       = 0;
    float   OldMetri        = 0;
    int     PositiveLoc     = 0;
    int     Last_iNode_Ok   = 0;
    int     Counter_iNodeOk = 0;
    int     LastGoodPoint   = -1;
    int     LastLocalizationOdo  = 0;
    int     FirstPoint      = 0;

    QString RouteID;
    //QString DutyID;
    QString DriverID;

signals:

    void SendMessage    ( int CliendID, QByteArray Data);
    void BusInfoUpdated ( clsBusInfo *Bus );

public slots:

    void NewPosition(QGeoCoordinate Coord);
    void NewTrips   (QString DutyID, QString TripID);
};

// move inside clsWinner
class clsClass
{
public:

    int    Node;
    double Value;
    double DistPrec;
    double DistNext;

    clsClass(int Node, double Value, double DistPrec, double DistNext)
    {
        this->Node    = Node;
        this->Value    = Value;
        this->DistPrec = DistPrec;
        this->DistNext = DistNext;
    }
};


class clsWinner
{
public:

    int MaxWin = 10;

    QList<clsClass> *Win = new QList<clsClass>();

    clsWinner()
    {
    }

    void Push(double Value, int Node, double DistPrec, double DistNext)
    {
        if (Win->count() > 0)
        {
            if (Value <= Win->at(0).Value)
                Win->insert(0, clsClass(Node, Value, DistPrec, DistNext));
        }
        else
            Win->append(clsClass(Node, Value, DistPrec, DistNext));

        if (Win->count() > MaxWin)
            Win->removeAt(Win->count() - 1);
    }
};

#endif // CLSNAVIGATOR_H
