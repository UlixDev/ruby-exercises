//moved to Converter class
#ifndef CLSTOOLS_H
#define CLSTOOLS_H

#include <QString>


class clsTools
{

public:

    clsTools();

    static int ConvertMTime2Sec( QString MTime );
};

#endif // CLSTOOLS_H
