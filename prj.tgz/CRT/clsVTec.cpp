#include "clsVTec.h"
#include "json.h"
#include <QtMath>
#include "global.h"

using QtJson::JsonObject;
using QtJson::JsonArray;

clsVTec::clsVTec(QObject *parent) : QThread(parent), Quit(false)
{
    this->Port = 4450;

    this->IP   = "192.168.1.231";

    Status = Init;

    LastPoll = Global::CurrentTime();

    JS = "";
}

/*********************************************************/
clsVTec::~clsVTec()
/*********************************************************/
{
    Quit = true;

    wait();
}

/*********************************************************/
void clsVTec::StopThread()
/*********************************************************/
{
    Quit = true;
}

/*********************************************************/
void clsVTec::Config(QString IP, int Port, int ID )
/*********************************************************/
{
    this->IP   = IP;
    this->Port = Port;
    this->ID   = ID;

    VTecClient = new TcpClient(this);

    VTecClient->StartConnection(IP, Port);

    BuildRequest(true, true);
}
/*********************************************************/
void clsVTec::BuildRequest(bool DesStatus, bool Ref)
/*********************************************************/
{
    QVariantMap Buf;

    bool Ok = false;

    double Lat = Global::Posizione.latitude();
    double Lng = Global::Posizione.longitude();

    Buf["TimeStamp"] = Global::CurrentTime().toString("yyyy-MM-dd HH:mm:ss.000Z");
    Buf["Action"]    = 1;
    Buf["VTecMode"]  = DesStatus ? 1 : 0;
    Buf["TripID"]    = "";
    Buf["DutyID"]    = "";
    Buf["RouteID"]   = "";
    Buf["StopID"]    = "";
    Buf["Mezzo"]     = Global::Mezzo;
    Buf["Lat"]       = (double)Lat;
    Buf["Lng"]       = (double)Lng;

    QtJson::setPrettySerialize(false);

    JS  = QtJson::serialize( Buf, Ok);

    if (!Ok)
        JS = "";

    Refresh = Ref;
}

/*******************************************/
void clsVTec::run()
/*******************************************/
{
    qDebug() << "Start thread VTec IP :" << IP;

    while (!Quit)
    {
        QDateTime Now = Global::CurrentTime();

        bool OkSend = (fabs(Now.msecsTo(LastPoll)) >= 10000);

        if ( OkSend || Refresh )
        {
            if (VTecClient->GetState() == QAbstractSocket::SocketState::ConnectedState)
            {
                LastPoll = Now;

                Refresh = false;

                if (ID==1)
                    BuildRequest(Global::EnableVTec1, false);
                else
                    BuildRequest(Global::EnableVTec2, false);

                qDebug() << "TX VTec:" << JS;

                if (JS.length() > 0)
                {
                    int Ret = VTecClient->SendMessage( JS + "\r", JS.length() + 1, 3000);

                    if (Ret > 0)
                    {
                        QVariantMap Resp = QVariant(QtJson::parse(VTecClient->RxBuffer)).toMap();

                        Status = Resp["Status"].isValid() ? Up : Down;

                        if (Status==Up)
                        {
                            VTecMode   = Resp["Status"    ].toInt();
                            CounterPar = Resp["CounterPar"].toInt();
                            CounterTot = Resp["CounterTot"].toInt();
                        }
                    }
                    else
                        Status = Down;

                    qDebug() << "RX VTec:" << VTecClient->RxBuffer << " Status = " << Status;
                }
            }
            else
                Status = Init;
        }

        qSleep(250);
    }
}

/**************************************/
void clsVTec::qSleep(int ms)
/**************************************/
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000 * 1000 };
    nanosleep(&ts, nullptr);
}
