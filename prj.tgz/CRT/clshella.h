#ifndef CLSHELLA_H
#define CLSHELLA_H

#include <QObject>
#include <QDateTime>
#include <QUdpSocket>
#include <QThread>
#include "dbmanager.h"

enum eDoorStatus
{
    Opened,
    Closed,
    Unknow
};

class HellaInfo;

class clsHella : public QThread
{
    Q_OBJECT

public:

    explicit clsHella();
    void     SetHellaGroup(QString IP1, QString IP2, QString IP3);
    bool     SendMessage  (QString Key, QString Command);

    void     run();

private:

    QUdpSocket *Socket = nullptr;
    int HellaPort;

    const QString READ_COUNTER = "VDV2bU";
    const QString READ_DOOR    = "VDV2bW";

    QMap<QString, HellaInfo *> *Lista = nullptr;

    int  oTot      = 0;
    int  PaxOft    = 0;
    bool FL_SalDis = false;
    bool Pending   = false;

    QString DeviceType = "CPX";

    DBManager *DBase;

private slots:

    void Receiver(void);

signals:

    void DoorStatusChanged( eDoorStatus DoorStatus );
    void CpxStatusChanged ( QString DeviceType, QString Name, int Stato);

};

class HellaInfo
{
public:

    QString   IP;
    int       ID;
    int       PassIn;
    int       PassOut;
    QDateTime LastRx;
    QDateTime LastTx;
    QString   Resp;
    QString   StatoPorte;
    int       Stato     = 0;
    int       oStato    = -1;
    QString   DeviceID;

    HellaInfo(QString IP, int ID)
    {
        this->IP = IP;
        this->ID = ID;
        PassIn   = 0;
        PassOut  = 0;
        LastRx   = QDateTime::fromMSecsSinceEpoch(0);
        LastTx   = QDateTime::fromMSecsSinceEpoch(0);
        DeviceID = QString("CPX_%1").arg(ID);
    }
};

#endif // CLSHELLA_H
