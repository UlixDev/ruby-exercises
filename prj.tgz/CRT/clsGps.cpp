#include "clsGps.h"
#include "global.h"

#include <QtSerialPort/QSerialPort>
#include <QTime>
#include <QTimeZone>
#include <QDebug>
#include <QString>

QT_USE_NAMESPACE

clsGps::clsGps(QObject *parent) : QThread(parent), waitTimeout(0), quit(false)
{
    RxBuffer.resize(BufSize);

    LastGpsRx = QDateTime::fromMSecsSinceEpoch(0);
}

clsGps::~clsGps()
{
    mutex.lock();
    quit = true;
    mutex.unlock();
    wait();
}

void clsGps::startSlave(const QString &portName, int waitTimeout )
{
    QMutexLocker locker(&mutex);

    this->portName    = portName;
    this->waitTimeout = waitTimeout;

    LastUpdate = QTime::currentTime();

    if (!isRunning())
        start();
}

void clsGps::StartUDPReceiver()
{
    Socket = new QUdpSocket(this);

    connect(Socket, SIGNAL(readyRead()), this, SLOT(on_UDPReadyRead()));

    Socket->bind(QHostAddress::Any, Port);
}

void clsGps::on_UDPReadyRead()
{
    QByteArray Buffer;

    Buffer.resize(Socket->pendingDatagramSize());

    QHostAddress Sender;

    quint16 SenderPort;

    Socket->readDatagram(Buffer.data(), Buffer.size(), &Sender, &SenderPort);

    Gps_Automa(Buffer);
}

void clsGps::StopThread()
{
    mutex.lock();
    quit = true;
    mutex.unlock();
}

void clsGps::run()
{
    bool currentPortNameChanged = false;

    mutex.lock();

    QString currentPortName;

    if (currentPortName != portName)
    {
        currentPortName = portName;
        currentPortNameChanged = true;
    }

    int currentWaitTimeout = waitTimeout;

    mutex.unlock();

    QSerialPort serial;

    while (!quit)
    {
        if (currentPortNameChanged)
        {
            serial.close();

            qDebug() << "Open Device: " << currentPortName;

            serial.setPortName(currentPortName);
            serial.setBaudRate(9600);
            serial.setDataBits(QSerialPort::Data8);
            serial.setParity(QSerialPort::NoParity);

            if (!serial.open(QIODevice::ReadOnly))
            {
                QString Err = QString("Can't open %1, error code %2").arg(portName).arg(serial.error());
                emit error(Err);
                return;
            }

            currentPortNameChanged = false;
        }

        if (serial.waitForReadyRead(currentWaitTimeout))
        {
            QByteArray Buffer = serial.readAll();

            Gps_Automa(Buffer);
        }
    }

    serial.close();
}

/******************************************************************/
void clsGps::Gps_Automa(QByteArray Buffer)
/******************************************************************/
{
    QString Msg;

    for(int i=0; i<Buffer.count(); ++i)
    {
        quint8 Rx = Buffer.at(i);

        if (Rx=='$')
            RxPtr = 0;

        if (Rx == 0x0D || Rx == 0x0A)
        {
            if (Rx == 0x0D)
            {
                Msg = QString::fromLocal8Bit( RxBuffer, RxPtr );

                Analize(Msg);

                RxPtr = 0;
            }
        }
        else
        {
            if (RxPtr < RxBuffer.length() )
                RxBuffer[RxPtr++] = Rx;
        }
    }
}

/******************************************************************/
bool clsGps::Analize(QString nMea)
/******************************************************************/
{
    if (IsValid(nMea))
    {
        //qDebug() << nMea;

        LastGpsRx = Global::CurrentTime();

        QStringList Token = nMea.split(',');

        if (Token.at(0) == "$GPRMC" || Token.at(0) == "$GNRMC" )
        {
            return ParseGPRMC(nMea);
        }
        else if (Token.at(0) == "$GPGSA" || Token.at(0) == "$GNGSA")
        {
            return ParseGPGSA(nMea);
        }
        else if (Token.at(0) == "$GPGGA" || Token.at(0) == "$GNGGA")
        {
            return ParseGPGGA(nMea);
        }
        else if (Token.at(0) == "$GPVTG" || Token.at(0) == "$GNVTG")
        {
            return ParseGPVTG(nMea);
        }
    }

    return false;
}

/*******************************************************/
bool clsGps::IsValid(QString sentence)
/*******************************************************/
{
    QString Crc   = GetChecksum(sentence);
    QString RxCrc = sentence.mid(sentence.indexOf("*") + 1);

    return  Crc == RxCrc;
}
/*******************************************************/
QString clsGps::GetChecksum(QString nMea)
/*******************************************************/
{
    int Crc = 0;

    for( int j=0; j<nMea.length(); j++)
    {
        QChar Ch = nMea.at(j);

        if (Ch == '$')
        {
        }
        else if (Ch == '*')
        {
            break;
        }
        else
        {
            if (Crc == 0)
            {
                Crc = Ch.toLatin1();
            }
            else
            {
                Crc = Crc ^ Ch.toLatin1();
            }
        }
    }

    return QString("%1").arg(Crc, 2, 16, QChar('0'));
}

/*******************************************************/
bool clsGps::ParseGPVTG(QString Sentence)
/*******************************************************/
{
    QStringList Words = Sentence.split(',');

    if (Words.at(1) != "")
    {
        this->Course = Words.at(1).toFloat();
    }

    if (Words.at(7) != "")
    {
        this->Kmh = Words.at(7).toFloat();
    }

    return true;
}

/*******************************************************/
bool clsGps::ParseGPRMC(QString Sentence)
/*******************************************************/
{
    int UtcHours   = 0;
    int UtcMinutes = 0;
    int UtcSeconds = 0;
    int UtcMilliseconds = 0;

    QStringList Words = Sentence.split(',');

    if (Words.at(3) != "" && Words.at(4) != "" && Words.at(5) != "" && Words.at(6) != "")
    {
        Lat = Words.at(3).toFloat();

        Lat = Normalize(Lat);

        Lng = Words.at(5).toFloat();

        Lng = Normalize(Lng);
    }

    if (Words.at(1) != "")
    {
        UtcHours   = Words.at(1).mid(0, 2).toInt();
        UtcMinutes = Words.at(1).mid(2, 2).toInt();
        UtcSeconds = Words.at(1).mid(4, 2).toInt();
        UtcMilliseconds = 0;

        if (Words.at(1).length() > 7)
        {
            UtcMilliseconds = Words.at(1).mid(6).toFloat() * 1000;
        }

        QDate Today = QDate::currentDate();

        QTime Time = QTime(UtcHours, UtcMinutes, UtcSeconds, UtcMilliseconds);

        SatelliteTime = QDateTime(QDate(Today), QTime(Time)).addSecs(Global::TimeOffset);
    }

    if (Words.at(7) != "")
    {
        Kmh = Words.at(7).toFloat() * KMHPerKnot;
    }

    if (Words.at(8) != "")
    {
        Course = Words.at(8).toFloat();
    }

    if (Lat < 180 && Lng < 180 && Alt < 10000 && Course <= 360)
    {
        Geo.GpsFix = (Words.at(2) == "A");

        Geo.setLatitude (Lat);
        Geo.setLongitude(Lng);
        Geo.setAltitude (Alt);
        Geo.setCourse   (Course);
        Geo.setSpeed    (Kmh);
        Geo.setAccuracy (hDop);
        Geo.setnSat     (nSat);
        Geo.setGpsTime  (SatelliteTime);

        emit OnLocation( Geo );
    }

    return true;
}

/*******************************************************/
bool clsGps::ParseGPGGA(QString Sentence)
/*******************************************************/
{
    int UtcHours   = 0;
    int UtcMinutes = 0;
    int UtcSeconds = 0;
    int UtcMilliseconds = 0;

    QStringList Words = Sentence.split(',');

    if (Words.at(3) != "" && Words.at(5) != "" )
    {
        Lat = QString(Words.at(2)).toDouble();

        Lat = Normalize(Lat);

        Lng = QString(Words.at(4)).toDouble();

        Lng = Normalize(Lng);
    }

    if (Words.at(1) != "")
    {
        UtcHours   = Words.at(1).mid(0, 2).toInt();
        UtcMinutes = Words.at(1).mid(2, 2).toInt();
        UtcSeconds = Words.at(1).mid(4, 2).toInt();
        UtcMilliseconds = 0;

        if (Words.at(1).length() > 7)
        {
            UtcMilliseconds = Words.at(1).mid(6).toFloat() * 1000;
        }

        QDate Today = QDate::currentDate();

        QTime Time = QTime(UtcHours, UtcMinutes, UtcSeconds, UtcMilliseconds);

        SatelliteTime = QDateTime(QDate(Today), QTime(Time)).addSecs(Global::TimeOffset);
    }

    Geo.GpsFix = (Words.at(6) != "0");

    if (Words.at(7) != "")
    {
        nSat = QString(Words.at(7)).toInt();
    }

    if (Words.at(8) != "")
    {
        hDop = QString(Words.at(8)).toDouble();
    }

    if (Words.at(9) != "")
    {
        Alt = QString(Words.at(9)).toDouble();
    }

    Geo.setLatitude (Lat);
    Geo.setLongitude(Lng);
    Geo.setAltitude (Alt);
    Geo.setCourse   (Course);
    Geo.setSpeed    (Kmh);
    Geo.setAccuracy (hDop);
    Geo.setnSat     (nSat);
    Geo.setGpsTime  (SatelliteTime);

    //emit OnLocation( Geo );

    return true;
}

/*******************************************************/
bool clsGps::ParseGPGSA(QString sentence)
/*******************************************************/
{
    bool Ex = false;

    QStringList Words = sentence.split(',');

     if (Words.at(15) != "")
     {
         pDop = Words.at(15).toFloat();
     }
     if (Words.at(16) != "")
     {
         hDop = Words.at(16).toFloat();
     }
     if (Words.at(17) != "")
     {
         vDop = Words.at(17).toFloat();
     }

     Ex = true;

    return Ex;
}

/*****************************************************/
float clsGps::Normalize(float Polar)
/*****************************************************/
{
    int Gradi = (int)(Polar / 100);

    float Secondi = Polar - (Gradi * 100);

    return Gradi + Secondi / 60;
}


