// moved to TCPConnectionManager
#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>
#include <QTcpSocket>
#include <QDebug>
#include <QRunnable>

class TcpClientMan : public QThread
{
    Q_OBJECT

public:
    explicit TcpClientMan(qintptr ID, QObject *parent = 0);

    void run() override;

    QTcpSocket *socket;

    void Init();

signals:
    void error(QTcpSocket::SocketError socketerror);
    void MessageReceived (int ClientID, QByteArray Data);

public slots:
    void    readyRead();
    void    disconnected();
    void    WriteMessage     (int ClientID, QByteArray Data);
    void    WriteMessage2    (const QString &Data);
    void    sendMsgDelayed   (int ClientID, const QString &Data);
    void    SendProcessStatus(QString Status);

private:
    qintptr socketDescriptor;
    QThread *OldThread;

};

#endif // MYTHREAD_H
