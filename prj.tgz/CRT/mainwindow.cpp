#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "frmpannelli.h"
#include "frmselectduty.h"
#include "clswebservice.h"
#include "json.h"
#include "gpio.h"

#include <QSettings>
#include <QMap>
#include <QtMath>
#include <QDir>
#include <QProcess>

using QtJson::JsonObject;
using QtJson::JsonArray;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setWindowFlags(Qt::Widget | Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint );
    setStyleSheet( "" );

    // QWidget#centralwidget{ border-image: url(:/Icone/AMTS_480x272_White.png)};

    QString FileName = QString("%1/Logo.png").arg(QCoreApplication::applicationDirPath());

    QFile File(FileName);

    qDebug() << "****** DEBUG ******** ";
    qDebug() << "****** FABRIZIO 3 ******** ";

    // imposta il logo dell'azienda
    if (File.exists())
    {
        QString Style = QString("QWidget#centralwidget{ border-image: url(%1)};").arg(FileName);
        ui->centralwidget->setStyleSheet(Style);
    }

    ui->cmd_Duty->setVisible(false);
    ui->cmd_Navigator->setVisible(false);

    Global::Running = true;

    Logger::RemoteLogIP   = "192.168.1.10";
    Logger::RemoteLogPort = 3000;
    Logger::EnUDP         = false;
    Logger::Root          = "./Log";

    Logger::Purge(8);

    Logger::Info( "SYS", "Start appplication" );

    /**************************
     * GPIO
     **************************/

    buzzer = new TogglePin("buzzer");
    buzzer->setValue(0);

    /**************************
     * INIT VARS
     **************************/

    Config_Read();

    if (Global::nAgenzia == 41)
    {
        if (Global::VTecMaster)
        {
            Global::VTecMaster = false;

            Config_Write();
        }
    }

    LastTrackSendTime = Global::CurrentTime().addDays(-1);
    LastDutyCheck     = Global::CurrentTime();

    LastPosition.setAltitude(14);
    LastPosition.setLongitude(7);
    LastPosition.setAltitude(0);

    Global::Posizione.setAltitude ( 0     );
    Global::Posizione.setLongitude( 15.54 );
    Global::Posizione.setLatitude ( 38.16 );
    Global::Posizione.setCourse   ( 0     );

    /**********************************
     * LETTURA CONFIGURAZIONE PANNELLI
     **********************************/

    DisplayElmec = new QList<clsDisplayElmec *>();

    DisplayAesys = new QList<clsDisplayAesys *>();

    Panel_ReadConfig();

    qDebug() << "Pannelli ELMEC in configurazione: " << DisplayElmec->count();

    qDebug() << "Pannelli AESYS in configurazione: " << DisplayAesys->count();

    bool Pan = DisplayAesys->count() > 0 || DisplayElmec->count();

    ui->cmd_Panel->setVisible(Pan);

    /************************************
     *
     ************************************/

    VTecDevice = new QList<clsVTec *>();

    VTec_ReadConfig();

    qDebug() << "VTec in configurazione: " << VTecDevice->count();

    ui->cmd_VTec1->setVisible(VTecDevice->count() > 0);

    ui->cmd_VTec2->setVisible(VTecDevice->count() > 1);

    /**************************
     * INIT DEVICE LIST
     **************************/

    QVariantMap  Dev;

    Dev.insert("Code"  , "PNLA"     );
    Dev.insert("Id"    , "ANT"      );
    Dev.insert("Status", 1          );
    ListDev.append(Dev);

    Dev.insert("Code"  , "PNLL"     );
    Dev.insert("Id"    , "LAT"      );
    Dev.insert("Status", 0          );
    ListDev.append(Dev);

    Dev.insert("Code"  , "PNLP"     );
    Dev.insert("Id"    , "POS"      );
    Dev.insert("Status", 0          );
    ListDev.append(Dev);

    /******************************
     * APERTURA DATABASE
     ******************************/

    DBase = new DBManager(this, "DB_Main");

    bool Ok = DBase->Open();

    if (Ok)
    {
        DBase->Init();

        /******************************
         * CONFIGURAZIONE AZIENDA
         ******************************/

        ui->cmd_Xibo->setVisible( Global::XiboIP.length() > 6);

        qDebug() << "IMEI:  " << Global::Imei;
        qDebug() << "MEZZO: " << Global::Mezzo;

        Global::IDAgenzia = DBase->GetParam("IDAgenzia" , 0);
        Global::Agenzia   = DBase->GetParam("Agenzia"   , Global::Agenzia);
        Global::ApiKey    = DBase->GetParam("ApiKey"    , "");
        Global::BigoPoint = DBase->GetParam("EndPoint"  , Global::BigoPoint );
        Global::MqttServer= DBase->GetParam("MqttServer", Global::MqttServer);
        Global::MqttPort  = DBase->GetParam("MqttPort"  , Global::MqttPort);
        Global::MqttUser  = DBase->GetParam("MqttUser"  , Global::MqttUser);
        Global::MqttPsw   = DBase->GetParam("MqttPwd"   , Global::MqttPsw);

        Global::TimeOffset = DBase->GetParam("TimeOffset", 0);

        bool ForzaLetturaGtfs = (Global::IDAgenzia != Global::nAgenzia);

        int R = Read_ConfigurazioneAgenzia(Global::nAgenzia, "0000");

        if (R >= 0)
            Logger::Info("SYSTEM", "Configurazione Azienda: " + Global::Agenzia );

        qDebug() << "Agenzia in configurazione: " << Global::Agenzia;

        /**************************
         * LETTURA GTFS
         **************************/

        Gtfs = new clsGtfs();

        Gtfs->Read_Gtfs(ForzaLetturaGtfs, Global::Agenzia);
    }
    else
    {
        qDebug() << "ERRORE Apertuta database";
    }

    /**************************
     * START TCP SERVER
     **************************/

    TCPServer = new TcpServer(this);

    connect(TCPServer, SIGNAL(CommandReceived(int, QByteArray)), this, SLOT(CommandReceived(int, QByteArray)), Qt::QueuedConnection);

    connect( this, SIGNAL(SendMessage(int, QByteArray)), TCPServer, SLOT(SendMessage(int, QByteArray)), Qt::QueuedConnection);

    TCPServer->startServer();

    /**************************
     * START SERVER SPOOLER
     **************************/

    ThPay = new clsPayload("Spooler");

    ThPay->VTecDevice = VTecDevice;

    ThPay->start();

    /*****************************
     * PROTOCOLLO DISPLAY ELMEC
     *****************************/

    for(int j=0; j<DisplayElmec->count(); j++)
        DisplayElmec->at(j)->start();

    /*****************************
     * PROTOCOLLO DISPLAY AESYS
     *****************************/

    Aesys = new clsAesys(this);

    Aesys->Config(DisplayAesys);

    Aesys->startSlave("/dev/ttymxc5", 9600);

    /*****************************
     * PROTOCOLLO VTec
     *****************************/

    if (Global::VTecMaster)
    {
        for(int j=0; j<VTecDevice->count(); j++)
            VTecDevice->at(j)->start();
    }

    /*****************************
     * START CONTAPASSEGGER HELLA
     *****************************/

    Hella = new clsHellaNew();

    Eurotech = new Eurotechs();

    QList<QString> Pax = ContaPax_ReadConfig();

    if (Pax.count() > 0)
    {
        if (Global::ContaPaxModel.toUpper() == "HIKVISION" || Global::ContaPaxModel.toUpper() == "HELLA" )
        {
            Hella->Config( Pax, Global::ContaPaxPort);

            connect( Hella, SIGNAL(CpxStatusChanged(int)), this, SLOT(on_CpxStatusChanged(int)));

            connect( Hella, SIGNAL(PeopleCountChange(int,int,int)), this, SLOT(on_PeopleCountChange(int,int,int)));

            connect( Hella, SIGNAL(DoorStatusChanged(int)), this, SLOT(on_DoorStatusChanged(int)));

            Hella->start();
        }

        if (Global::ContaPaxModel.toUpper() == "EUROTECH" )
        {
            Eurotech->Config( Pax, Global::ContaPaxPort);

            connect( Eurotech, SIGNAL(CpxStatusChanged(int)), this, SLOT(on_CpxStatusChanged(int)));

            connect( Eurotech, SIGNAL(PeopleCountChange(int,int,int)), this, SLOT(on_PeopleCountChange(int,int,int)));

            connect( Eurotech, SIGNAL(DoorStatusChanged(int)), this, SLOT(on_DoorStatusChanged(int)));

            Eurotech->start();
        }
    }

    ui->People_ABordo->setVisible(Pax.count() > 0);
    ui->People_In    ->setVisible(Pax.count() > 0);
    ui->People_Out   ->setVisible(Pax.count() > 0);

    /**************************
     * START GPS
     **************************/

    /**************************
     * START SIMULATORE GPS
     **************************/

    qRegisterMetaType<GpsData>();

#ifdef ENABLE_GPS

    #ifdef ENABLE_SIMULATORE

        clsSimulatore *ThSim = new clsSimulatore(this);

        connect( ThSim, SIGNAL(DataReady(GpsData)), this, SLOT(DataReady(GpsData)), Qt::QueuedConnection );

        ThSim->start();

    #else

        Gps = new clsGps(this);

        Gps->startSlave("/dev/ttyUSB1", 100);

        connect( Gps, SIGNAL(OnLocation(QGeoCoordinate)), this, SLOT(onLocation(QGeoCoordinate)));

    #endif

#endif

#ifdef ENABLE_UDPGPS

        Gps = new clsGps(this);

        connect( Gps, SIGNAL(OnLocation(QGeoCoordinate)), this, SLOT(onLocation(QGeoCoordinate)));

        Gps->StartUDPReceiver();

#endif

#ifdef ENABLE_RFID

        Nfc = new clsNfc(this);

        //connect( Nfc, SIGNAL(NfcReceived(QString)), this, SLOT(onNfcReceived(QString)));

        Nfc->startSlave("/dev/ttyUSB0", 100);

#endif


#ifdef ENABLE_NAVIGATOR

    /**************************
     * START NAVIGATOR
     **************************/

    Nav = new clsNavigator();

    connect( this, SIGNAL(NewTrip(QString,QString)), Nav, SLOT(NewTrips(QString,QString)));

    connect( this, SIGNAL(NewLoc(QGeoCoordinate)), Nav, SLOT(NewPosition(QGeoCoordinate)));

    connect( Nav , SIGNAL(SendMessage(int,QByteArray)), this, SLOT(BroacastMessage(int, QByteArray)) );

    Nav->start();

#endif

    /**************************
     * BRIGHTNESS
     **************************/

    LumTimer = new QTimer(this);

    LumTimer->setSingleShot(true);

    connect( LumTimer, SIGNAL(timeout()), this, SLOT(ResetBrightness()));


    /**************************
     * BUZZER
     **************************/

    BuzzerTimer = new QTimer(this);

    BuzzerTimer->setSingleShot(false);

    connect( BuzzerTimer, SIGNAL(timeout()), this, SLOT(BuzzerTimerClick()));

    BuzzerTimer->start(15);

    onBeepSignal();

    /******************************
     * VERIFICA UTC
     ******************************/

    QProcess Proc;

    Proc.start("date");

    Proc.waitForFinished(5000);

    QString Temp = Proc.readAllStandardOutput();

    Global::FL_Utc = Temp.contains("UTC");

    qDebug() << Temp << (Global::FL_Utc ? "UTC" : "CET");

    /**************************
     * TIMER
     **************************/

    SecTimer = new QTimer(this);

    SecTimer->setSingleShot(false);

    connect( SecTimer, SIGNAL(timeout()), this, SLOT(onTimerRefresh()));

    SecTimer->start(1000);

    /**************************
     * MQTT
     **************************/

#ifdef ENABLE_MQTT

    LastMqttKeepAlive = QDateTime::fromSecsSinceEpoch(0);

    MqttClient = new QMQTT::Client();

    MqttClient->setHostName( Global::MqttServer );
    MqttClient->setPort( Global::MqttPort );

    connect(MqttClient, SIGNAL(connected())   , this, SLOT(onMqttConnected()));
    connect(MqttClient, SIGNAL(disconnected()), this, SLOT(onMqttDisconnected()));

    connect(MqttClient, SIGNAL(subscribed(QString,quint8)), this, SLOT(onMqttSubscribed(QString,quint8)));
    connect(MqttClient, SIGNAL(received  (QMQTT::Message)), this, SLOT(onMqttReceived(QMQTT::Message)));

    MqttClient->setClientId("cnt_" + Global::Imei + Global::CurrentTime().toString());
    MqttClient->setUsername(Global::MqttUser);
    MqttClient->setPassword(Global::MqttPsw.toLocal8Bit());
    MqttClient->setAutoReconnect(true);
    MqttClient->setKeepAlive(60);
    MqttClient->setCleanSession(false);

    MqttClient->connectToHost();

#endif

    /*****************************************
     * DOWNLOAD MANAGER
     *****************************************/

    QString Root = QCoreApplication::applicationDirPath();

    if ( !QDir(Root + "/temp").exists() )
        QDir().mkdir(Root + "/temp");

    if ( !QDir(Root + "/tmp").exists() )
        QDir().mkdir(Root + "/tmp");

    QObject::connect(&Repo, SIGNAL(done()), this, SLOT(on_Download()));

    DownloadTimer = new QTimer(this);

    DownloadTimer->setSingleShot(true);

    connect( DownloadTimer, SIGNAL(timeout()), this, SLOT(DownloadTimerClick()));

    DownloadTimer->start(3 * 60000);
    //DownloadTimer->start(20000); //SERGIO
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onLocation(QGeoCoordinate Geo)
{
    Global::Posizione.setAltitude ( Geo.altitude() );
    Global::Posizione.setLongitude( Geo.longitude());
    Global::Posizione.setLatitude ( Geo.latitude() );
    Global::Posizione.setCourse   ( Geo.course()   );
    Global::Posizione.setGpsTime  ( Geo.GpsTime()  );
    Global::Posizione.setAccuracy ( Geo.accuracy() );
    Global::Posizione.setnSat     ( Geo.nSat()     );
    Global::Posizione.setSpeed    ( Geo.speed()    );

    SendLocMessage("POL", false);
}

/*****************************************************************/
void MainWindow::DownloadTimerClick(void)
/*****************************************************************/
{
    int TWait = 30 * 60000;

    /*****************************
     * UDEV PATCH
     *****************************/

    QFile UDev("/etc/udev/rules.d/92-bigo-sdcard.rules");

    bool FL_Update = false;

    if(UDev.open(QIODevice::ReadOnly))
    {
        QString A = UDev.readAll();

        FL_Update = !A.contains("sync");

        UDev.close();
    }

    if (FL_Update)
    {
        if(UDev.open(QIODevice::WriteOnly | QIODevice::Truncate ))
        {
            QTextStream stream(&UDev);

            stream << "KERNEL!=\"mmcblk*\", GOTO=\"exit\"\n";
            stream << "KERNEL==\"mmcblk0p[0-9]\", SYMLINK+=\"sdcard%n\"\n";
            stream << "KERNEL==\"mmcblk0p[0-9]\", ENV{dir_name}=\"sdcard%n\"\n";
            stream << "# Global mount options\n";
            stream << "DRIVERS==\"usb\", ACTION==\"add\", ENV{mount_options}=\"relatime,nodiratime\"\n";
            stream << "# Filesystem-specific mount options\n";
            stream << "DRIVERS==\"usb\", ACTION==\"add\", ENV{ID_FS_TYPE}==\"vfat|ntfs\", ENV{mount_options}=\"$env{mount_options},utf8,gid=100,umask=002\"\n";
            stream << "# Mount the device\n";
            stream << "KERNEL==\"mmcblk0p[0-9]\", ACTION==\"add\", RUN+=\"/etc/init.d/udev_mount /dev/%E{dir_name} /media/%E{dir_name} $env{mount_options},sync\"\n";
            stream << "# Clean up after removal\n";
            stream << "KERNEL==\"mmcblk0p[0-9]\", ACTION==\"remove\", RUN+=\"/etc/init.d/udev_umount /media/%E{dir_name}\"\n";
            stream << "# Exit\n";
            stream << "LABEL=\"exit\"\n";

            stream.flush();

            UDev.flush();
            UDev.close();
        }
    }

    if (true)
    {
        clsWebService *WS = new clsWebService();

        /**************************************************************/

        connect(WS, &clsWebService::Signal_TimeOffset, [=](int offset){

            qDebug() << "Aggiornamento time offset";

            DBase->WriteParam("TimeOffset", offset);
        });

        WS->SincTime();

        /**************************************************************/

        /**************************
        * SEND DISCOVERY MESSAGE
        **************************/

        QVariantMap Map;

        Map["Agenzia"]   = Global::Agenzia;
        Map["Mezzo"]     = Global::Mezzo;
        Map["CP"]        = Global::Imei;
        Map["Timestamp"] = Global::CurrentTime().toString("yyyy-MM-dd HH:mm:ss");
        Map["Versione"]  = QString("TRM_%1").arg(Global::Versione);
        Map["TermID"]    = "";

        bool Ok = false;

        QString JS = QtJson::serialize(Map, Ok);

        if (Ok)
        {
            QUdpSocket Socket;

            try
            {
                Socket.writeDatagram(JS.toLocal8Bit(), QHostAddress("10.4.0.1"), 3000);
                Socket.writeDatagram(JS.toLocal8Bit(), QHostAddress("10.5.0.1"), 3000);
            }
            catch (...) {}
        }

        /**************************
        * CHECK REPOSITORY
        **************************/

        qDebug() << "WS: Lettura repository";

        QDateTime T0 = Global::CurrentTime();

        QString Url = QString("%1gtfs.asmx/Repository?Azienda=%2&Imei=TRM_%3")
                .arg(Global::EndPoint)
                .arg(Global::Agenzia)
                .arg(Global::Imei);

        Ok = WS->WSCall(Url);

        if (Ok)
        {
            qint64 T1 = T0.msecsTo(Global::CurrentTime());

            qDebug() << "Tempo lettura repository = " << T1 << " Resp: " << WS->Web_Response;

            int x1 = WS->Web_Response.indexOf("[");
            int x2 = WS->Web_Response.lastIndexOf("]");

            if (x2 > x1)
            {
                if (WS->Web_Response.contains("Download_Url"))
                {
                    qDebug() << "WS: Lettura repository OK";

                    JsonArray Lista = QtJson::parse( WS->Web_Response.mid( x1, x2-x1+2 ), Ok).toList();

                    if (Ok)
                    {
                        bool AlmenoUno = false;

                        QString Root = QCoreApplication::applicationDirPath();

                        for (int j=0; j < Lista.length(); j++ )
                        {
                            QMap<QString, QVariant> Resp = Lista[j].toMap();

                            QString MD5   = Resp["FileHash"].toString();
                            QString Url   = Resp["Download_Url"].toString();
                            QString TPath = Resp["TargetPath"].toString();

                            TPath = TPath.replace("\\", "/");

                            QString LocalMd5 = Repo.File_ReadMd5( QString( Root + "/%1").arg(TPath) );

                            if (LocalMd5 != MD5)
                            {
                                qDebug() << "Aggiornamento disponibile ... download " << TPath;

                                Repo.setTarget(Url, TPath, MD5);
                                Repo.download();
                                AlmenoUno = true;
                                break;
                            }
                            else
                                qDebug() << "L'ultima versione gia' presente";
                        }

                        if (AlmenoUno)
                            TWait = 1 * 60000;
                        else
                            TWait = 30 * 60000;
                    }

                }
                else
                    qDebug() << "WS: Lettura repository ERROR #2";
            }
            else
                qDebug() << "WS: Lettura repository ERROR #3";
        }
        else
            qDebug() << "WS: Lettura repository ERROR #1";
    }

    DownloadTimer->start(TWait);
}

/*****************************************************************/
void MainWindow::on_Download(void)
/*****************************************************************/
{
    qDebug() << "Download terminato";
}

/*****************************************************************/
void MainWindow::on_cmd_Panel_clicked()
/*****************************************************************/
{
    qDebug() << "KEY: Pannelli";

    onBeepSignal();

    int Brand = 0;

    if (DisplayElmec->count() > 0)
        Brand = 2;

    if (DisplayAesys->count() > 0)
        Brand = 1;

    if (Brand != 0)
    {
        frmPannelli *frm = new frmPannelli(this, Brand);

        connect(frm, SIGNAL(SendMessage(QString)), this, SLOT(Elmec_SendMessage(QString)));

        connect(frm, SIGNAL(BeepSignal()), this, SLOT(onBeepSignal()));

        frm->show();
    }
}

/*******************************************/
void MainWindow::onBeepSignal()
/*******************************************/
{
    buzzer->Beep(1);

    LumTimer->stop();
    LumTimer->start(30000);
}

/*****************************************************************/
void MainWindow::ResetBrightness(void)
/*****************************************************************/
{
    if (Global::SpegniLCD)
        buzzer->setBrightness(5);
}

/*******************************************/
void MainWindow::Elmec_SendMessage(QString Codice)
/*******************************************/
{
    Global::PanelCode = Codice;

    /*****************
     * ELMEC
     *****************/

    for (int k=0; k<DisplayElmec->count(); k++)
    {
        clsDisplayElmec *Disp = DisplayElmec->at(k);

        int nR = 0;

        switch (Disp->TipoPannello)
        {
            case 1:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, ePanelModel::Posteriore );
                break;
            case 2:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, ePanelModel::Laterale );
                break;
            case 3:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, ePanelModel::Anteriore );
                break;
            case 4:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, ePanelModel::Anteriore );
                break;
            case 5:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, ePanelModel::Anteriore );
                break;
            default:
                nR = 0;
                break;
        }

        if (nR > 0)
        {
            QString Num = "";
            QString Sup = "";
            QString Inf = "";

            QString NumFore = "FFF";
            QString NumBack = "000";

            QString SupFore = "FFF";
            QString SupBack = "000";

            QString InfFore = "FFF";
            QString InfBack = "000";

            for (int j = 0; j < nR; j++)
            {
                if (Gtfs->GTFS_Velette->at(j)->rowTypeId == 1)
                {
                    Num     = Gtfs->GTFS_Velette->at(j)->panelText;
                    NumFore = Gtfs->GTFS_Velette->at(j)->color;
                    NumBack = Gtfs->GTFS_Velette->at(j)->bgColor;

                    // qDebug() << "NUM:" << Num << " FORE:" << NumFore << " BACK:" << NumBack;
                }

                if (Gtfs->GTFS_Velette->at(j)->rowTypeId == 2)
                {
                    Sup     = Gtfs->GTFS_Velette->at(j)->panelText;
                    SupFore = Gtfs->GTFS_Velette->at(j)->color;
                    SupBack = Gtfs->GTFS_Velette->at(j)->bgColor;
                }

                if (Gtfs->GTFS_Velette->at(j)->rowTypeId == 3)
                {
                    Inf     = Gtfs->GTFS_Velette->at(j)->panelText;
                    InfFore = Gtfs->GTFS_Velette->at(j)->color;
                    InfBack = Gtfs->GTFS_Velette->at(j)->bgColor;
                }
            }

            if (Disp->TipoPannello==4)
            {
                Sup = "";
                Inf = "";
            }

            if (Disp->TipoPannello == 5)
            {
                Num = "";
            }

            Disp->SetPanel(Num, NumFore, NumBack, Sup, SupFore, SupBack, Inf, InfFore, InfBack);
        }
    }

    /*****************
     * AESYS
     *****************/

    for (int k=0; k<DisplayAesys->count(); k++)
    {
        clsDisplayAesys *Disp = DisplayAesys->at(k);

        int nR = 0;

        switch (Disp->nZone)
        {
            case 1:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, Disp->Modello );
                break;
            case 2:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, Disp->Modello );
                break;
            case 3:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, Disp->Modello );
                break;
            case 4:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, Disp->Modello );
                break;
            case 5:
                nR = Gtfs->Load_Velette(Codice, Disp->Brand, Disp->Modello );
                break;
            default:
                nR = 0;
                break;
        }

        if (nR > 0)
        {
            QString Num = "";
            QString Sup = "";
            QString Inf = "";

            QString NumFore = "FFF";
            QString NumBack = "000";

            QString SupFore = "FFF";
            QString SupBack = "000";

            QString InfFore = "FFF";
            QString InfBack = "000";

            for (int j = 0; j < nR; j++)
            {
                if (Gtfs->GTFS_Velette->at(j)->rowTypeId == 1)
                {
                    Num     = Gtfs->GTFS_Velette->at(j)->panelText;
                    NumFore = Gtfs->GTFS_Velette->at(j)->color;
                    NumBack = Gtfs->GTFS_Velette->at(j)->bgColor;

                    // qDebug() << "NUM:" << Num << " FORE:" << NumFore << " BACK:" << NumBack;
                }

                if (Gtfs->GTFS_Velette->at(j)->rowTypeId == 2)
                {
                    Sup     = Gtfs->GTFS_Velette->at(j)->panelText;
                    SupFore = Gtfs->GTFS_Velette->at(j)->color;
                    SupBack = Gtfs->GTFS_Velette->at(j)->bgColor;
                }

                if (Gtfs->GTFS_Velette->at(j)->rowTypeId == 3)
                {
                    Inf     = Gtfs->GTFS_Velette->at(j)->panelText;
                    InfFore = Gtfs->GTFS_Velette->at(j)->color;
                    InfBack = Gtfs->GTFS_Velette->at(j)->bgColor;
                }
            }

            Disp->SetPanel(Num, NumFore, NumBack, Sup, SupFore, SupBack, Inf, InfFore, InfBack);
        }
    }
}

void MainWindow::on_cmd_Navigator_clicked()
{
}

/*************************************/
void MainWindow::BroacastMessage(int ClientID, QByteArray Data)
/*************************************/
{
    emit SendMessage( ClientID, Data );
}

/*************************************/
void MainWindow::BroacastMessage(int ClientID, QString Data)
/*************************************/
{
    emit SendMessage( ClientID, Data.toLocal8Bit() );
}

/*************************************/
void MainWindow::CommandReceived(int ClientID, QByteArray Datagram)
/*************************************/
{
    qDebug() << "Ricevuto messaggio da " << ClientID;

    QString Message = QString::fromLocal8Bit( Datagram );

    int Ptr = 0;

    do
    {
        QString Msg = Message.mid(Ptr);

        qDebug() << Msg;

        bool Ok = false;

        if (Msg.startsWith("#"))
        {
            if (Msg.startsWith("#pan"))
            {
                on_cmd_Panel_clicked();
            }

            if (Msg.startsWith("#info"))
            {
                BroacastMessage( ClientID, QString("Agenzia: %1\r\n").arg(Global::Agenzia));
                BroacastMessage( ClientID, QString("Trip: %1\r\n").arg(Global::TripID));
                BroacastMessage( ClientID, QString("Duty: %1\r\n").arg(Global::DutyID));
            }

            if (Msg.startsWith("#agenzia"))
            {
                QString Agenzia = "18";

                if (Agenzia != Global::Agenzia)
                {
                    SendProcessStatus("busy");

                    bool Ok = Gtfs->Read_Gtfs(true, Agenzia);

                    if (Ok)
                    {
                        Global::Agenzia = Agenzia;

                        SendProcessStatus("ready");
                    }
                    else
                        SendProcessStatus("error");
                }
            }

            if (Msg.startsWith("#test"))
            {
                Global::Imei        = "1540918946";
                Global::Mezzo       = "PROVA";
                Global::Conducente  = "";
                QString DutyID      = "309";
                QString TripID      = "";

                if (Global::Agenzia.length() > 0)
                    emit NewTrip(DutyID, TripID);
            }

            if (Msg.startsWith("#emit"))
            {
                GpsData Dati;
                Dati.GpsFix = true;
                Dati.TimeStamp = Global::CurrentTime();
                Dati.Coord.setLatitude(10.0);
                Dati.Coord.setLongitude(7);
                Dati.Coord.setAltitude(236);
                //emit DataReady(Dati);
            }

            if (Msg.startsWith("#start_app"))
            {
                Global::DutyID      = "18000";
                Global::TripID      = "20-TEST";
            }

            if (Msg.startsWith("#stop_app"))
            {
                Global::DutyID      = "";
                Global::TripID      = "";
            }

            Ptr += Msg.length();
        }
        else
        {
            QVariantMap Param = QtJson::parse( Msg, Ok).toMap();

            if (Ok)
            {
                QString Action = Param["action"].toString().toUpper();

            }

            Ptr += Msg.indexOf("\n\n") + 2;
        }

    } while ( Ptr < Message.length() );

}

/*****************************************/
void MainWindow::SendProcessStatus( QString Status )
/*****************************************/
{
    bool Ok = false;
    QVariantMap Data;
    QDateTime   Now = Global::CurrentTime();

    Data.insert("action"   , "avm-process-status");
    Data.insert("timestamp", Now.toString("dd/MM/yyyy HH:mm:ss") );
    Data.insert("status"   , Status   );

    QtJson::setPrettySerialize(true);

    QString JS = QtJson::serialize(Data, Ok) + "\n\n";

    if (Ok)
    {
        BroacastMessage( -1, JS.toLocal8Bit() );
    }
}

/**************************************/
void MainWindow::BuzzerTimerClick()
/**************************************/
{
    if (buzzer->WavePtr > 0)
    {
        int i = buzzer->WavePtr - 1;

        if (buzzer->Wave[i] > 0)
            buzzer->Wave[i]--;
        else
            buzzer->WavePtr--;

        buzzer->setValue( i & 1 );
    }
}


/*****************************************************************/
void MainWindow::SendDiagnostic(void)
/*****************************************************************/
{
    static QDateTime LastDiagno = QDateTime::fromSecsSinceEpoch(0);

    static QString oJS = "";

    QVariantMap Map;

    Map["AgencyId" ]    = Global::Agenzia;
    Map["VehicleId"]    = Global::Imei;
    Map["PlateId"  ]    = "";
    Map["CodeHW"   ]    = "";
    Map["IsSchool" ]    = false;
    Map["Lat"]          = 0;
    Map["Lng"]          = 0;
    Map["Heading"  ]    = 0;
    Map["Speed"     ]   = 0;
    Map["TimeStamp"]    = "#DATA#";
    Map["TripId"]       = "";
    Map["StopId"]       = "";
    Map["Type"]         = "DGX";
    Map["VS"]           = Global::Versione;

    /**************************
    * INIT DEVICE LIST
    **************************/

    QVariantList DeviceList;
    QVariantMap  Dev;

    QVariantList SignalList;

    /**************************
    * PANELS
    **************************/

    for (int j=0; j < DisplayElmec->count(); j++)
    {
        clsDisplayElmec *P = DisplayElmec->at(j);

        Dev.clear();
        Dev.insert("Code"  , P->DCode );
        Dev.insert("Id"    , P->DID   );
        Dev.insert("Status", (P->Status == eStatus::Up) ? 1 : 0);

        DeviceList.append(Dev);
    }

    for (int j=0; j < DisplayAesys->count(); j++)
    {
        clsDisplayAesys *P = DisplayAesys->at(j);

        Dev.clear();
        Dev.insert("Code"  , P->DCode );
        Dev.insert("Id"    , P->DID   );
        Dev.insert("Status", P->Status == eStatus::Up ? 1 : 0);

        DeviceList.append(Dev);
    }


    /**************************
    * GPS
    **************************/

    Dev.clear();
    Dev.insert("Code"  , "GPS"              );
    Dev.insert("Id"    , "GPS_1"            );
    Dev.insert("Status", Global::GpsStatus ? 1 : 0);

    Dev.insert("Signals"    , SignalList);
  //Dev.insert("SignalsMon" , Money);
  //Dev.insert("SignalsRot" , Rotolo);

    DeviceList.append(Dev);

    /**************************
    * XIBO
    **************************/

    if (Global::XiboIP.length() > 6)
    {
        Dev.clear();
        Dev.insert("Code"  , "LCD"  );
        Dev.insert("Id"    , "LCD_1");
        Dev.insert("Status", Global::XiboStatus ? 0 : 1);

        Dev.insert("Signals"    , SignalList);

        DeviceList.append(Dev);
    }

    /**************************
    * CONTAPAX HELLA
    **************************/

    for (int j=0; j < Hella->Lista->count(); j++)
    {
        HellaInfo *cpx = Hella->Lista->values().at(j);

        Dev.clear();
        Dev.insert("Code"  , "CPX"        );
        Dev.insert("Id"    , cpx->DeviceID);
        Dev.insert("Status", (cpx->Stato == eStatus::Up) ? 1 : 0 );

        Dev.insert("Signals"    , SignalList);

        DeviceList.append(Dev);
    }

    /**************************
    * CONTAPAX EUROTECH
    **************************/

    for (int j=0; j < Eurotech->ContaPax.count(); j++)
    {
        clsEurotech *cpx = Eurotech->ContaPax.at(j);

        Dev.clear();
        Dev.insert("Code"  , "CPX"  );
        Dev.insert("Id"    , cpx->ID);
        Dev.insert("Status", (cpx->Status == eStatus::Up) ? 1 : 0 );

        Dev.insert("Signals"    , SignalList);

        DeviceList.append(Dev);
    }

    /**************************
    * VTECS
    **************************/

    for(int j = 0; j < VTecDevice->count(); j++)
    {
        clsVTec *vtec = VTecDevice->at(j);
        Dev.clear();
        Dev.insert("Code"  , "VTEC"        );
        Dev.insert("Id"    , vtec->ID);
        Dev.insert("Status", vtec->Status == clsVTec::Up ? 1 : 0  );

        Dev.insert("Signals"    , SignalList);

        DeviceList.append(Dev);
    }

    Map["Devices"] = DeviceList;

    bool Ok = false;

    QString JS = QtJson::serialize(Map, Ok);

    if (Ok)
    {
        bool OkSend = (JS != oJS);

        if (!OkSend)
        {
            quint64 T = (LastDiagno.secsTo(Global::CurrentTime()));

            OkSend = ( qFabs(T) >= 300);

            qDebug() << "Send diagnostic x time";
        }
        else
        {
            qDebug() << "Send diagnostic x var";
            qDebug() << JS;
            qDebug() << oJS;
            oJS = JS;
        }

        if (OkSend)
        {
            LastDiagno = Global::CurrentTime();

            Map["Lat"]       = (double)Global::Posizione.latitude();
            Map["Lng"]       = (double)Global::Posizione.longitude();
            Map["Speed"]     = (double)Global::Posizione.speed();
            Map["TimeStamp"] = Global::CurrentTime().toString("yyyy-MM-dd HH:mm:ss.000Z");

            JS = QtJson::serialize(Map, Ok);

            qDebug() << "DIAGNO: " << JS;

            ThPay->PushMessage("DIAGNO", JS);

            QString Topics = QString("%1/TRM/MASTER/DIAGNO/%2")
                    .arg(Global::Agenzia.toUpper())
                    .arg(Global::Imei);

            MqttSendMessage(Topics, JS);
        }
    }
}


/**************************************/
void MainWindow::onTimerRefresh()
/**************************************/
{
    double T0;

    QDateTime Now = Global::CurrentTime();

    /******************************
     * ICONE DIAGNOSTICA VTEC
     ******************************/

    if (VTecDevice->count() > 0)
    {
        if (VTecDevice->at(0)->Status == clsVTec::eVTecStatus::Down || VTecDevice->at(0)->Status == clsVTec::eVTecStatus::Init)
            ui->cmd_VTec1->setIcon(QIcon(":/Icone/vtec_down.png"));
        else
        {
            if (VTecDevice->at(0)->VTecMode == 1)
                ui->cmd_VTec1->setIcon(QIcon(":/Icone/vtec.png"));
            else
                ui->cmd_VTec1->setIcon(QIcon(":/Icone/vtec_disabled.png"));
        }
    }

    if (VTecDevice->count() > 1)
    {
        if (VTecDevice->at(1)->Status == clsVTec::eVTecStatus::Down || VTecDevice->at(1)->Status == clsVTec::eVTecStatus::Init)
            ui->cmd_VTec2->setIcon(QIcon(":/Icone/vtec_down.png"));
        else
        {
            if (VTecDevice->at(1)->VTecMode == 1)
                ui->cmd_VTec2->setIcon(QIcon(":/Icone/vtec.png"));
            else
                ui->cmd_VTec2->setIcon(QIcon(":/Icone/vtec_disabled.png"));
        }
    }

    /******************************
     * ICONE DIAGNOSTICA XIBO
     ******************************/

    if (Global::XiboStatus==0)
        ui->cmd_Xibo->setIcon(QIcon(":/Icone/monitor.png"));
    else
        ui->cmd_Xibo->setIcon(QIcon(":/Icone/monitor_down.png"));

    /******************************
     * GPS
     ******************************/

    T0 = Gps->LastGpsRx.msecsTo(Now);

    Global::GpsStatus = T0 < 5000;

    if (Global::GpsStatus)
        ui->cmd_Gps->setIcon(QIcon(":/Icone/satellite.png"));
    else
        ui->cmd_Gps->setIcon(QIcon(":/Icone/satellite_down.png"));

    /******************************
     * LAN
     ******************************/

    T0 = ThPay->LastNetSend.msecsTo(Now);

    Global::NetStatus = qFabs(T0) < 60000;

#ifdef ENABLE_MQTT

        if (MqttClient->isConnectedToHost())
        {
            /********************
             * MQTT KEEPALIVE
             ********************/

            quint64 T = (LastMqttKeepAlive.secsTo(Global::CurrentTime()));

            if ( qFabs(T) >= 60)
            {
                LastMqttKeepAlive = Global::CurrentTime();

                /************************
                 * DIAGNOSTICA PANNELLI
                 ************************/

                /*** ELMEC ***/

                Global::ElmecStatus = "";

                for (int j=0; j<DisplayElmec->count(); j++)
                {
                    QString S = QVariant::fromValue(DisplayElmec->at(j)->Status).toString();

                    Global::ElmecStatus += S.mid(0,1);
                }

                /*** AESYS ***/

                Global::AesysStatus = "";

                for (int j=0; j<DisplayAesys->count(); j++)
                {
                    QString S = QVariant::fromValue(DisplayAesys->at(j)->Status).toString();

                    Global::AesysStatus += S.mid(0,1);
                }

                /************************
                 * DIAGNOSTICA VTec
                 ************************/

                Global::VTecStatus = "";

                for (int j=0; j<VTecDevice->count(); j++)
                {
                    QString S = QVariant::fromValue(VTecDevice->at(j)->Status).toString();

                    Global::VTecStatus += S.mid(0,1);
                }

                QString Topics = QString("%1/TRM/MASTER/KEEPALIVE/%2")
                        .arg(Global::Agenzia.toUpper())
                        .arg(Global::Imei);

                QMQTT::Message msg;
                msg.setTopic(Topics);
                msg.setQos(1);
                msg.setRetain(true);

                QVariantMap Map;

                Map["Event" ]      = "KeepAlive";
                Map["Time"  ]      = Global::CurrentTime().toString("yyyy-MM-dd HH:mm:ss");
                Map["Versione"   ] = Global::Versione;
                Map["PanelCode"  ] = Global::PanelCode;
                Map["PanelStatus"] = Global::ElmecStatus;
                Map["VTecStatus" ] = Global::VTecStatus;
                Map["Utc"        ] = Global::FL_Utc ? "UTC" : "CET";

                bool Ok = false;

                QString JS = QtJson::serialize(Map, Ok);

                msg.setPayload(JS.toLocal8Bit());

                int MqttErr = MqttClient->publish(msg);

                qDebug() << "MqttErr: " << MqttErr;

                SendDiagnostic();
            }
        }
#endif
}

#ifdef ENABLE_MQTT

void MainWindow::onMqttConnected(void)
{
    qDebug() << "MQTT Connected";

    QString Topics = QString("ELMEC/TRM/%1/%2/#").arg(Global::Agenzia.toUpper()).arg(Global::Imei);
    MqttClient->subscribe(Topics);
}

void MainWindow::onMqttDisconnected(void)
{
    qDebug() << "MQTT Disconnected";
}

void MainWindow::onMqttSubscribed(QString Topic, quint8 qos)
{
    qDebug() << "MQTT Subscribed topics" << Topic << "Qos" << qos;
}

/********************************************************/
void MainWindow::onMqttReceived(QMQTT::Message message)
/********************************************************/
{
    bool Rispondi = false;
    bool Ok = false;
    QString Pay;
    int ID;
    QMap<QString, QVariant> Resp;

    Pay = message.payload();
    ID  = message.id();

    if (Pay.startsWith("{"))
        Resp = QtJson::parse(Pay, Ok).toMap();

    qDebug() << "MQTT Received ID:" << ID << " " << message.topic() << " -> " << message.payload();

    QString Topics = QString("%1/TRM/MASTER/COMMANDS/%2")
            .arg(Global::Agenzia)
            .arg(Global::Imei);

    if (message.topic().toUpper() == Topics.toUpper() )
    {
        qDebug() << "MQTT: Ricevuto Commands";

        QString Cmd = Resp["Cmd"  ].toString().toUpper();
                ID  = Resp["MsgID"].toInt();

        if (Cmd == "SETPANEL")
        {
            QString Code = Resp["Code"].toString();

            Elmec_SendMessage(Code);

            Rispondi = true;
        }
    }

    if (Rispondi)
    {
        QString Topics = QString("ELMEC/TRM/%1/MASTER/%2")
                .arg(Global::Agenzia)
                .arg(Global::Imei);

        QMQTT::Message msg;
        msg.setTopic(Topics.toUpper());
        msg.setQos(1);
        msg.setRetain(false);

        QVariantMap Map;

        Map["Event" ] = "Reply";
        Map["MsgID" ] = ID;

        bool Ok = false;

        QString JS = QtJson::serialize(Map, Ok);

        msg.setPayload(JS.toLocal8Bit());

        MqttClient->publish(msg);
    }
}

#endif


void MainWindow::on_cmd_Duty_clicked()
{
    frmSelectDuty *frm = new frmSelectDuty();

    connect( frm, SIGNAL(NewTrips(QString,QString)), Nav, SLOT(NewTrips(QString,QString)));

    frm->show();
}

/****************************************************************************************/
void MainWindow::on_DoorStatusChanged(int DoorStatus)
/****************************************************************************************/
{
    QString Event = (DoorStatus == eDoorStatus::Opened) ? "OPN" : "CLS";

    SendLocMessage(Event, true);
}

/****************************************************************************************/
void MainWindow::on_PeopleCountChange(int PassIn, int PassOut, int aBordo)
/****************************************************************************************/
{
    ui->People_In    ->setNum(PassIn);
    ui->People_Out   ->setNum(PassOut);
    ui->People_ABordo->setNum(aBordo);
}
/****************************************************************************************/
void MainWindow::on_CpxStatusChanged(int Stato)
/****************************************************************************************/
{
    if (Stato == Up)
        ui->IcoPeole->setStyleSheet("border-image: url(:/Icone/People.png) 0,0,0,0 stretch stretch");
    else
        ui->IcoPeole->setStyleSheet("border-image: url(:/Icone/People_down.png) 0,0,0,0 stretch stretch");
}

/****************************************************************************************/
void MainWindow::SendLocMessage(QString Evento, bool Forza)
/****************************************************************************************/
{
    QString Msg = QString("Data:%1 nSat:%7 Lat:%2 Lng:%3 Spd:%4 Ang:%5 hDop:%6")
                    .arg(Global::Posizione.GpsTime().toString("HH:mm:ss"))
                    .arg(Global::Posizione.latitude())
                    .arg(Global::Posizione.longitude())
                    .arg(QString::number(Global::Posizione.speed()   , 'f', 2))
                    .arg(QString::number(Global::Posizione.course()  , 'f', 2))
                    .arg(QString::number(Global::Posizione.accuracy(), 'f', 2))
                    .arg(Global::Posizione.nSat());

    qDebug() << "GPS: " << Msg;

    QDateTime Now = Global::CurrentTime();

    bool OkSend = Forza;

    if (!OkSend)
    {
        OkSend = qFabs(LastTrackSendTime.secsTo(Now)) >= 60;

        if (OkSend)
            qDebug() << "Send for time";
    }

    double Dist = LastPosition.distanceTo(Global::Posizione);

    if (!OkSend)
    {
        OkSend = Dist > 30;

        if (OkSend)
            qDebug() << "Send for Dist";
    }

    if (!OkSend)
    {
        if (Global::Posizione.speed() > 5)
        {
            double Angolo = qFabs( Global::Posizione.course() - LastPosition.course() );

            OkSend =  Angolo > 5;

            if (OkSend)
            {
                qDebug() << "Send for course";
                qDebug() << "Angolo: " << Angolo << " Loc: " << Global::Posizione.course() << " Last: " << LastPosition.course();
            }
        }
    }

    if (OkSend)
    {
        oDoor = Global::Door;

        TrackInfo Data;

        Data.Event  = Evento;
        Data.Imei   = Global::Imei;
        Data.Mezzo  = Global::Mezzo;
        Data.Cond   = Global::Conducente;
        Data.Lat    = (double)Global::Posizione.latitude();
        Data.Lng    = (double)Global::Posizione.longitude();
        Data.Ang    = (double)Global::Posizione.course();
        Data.Speed  = (double)Global::Posizione.speed();
        Data.Odo    = 0;
        Data.Time   = Global::Posizione.GpsTime();
        Data.StopID = "";
        Data.Motore = 1;
        Data.TripID = Global::TripID;
        Data.DutyID = Global::DutyID;
        Data.Porte  = Global::Door;
        Data.PassIN = Global::PeopleIN;
        Data.PassOUT= Global::PeopleOUT;
        Data.Rit    = 0;

        Data.Fore_Stop = Global::Fore_Stop;
        Data.Fore_Time = Global::Fore_Time;

        ThPay->PushMessage( "TRACKER", Data );

        LastPosition.setAltitude ( Global::Posizione.altitude() );
        LastPosition.setLongitude( Global::Posizione.longitude());
        LastPosition.setLatitude ( Global::Posizione.latitude() );
        LastPosition.setCourse   ( Global::Posizione.course()   );

        if (!Forza)
            LastTrackSendTime = Now;
    }
}

/**************************************/
int MainWindow::Panel_ReadConfig( void )
/**************************************/
{
    QString FileName = QDir(QCoreApplication::applicationDirPath()).filePath("Panel.ini");

    QFile Config(FileName);

    if(Config.exists())
    {
        qDebug() << "Lettura Panel.ini";

        if (Config.open(QFile::ReadOnly | QFile::Text))
        {
            QByteArray JS = Config.readAll();

            JS.replace("\t", "");
            JS.replace("\n", "");

            bool Ok = false;

            QVariantMap Conf = QtJson::parse( JS, Ok).toMap();

            if (Ok)
            {
                QVariantList Panel = Conf["Pannelli"].toList();

                if (Conf["Lumin"].isValid())
                    Global::Lumin  = Conf["Lumin"].toInt();

                for (int j=0; j<Panel.count(); j++)
                {
                    QMap<QString, QVariant> Elem = Panel.at(j).toMap();

                    QString IP           = Elem["Adr"].toString();
                    QString DCode        = Elem["Code"].toString();
                    QString DID          = Elem["ID"].toString();
                    int     Modello      = Elem["Model"].toInt();
                    int     nZone        = Elem["nZone"].toInt();
                    int     Brand        = Elem["Brand"].toInt();

                    if (Brand==2)
                    {
                        clsDisplayElmec *P = new clsDisplayElmec();

                        P->Config(IP, 3001, (ePanelType)nZone, (ePanelModel)Modello, DCode, DID);

                        DisplayElmec->append(P);
                    }

                    if (Brand==1)
                    {
                        clsDisplayAesys *P = new clsDisplayAesys();

                        P->Config(IP, (ePanelType)nZone, (ePanelModel)Modello, DCode, DID);

                        DisplayAesys->append(P);
                    }

                }
            }

            Config.close();
        }
    }

    return DisplayElmec->count() + DisplayAesys->count();
}

/**************************************/
QList<QString> MainWindow::ContaPax_ReadConfig( void )
/**************************************/
{
    QList<QString> Lista;

    QString FileName = QDir(QCoreApplication::applicationDirPath()).filePath("ContaPax.ini");

    QFile Config(FileName);

    if(Config.exists())
    {
        qDebug() << "Lettura ContaPax.ini";

        if (Config.open(QFile::ReadOnly | QFile::Text))
        {
            QByteArray JS = Config.readAll();

            JS.replace("\t", "");
            JS.replace("\n", "");

            bool Ok = false;

            QVariantMap Conf = QtJson::parse( JS, Ok).toMap();

            if (Ok)
            {
                if (Conf["Model"].isValid())
                    Global::ContaPaxModel = Conf["Model"].toString();

                if (Conf["Port"].isValid())
                    Global::ContaPaxPort  = Conf["Port"].toInt();

                QVariantList Device = Conf["Device"].toList();

                for (int j=0; j<Device.count(); j++)
                {
                    QMap<QString, QVariant> Elem = Device.at(j).toMap();

                    Lista.append(Elem["IP"].toString());
                }
            }

            Config.close();
        }
    }

    return Lista;
}


/**************************************/
int MainWindow::VTec_ReadConfig( void )
/**************************************/
{
    QString FileName = QDir(QCoreApplication::applicationDirPath()).filePath("Device.ini");

    QFile Config(FileName);

    if(Config.exists())
    {
        qDebug() << "Lettura Device.ini";

        if (Config.open(QFile::ReadOnly | QFile::Text))
        {
            QByteArray JS = Config.readAll();

            bool Ok = false;

            QVariantMap Conf = QtJson::parse( JS, Ok).toMap();

            if (Ok)
            {
                /**********************
                 * VTEC SECTION
                 **********************/

                QVariantList VTec = Conf["VTec"].toList();

                for (int j=0; j<VTec.count(); j++)
                {
                    QMap<QString, QVariant> Elem = VTec.at(j).toMap();

                    clsVTec *P = new clsVTec();

                    QString IP           = Elem["IP"].toString();
                    int     Port         = Elem["Port"].toInt();

                    P->Config(IP, Port, j+1);

                    VTecDevice->append(P);
                }
            }

            Config.close();
        }
    }

    /*********************************
     * ESEMPIO DEVICE.INI
     *********************************
    {
      "VTec": [
        {
          "Port": 1000,
          "IP": "192.168.1.231"
        },
        {
          "Port": 1001,
          "IP": "192.168.1.232"
        }
      ],

      "Monitor": [
        {
          "Port": 300,
          "IP": "192.168.1.200"
        }
      ]

    }

    *********************************/

    return VTecDevice->count();
}

/**************************************/
int MainWindow::Config_Read( void )
/**************************************/
{
    int Err = 1;

    QString FileName = QDir(QCoreApplication::applicationDirPath()).filePath("trm.ini");

    QFile Config(FileName);

    if(Config.exists())
    {
        qDebug() << "Lettura trm.ini";

        QSettings *Setting = new QSettings(FileName, QSettings::IniFormat);

        Global::nAgenzia    = Setting->value("Config/Agenzia" , 26).toInt();
        Global::Imei        = Setting->value("Config/Imei"    , Global::Imei ).toString();
        Global::Mezzo       = Setting->value("Config/Mezzo"   , Global::Mezzo).toString();
        Global::XiboIP      = Setting->value("Config/LCDPanel", Global::XiboIP).toString();
        Global::VTecMaster  = Setting->value("Config/VTecMaster", Global::VTecMaster).toBool();
        Global::SpegniLCD   = Setting->value("Config/SpegniLCD", Global::SpegniLCD).toBool();

        Err = 0;
    }
    else
    {
        Global::nAgenzia = 26;                // BigoTest

        Global::Imei       = "12345678";
        Global::Mezzo      = "TEST";
        Global::VTecMaster = false;

        Config_Write();
    }

    return Err;
}

/**************************************/
int MainWindow::Config_Write( void )
/**************************************/
{
    qDebug() << "Scrittura trm.ini";

    QString FileName = QDir(QCoreApplication::applicationDirPath()).filePath("trm.ini");

    QSettings *Setting = new QSettings(FileName, QSettings::IniFormat);

    Setting->setValue("Config/Agenzia"    , Global::nAgenzia);
    Setting->setValue("Config/Imei"       , Global::Imei    );
    Setting->setValue("Config/LCDPanel"   , Global::XiboIP  );
    Setting->setValue("Config/Mezzo"      , Global::Mezzo   );
    Setting->setValue("Config/VTecMaster" , Global::VTecMaster);
    Setting->setValue("Config/SpegniLCD"  , Global::SpegniLCD );

    Setting->sync();

    return 0;
}

/**************************************/
void MainWindow::on_cmd_VTec1_clicked()
/**************************************/
{
    if (Global::VTecMaster)
    {
        onBeepSignal();
        Global::EnableVTec1 = !Global::EnableVTec1;
        VTecDevice->at(0)->BuildRequest(Global::EnableVTec1, true);
    }
}

/**************************************/
void MainWindow::on_cmd_VTec2_clicked()
/**************************************/
{
    if (Global::VTecMaster)
    {
        onBeepSignal();
        Global::EnableVTec2 = !Global::EnableVTec2;
        VTecDevice->at(1)->BuildRequest(Global::EnableVTec2, true);
    }
}

/******************************************/
QString MainWindow::CP_Read(void)
/******************************************/
{
    QString Ret = "9999";

    QDir dir("/app/1wire");

    qDebug() << "Lettura codice piastra";

    dir.setFilter(QDir::Dirs | QDir::NoSymLinks | QDir::NoDot | QDir::NoDotDot);

    QString Path = "";

    foreach (QFileInfo fileInfo, dir.entryInfoList())
    {
        if (fileInfo.fileName().startsWith("2D."))
        {
            Path = fileInfo.fileName();
            break;
        }
    }

    if (Path.length() > 0)
    {
        QString fileName = QString("/app/1wire/%1/memory").arg(Path);

        QFile file(fileName);

        if(file.exists())
        {
            if(file.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QTextStream stream(&file);

                if (!stream.atEnd())
                {
                    Ret = stream.readLine().remove(QChar::Null);

                    qDebug() << "FS: Codice Piastra: " << Ret;
                }

                file.close();
            }
        }
    }
    else
        qDebug() << "Si è verificato un errore durante la lettura del codice piastra";

    return Ret;
}

/******************************************/
bool MainWindow::CP_Write(QString Codice)
/******************************************/
{
    bool Ret = false;

    QDir dir("/app/1wire");

    dir.setFilter(QDir::Dirs | QDir::NoSymLinks | QDir::NoDot | QDir::NoDotDot);

    QString Path = "";

    foreach (QFileInfo fileInfo, dir.entryInfoList())
    {
        if (fileInfo.fileName().startsWith("2D."))
        {
            Path = fileInfo.fileName();
            break;
        }
    }

    if (Path.length() > 0)
    {
        QString fileName = QString("/app/1wire/%1/memory").arg(Path);

        QFile file(fileName);

        if(file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text ))
        {
            QTextStream out(&file);

            out << Codice << "\0";

            file.close();

            Ret = true;
        }

    }

    return Ret;
}

/********************************************************/
int MainWindow::Read_ConfigurazioneAgenzia( int CodiceAgenzia, QString CodicePiastra )
/********************************************************/
{
    int ConfigError       = -3;

    QString ConfigMessage = "";

    clsWebService *WS = new clsWebService();

    QString Path = Global::PortalBigo;

    QString Temp;

    Temp.sprintf("%04d", CodiceAgenzia);

    Path += QString("/api/deviceonboard/settings?deviceTypeId=1&plateId=%1%2").arg(Temp).arg(CodicePiastra);

    QVariantMap  Resp;

    bool Ok = WS->WSCall(Path, Global::PortalApiKey);

    if (Ok)
    {
        Resp = QVariant(QtJson::parse(WS->Web_Response)).toMap();

        ConfigError   = Resp["Status"].toInt();
        ConfigMessage = Resp["Message"].toString();

        if (ConfigError >= 0)
        {
            qDebug() << "Impostazioni base dispositivo" << Resp["deviceOptions"].toString();

            QVariantMap device = QVariant(Resp["deviceOptions"]).toMap();

            Global::Agenzia         = device["Code"].toString();
            Global::ApiKey          = device["ApiKey"].toString();
            Global::BigoPoint       = device["ApiServer"].toString();

            if (Global::BigoPoint == "10.5.0.1") Global::BigoPoint = "https://portal.bigosolutions.it";
            if (Global::BigoPoint == "10.6.0.1") Global::BigoPoint = "https://dev.bigosolutions.it";
            if (Global::BigoPoint == "10.9.0.1") Global::BigoPoint = "https://portal.bigosolutions.it";

            Global::MqttServer      = device["MqttServer"].toString();

            if (Global::MqttServer == "10.5.0.1") Global::MqttServer = "mqtt.bigosolutions.it";
            if (Global::MqttServer == "10.6.0.1") Global::MqttServer = "test.bigosolutions.it";
            if (Global::MqttServer == "10.9.0.1") Global::MqttServer = "sais.bigosolutions.it";

            Global::MqttPort        = device["MqttPort"].toInt();
            Global::MqttUser        = device["MqttUser"].toString();
            Global::MqttPsw         = device["MqttPwd"].toString();

            Global::IDAgenzia = CodiceAgenzia;

            DBase->WriteParam("IDAgenzia" , Global::IDAgenzia);
            DBase->WriteParam("Agenzia"   , Global::Agenzia);
            DBase->WriteParam("ApiKey"    , Global::ApiKey);
            DBase->WriteParam("EndPoint"  , Global::BigoPoint);
            DBase->WriteParam("MqttServer", Global::MqttServer);
            DBase->WriteParam("MqttPort"  , Global::MqttPort);
            DBase->WriteParam("MqttUser"  , Global::MqttUser);
            DBase->WriteParam("MqttPwd"   , Global::MqttPsw);
        }
    }

    return ConfigError;
}

/*****************************************************************/
int MainWindow::MqttSendMessage(QString Topics, QString Text)
/*****************************************************************/
{
    int MsgID = -1;

    if (MqttClient != nullptr)
    {
        if (MqttClient->isConnectedToHost())
        {
            QMQTT::Message msg;
            msg.setTopic(Topics);
            msg.setQos(1);

            msg.setPayload(Text.toLocal8Bit());

            MsgID = MqttClient->publish(msg);

            #ifdef DEBUG
                qDebug() << "MQTT sent MsgID: " << MsgID;
            #endif
        }
    }

    return MsgID;
}


