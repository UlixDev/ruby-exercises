#include "clssimulatore.h"
#include "clsgtfs.h"
#include "Positioning/qgeocoordinate.h"

#include <QFile>
#include <QTextStream>
#include <QLocale>
#include <QDebug>

#include "global.h"


clsSimulatore::clsSimulatore(QObject *parent) : QThread(parent)
{
    Gps = new QList<GpsData>();

    clsGtfs Gtfs;

    Gtfs.Load_Shapes( "LANC_CHIETI " );

    /***********************************************************
     *  Calcolo il totale Km
     ***********************************************************/

    float Km = 0;

    QGeoCoordinate A;
    QGeoCoordinate B;

    for (int j = 0; j < Gtfs.GTFS_Shapes->count()-1; j++)
    {
        A.setLatitude ( Gtfs.GTFS_Shapes->at(j)->Lat );
        A.setLongitude( Gtfs.GTFS_Shapes->at(j)->Lng );

        B.setLatitude ( Gtfs.GTFS_Shapes->at(j+1)->Lat );
        B.setLongitude( Gtfs.GTFS_Shapes->at(j+1)->Lng );

        Gtfs.GTFS_Shapes->at(j+1)->Course = A.azimuthTo(B);

        Km += A.distanceTo(B);

        Gtfs.GTFS_Shapes->at(j)->Metri = A.distanceTo(B);
    }

    float Tempo = 3300;

    float Veloc = Km / Tempo;


    for (int j=0; j<Gtfs.GTFS_Shapes->count(); j++)
    {
        GShape *T = Gtfs.GTFS_Shapes->at(j);

        GpsData Data;

        Data.Coord.setLatitude (T->Lat);
        Data.Coord.setLongitude(T->Lng);

        Data.mTime =  (T->Metri * 500) / Veloc;

        Data.Coord.setAccuracy(0);
        Data.Coord.setCourse(T->Course);
        Data.Coord.setSpeed(12 + qrand() % 8);
        Data.PassIN         = 0;
        Data.PassOUT        = 0;
        Data.StopID         = "";
        Data.GpsFix         = true;

        Gps->append(Data);
    }

    // LoadFile( "./Simul/LN1_007A.TXT" );
}

void clsSimulatore::run()
{
    int Index = 0;

    while (Global::Running)
    {
        if (Gps->count() > 0)
        {
            emit DataReady( Gps->at(Index) );

            QThread::msleep(Gps->at(Index).mTime );

            Index = (Index + 1) % Gps->count();
        }
        else
            QThread::msleep(2000);
    }
}

clsSimulatore::~clsSimulatore()
{

}

int clsSimulatore::LoadFile( QString FileName )
{
    int Ret = 0;

    if (Gps->count() > 0)
        Gps->clear();

    QLocale Ita( QLocale::Italian );

    QFile FileIn(FileName);

    if (FileIn.open( QIODevice::ReadOnly ))
    {
        QTextStream in(&FileIn);

        QString Line = in.readLine();

        while(!in.atEnd())
        {
            Line = in.readLine();

            QStringList Token = Line.split(";");

            if (Token.count() >= 4)
            {
                GpsData Data;

                int Ore = QString(Token.at(0).mid(0,2)).toInt();
                int Min = QString(Token.at(0).mid(3,2)).toInt();
                int Sec = QString(Token.at(0).mid(6,2)).toInt();
                int mSe = QString(Token.at(0).mid(9,3)).toInt();

                Data.mTime = (long)Ore * 3600000 + (long)Min * 60000 + (long)Sec * 1000 + (long)mSe;

                Data.Coord.setLatitude (Ita.toFloat(QString(Token.at(1))));
                Data.Coord.setLongitude(Ita.toFloat(QString(Token.at(2))));

                Data.Coord.setAccuracy (Ita.toFloat(QString(Token.at(3))));
                Data.Coord.setCourse   (Ita.toFloat(QString(Token.at(5))));
                Data.Coord.setSpeed    (Ita.toFloat(QString(Token.at(7))));
                Data.PassIN         = QString(Token.at(8)).toInt();
                Data.PassOUT        = QString(Token.at(9)).toInt();
                Data.StopID         = QString(Token.at(10));
                Data.GpsFix         = true;

                Gps->append( Data );
            }
        }

        FileIn.close();

        return true;
    }

    return Ret;
}

