#include "clspayload.h"
#include "clswebservice.h"
#include "dbmanager.h"
#include "json.h"
#include "global.h"

#include <QThread>
#include <QtMath>
#include <QProcess>

using QtJson::JsonObject;
using QtJson::JsonArray;

clsPayload::clsPayload(QString s) : name(s)
{
    m_mx = new QMutex(QMutex::Recursive);

    DBase = new DBManager( this, "DB_Payload");

    DBase->Open();

    LastNetSend = QDateTime::fromMSecsSinceEpoch(0);
}

void clsPayload::run()
{
    QString Sql = QString("DELETE FROM Payload WHERE Done=0");
    //QString Sql = QString("DELETE FROM Payload"); // SERGIO

    DBase->ExecuteQuery(Sql);

    QDateTime LastPing = QDateTime::fromSecsSinceEpoch(0);

    while (Global::Running)
    {
        QDateTime Now = Global::CurrentTime();

        /******************************
         * PING MONITOR XIBO & VTec
         ******************************/

        if (Global::XiboIP.length() > 6 )
        {
            quint64 TPing = (LastPing.secsTo(Now));

            if ( qFabs(TPing) >= 30) // SERGIO era 5
            {
                LastPing = Now;

                QStringList parameters;

                parameters << "-c1";
                parameters << Global::XiboIP;
                Global::XiboStatus = QProcess::execute("ping", parameters);
                qDebug() << "XIBO: " << Global::XiboStatus;

                /******************************
                 * PING VTEC
                 ******************************/

                if (Global::VTecMaster == false)
                {
                    for(int j=0; j<VTecDevice->count(); j++)
                    {
                        clsVTec *V = VTecDevice->at(j);

                        if (V->IP.length() > 6 )
                        {
                            parameters.clear();

                            parameters << "-c1";
                            parameters << V->IP;

                            int Ex = QProcess::execute("ping", parameters);

                            V->Status = (Ex==0) ? clsVTec::eVTecStatus::Up : clsVTec::eVTecStatus::Down;
                        }
                    }
                }
            }
        }



        Spooler();

        QThread::msleep(500);
    }
}

/****************************************************/
bool clsPayload::PushMessage(QString Command, TrackInfo Info)
/****************************************************/
{
    QVariantMap Map;

    Map["Time"]     = QVariant( QDateTime(Info.Time).toString("yyyy-MM-dd HH:mm:ss") );
    Map["Imei"]     = QVariant(Info.Imei);
    Map["Mezzo"]    = QVariant(Info.Mezzo);
    Map["DutyID"]   = QVariant(Info.DutyID);
    Map["TripID"]   = QVariant(Info.TripID);
    Map["StopID"]   = QVariant(Info.StopID);
    Map["Event"]    = QVariant(Info.Event);
    Map["Cond"]     = QVariant(Info.Cond);

    Map["Lat"]      = QVariant(Info.Lat);
    Map["Lng"]      = QVariant(Info.Lng);
    Map["Speed"]    = QVariant(Info.Speed);
    Map["Odo"]      = QVariant(Info.Odo);

    Map["Fore_Time"] = QVariant(Info.Fore_Time);
    Map["Fore_Stop"] = QVariant(Info.Fore_Stop);

    Map["Rit"]      = QVariant(Info.Rit);
    Map["Sosta"]    = QVariant(Info.Sosta);
    Map["PeopleIN"]  = QVariant(Info.PassIN);
    Map["PeopleOUT"] = QVariant(Info.PassOUT);
    Map["Batt"]     = QVariant(Info.Batt);
    Map["Motore"]   = QVariant(Info.Motore);

    Map["Porte"]    = QVariant(Info.Porte);
    Map["Sinc"]     = QVariant(Info.Sinc);
    Map["Ang"]      = QVariant(Info.Ang);

    bool Ok = false;

    if (Global::Imei.length() > 0)
    {
        QString JS = QtJson::serialize(Map, Ok);

        qDebug() << JS;

        if (Ok)
        {
            //qDebug() << "Waiting insert Payload...";
            QMutexLocker locker(m_mx);
            //qDebug() << "Insert Payload...";
            QString Sql = QString("INSERT INTO Payload (Command, Payload, Done) VALUES ('%1', '%2', 10)").arg(Command).arg(JS);

            int Ret = DBase->ExecuteQuery(Sql);

            Ok = (Ret == 1);

            if (!Ok)
            {
                clsWebService *WS = new clsWebService();

                if (Global::Agenzia.length() > 0)
                {
                    bool Ok = false;

                    JS = JS.replace("\n", "");

                    QUrlQuery PostData;
                    PostData.addQueryItem("Azienda", Global::Agenzia);
                    PostData.addQueryItem("Rev"    , ""         );
                    PostData.addQueryItem("Command", Command    );
                    PostData.addQueryItem("AziendaUtilizzo", "" );
                    PostData.addQueryItem("JS"     , JS         );

                    QString Path = Global::EndPoint + "gtfs.asmx/SendMessage";

                    Ok = WS->WSPostCall( Path, PostData );
                }
            }
        }
    }

    return Ok;
}

/****************************************************/
bool clsPayload::PushMessage(QString Command, QString Data )
/****************************************************/
{
    //QMutexLocker locker(m_mx);

    QString Sql = QString("INSERT INTO Payload (Command, Payload, Done) VALUES ('%1', '%2', 10)").arg(Command).arg(Data);

    int Ret = DBase->ExecuteQuery(Sql);

    return (Ret == 1);
}

/****************************************************/
bool clsPayload::Spooler()
/****************************************************/
{
    static bool First = true;

    bool Res = false;
    bool Ok  = false;

    QString Sql;

    QSqlQuery Qry = DBase->GetRecord("SELECT * FROM Payload WHERE (Done > 0) ORDER BY ID LIMIT 1");

    QString Path;

    clsWebService *WS = new clsWebService();

    if (First)
    {
        First = false;

        /*****************************
         * LOGIN
         *****************************/

        QUrlQuery PostData;
        PostData.addQueryItem("Azienda" , Global::Agenzia  );
        PostData.addQueryItem("Imei"    , Global::Imei     );
        PostData.addQueryItem("AppName" , "CRT"            );
        PostData.addQueryItem("Versione", Global::Versione );
        PostData.addQueryItem("IdMezzo" , Global::Mezzo    );
        PostData.addQueryItem("AziendaUtilizzo", "" );

        Path = Global::EndPoint + "gtfs.asmx/Login";

        Ok = WS->WSPostCall( Path, PostData );

        qDebug() << "Login result: " << Ok;
    }

    while (Qry.next())
    {
        if (Global::Agenzia.length() > 0)
        {
            Ok = false;

            int ID          = DBase->GetIFromName( Qry, "ID");
            int Done        = DBase->GetIFromName( Qry, "Done");
            QString Command = DBase->GetSFromName( Qry, "Command");
            QString Payload = DBase->GetSFromName( Qry, "Payload");

            if (Command == "DIAGNO")
            {
                Path = QString("%1/api/tracker/%2/diagnostic").arg(Global::BigoPoint).arg(Global::Agenzia);

                Ok = WS->WSPostCall_Api( Path, Payload.toLocal8Bit() );

                if (Ok)
                    LastNetSend = Global::CurrentTime();
            }
            else
            {
                Payload = Payload.replace("\n", "");

                QUrlQuery PostData;
                PostData.addQueryItem("Azienda", Global::Agenzia);
                PostData.addQueryItem("Rev"    , "1"         );
                PostData.addQueryItem("Command", Command     );
                PostData.addQueryItem("JS"     , Payload     );
                PostData.addQueryItem("AziendaUtilizzo" , "" );

                Path = Global::EndPoint + "gtfs.asmx/SendMessage";

                Ok = WS->WSPostCall( Path, PostData );

                if (Ok)
                    LastNetSend = Global::CurrentTime();
            }

            if (Ok)
            {
                m_mx->lock();
                Sql = QString("UPDATE Payload SET Done=0 WHERE ID=%1").arg(ID);
                DBase->ExecuteQuery(Sql);
                m_mx->unlock();
            }
        }
        else
            break;
    }

    delete WS;

    return Res;
}


