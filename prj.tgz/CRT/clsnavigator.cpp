#include "clsnavigator.h"
#include "global.h"
#include "clstools.h"
#include "logger.h"
#include "json.h"

#include <QDateTime>
#include <QtMath>
#include <QMap>
#include <QList>

#define EPS 0.00001

clsNavigator::clsNavigator(QObject *parent) : QThread(parent)
{
    Forecast = new clsForecast();

    CurTrip  = new QList<GTrack*>();
    CurStops = new QMap <QString,GStops*>();

    LastMeterOk = Global::CurrentTime();

    Deposito.setAltitude (0);
    Deposito.setLongitude(7);
    Deposito.setLatitude (40);

    BusInfo = new clsBusInfo();
}

clsNavigator::~clsNavigator()
{
}

void clsNavigator::run()
{
    while (Global::Running)
    {
        if (FL_NewPosition)
        {
            FL_NewPosition = false;

            ChangeTrip.lock();
            {
                FirstPoint = Localize( FirstPoint, CurrentPosition );

                if (FirstPoint < 0) FirstPoint = 0;
            }
            ChangeTrip.unlock();

            emit BusInfoUpdated (BusInfo);

            if (NavState == eNavState::FineCorsa)
            {
                FirstPoint = 0;

                NavState = eNavState::FuoriServizio;

                if (Global::EnableSimulatore)
                {
                    QDateTime Now  = Global::CurrentTime();
                    QDateTime Data = QDateTime(Now.date());

                    int TRif = CurTrip->at(0)->Arrival_Time;

                    for (int i = 0; i< CurTrip->count(); i++)
                    {
                        GTrack *T = CurTrip->at(i);

                        if (T->Marker != eMarker::Auto)
                        {
                            int Oft = T->Departure_Time - TRif;

                            T->Departure_Time = (int)Data.secsTo(Now) + Oft;
                            T->Arrival_Time   = (int)Data.secsTo(Now) + Oft;
                            T->Orario_Statico = Data.addSecs(T->Departure_Time);
                        }
                    }
                }
            }
        }
        else
        {
            usleep(500000);
        }
    }
}

/**********************************************************/
void clsNavigator::NewPosition(QGeoCoordinate Data)
/**********************************************************/
{
    ChangeLoc.lock();

    CurrentPosition = Data;

  //CurrentPosition.setGpsTime(Data.TimeStamp);

    qDebug() << QString("Lat: %1  Lng: %2").arg(CurrentPosition.latitude()).arg(CurrentPosition.longitude());

    FL_NewPosition = true;

    ChangeLoc.unlock();
}

/**********************************************************/
void clsNavigator::NewTrips(QString DutyID, QString TripID)
/**********************************************************/
{
    if ( Global::TripID != TripID ||  ( TripID == "" && DutyID != "" ) )
    {
        ChangeTrip.lock();

        QString Trip = SetNavigationData(DutyID, TripID);

        Logger::Info("NAV", QString("SetNavigationData DutyID:%1 TripID:%2").arg(DutyID).arg(TripID));

        if (Trip != "")
        {
            CurTrip  = GTFS->GTFS_Track;

            CurStops = GTFS->GTFS_Stops;

            clsPalina *Pal = BusInfo->Paline->at(0);

            Pal->StopID   = "";
            Pal->oStopID  = "";
            Pal->Distanza = 0;

            Global::TripID = Trip;

            CurrentPalina = -1;
            FL_Cap_Arm    = false;
            FirstPoint    = 0;
            NavState      = eNavState::AttesaPartenza;

            if (Global::EnableSimulatore)
            {
                QDateTime Now  = Global::CurrentTime();
                QDateTime Data = QDateTime(Now.date());

                int TRif = CurTrip->at(0)->Arrival_Time;

                for (int i = 0; i< CurTrip->count(); i++)
                {
                    GTrack *T = CurTrip->at(i);

                    if (T->Marker != eMarker::Auto)
                    {
                        int Oft = T->Departure_Time - TRif;

                        T->Departure_Time = Data.secsTo(Now) + Oft;
                        T->Arrival_Time   = Data.secsTo(Now) + Oft;
                        T->Orario_Statico = Data.addSecs(T->Departure_Time);
                    }
                }
            }
        }

        ChangeTrip.unlock();
    }
}

/**********************************************************/
QString clsNavigator::SetNavigationData( QString DutyID, QString TripID)
/**********************************************************/
{
    QGeoCoordinate A;
    QGeoCoordinate B;

    GTFS = new clsGtfs();

    GTFS->Load_Turni("", Global::CurrentTime());

    if (TripID.length() == 0)
    {
        TripID = FindTrip( GTFS->GTFS_Turni, DutyID, eDutyType::OPR );

        if (TripID.length() == 0)
        {
            Logger::Info( "NAV", QString("Nessuna corsa prossima alla partenza"));

            return "";
        }
    }

    GTurni *Turno = GTFS->GTFS_Turni->value(TripID);

    if (Turno == nullptr)
    {
        Logger::Info( "NAV", QString("Corsa %1 no trovata in turni").arg(TripID));

        return "";
    }

    int nTrip = GTFS->Load_Trips( TripID );

    if (nTrip != 1)
    {
        Logger::Info( "NAV", "Trip not found");

        return "";
    }

    Logger::Info( "NAV", "Set new Trip:" + TripID);

    if ( nTrip==1 && Turno != nullptr)
    {
         GTFS->Load_Track( GTFS->GTFS_Trips->value(TripID)->Shape_Id );

         GTFS->Load_StopsTime(TripID);

         GTFS->Load_Stops();

         GTFS->Load_Routes();

         /***********************************************************
          *  Calcolo il progressivo metri
          ***********************************************************/

         for (int j = 1; j < GTFS->GTFS_Track->count(); j++)
         {
             A.setLatitude ( GTFS->GTFS_Track->at(j)->Lat );
             A.setLongitude( GTFS->GTFS_Track->at(j)->Lng );

             B.setLatitude ( GTFS->GTFS_Track->at(j-1)->Lat );
             B.setLongitude( GTFS->GTFS_Track->at(j-1)->Lng );

             double Mt = A.distanceTo(B);

             qDebug() << "Metri " << Mt;

             GTFS->GTFS_Track->at(j)->Metri = Mt;
         }

         /***********************************************************
          *  Posiziono le fermate sullo shape corrente
          ***********************************************************/

         int Index = 0;

         for (int k = 0; k < GTFS->GTFS_Track->count(); k++)
         {
             GTrack *T = GTFS->GTFS_Track->at(k);

             if ( T->Marker != eMarker::Auto )
             {
                 QString StopID = GTFS->GTFS_StopTimes->at(Index)->Stop_Id;

                 GStops *Stop = GTFS->GTFS_Stops->value(StopID);

                 if ( Stop != nullptr)
                 {
                     if (Index == 0)
                         T->Marker = eMarker::Capolinea;
                     else if (Index == GTFS->GTFS_StopTimes->count() - 1)
                         T->Marker = eMarker::FineLinea;
                     else
                         T->Marker = eMarker::Palina;

                     T->StopID      = Stop->Stop_ID;
                     T->Stop_Index  = Stop->StopIndex;
                     T->Radius      = Stop->Radius;
                     T->Seq         = GTFS->GTFS_StopTimes->at(Index)->Stop_Sequence;
                 }

                 Index++;
             }
         }

         /***********************************************************
          * Calcolo angolo e distanze dello shape corrente
          * Per ogni fermata calcolo il tempo previsto di arrivo
          ***********************************************************/

         QDateTime DataRif = QDateTime(Turno->Data_Partenza.date());

         float Metri = 0;

         int FS = 0;

         for (int j = 0; j < GTFS->GTFS_Track->count(); j++)
         {
             GTrack *T = GTFS->GTFS_Track->at(j);

             if (j < GTFS->GTFS_Track->count() - 1)
             {
                 A.setLatitude ( GTFS->GTFS_Track->at(j)->Lat );
                 A.setLongitude( GTFS->GTFS_Track->at(j)->Lng );

                 B.setLatitude ( GTFS->GTFS_Track->at(j+1)->Lat );
                 B.setLongitude( GTFS->GTFS_Track->at(j+1)->Lng );

                 double Angle = A.azimuthTo(B);

                 if (Angle < 0) Angle = 360 + Angle;

                 T->Angolo   = Angle;
                 T->Distance = A.distanceTo(B);
                 T->Metri    = Metri;

                 Metri += T->Distance;
             }

             if (T->Marker != eMarker::Auto)
             {
                 for (int k = FS; k < GTFS->GTFS_StopTimes->count(); k++)
                 {
                     if (T->StopID == GTFS->GTFS_StopTimes->at(k)->Stop_Id)
                     {
                         GTFS->GTFS_StopTimes->at(k)->TrackPtr = j;

                         T->Arrival_Time   = clsTools::ConvertMTime2Sec( GTFS->GTFS_StopTimes->at(k)->Arrival_Time  );
                         T->Departure_Time = clsTools::ConvertMTime2Sec( GTFS->GTFS_StopTimes->at(k)->Departure_Time);

                         T->Orario_Statico = DataRif.addSecs( T->Arrival_Time % 86400 );

                         FS++;

                         break;
                     }
                 }
             }
         }

         /***********************************************************
          * Calcolo per ogni punto intermedio il tempo previsto
          * di passaggio
          ***********************************************************/

         for (int j = 0; j < GTFS->GTFS_StopTimes->count() - 1; j++)
         {
             int PA = -1;
             int PB = -1;

             if (GTFS->GTFS_StopTimes->at(j)->Enabled )
             {
                 PA = GTFS->GTFS_StopTimes->at(j)->TrackPtr;

                 for (int k = j + 1; k < GTFS->GTFS_StopTimes->count(); k++)
                 {
                     if (GTFS->GTFS_StopTimes->at(k)->Enabled )
                     {
                         PB = GTFS->GTFS_StopTimes->at(k)->TrackPtr;
                         break;
                     }
                 }

                 if (PA >= 0 && PB >= 0)
                 {
                     double Spazio = GTFS->GTFS_Track->at(PB)->Metri - GTFS->GTFS_Track->at(PA)->Metri;
                     double Tempo  = GTFS->GTFS_Track->at(PB)->Arrival_Time - GTFS->GTFS_Track->at(PA)->Arrival_Time;
                     double Veloc  = Spazio / Tempo;

                     QDateTime TRif = GTFS->GTFS_Track->at(PA)->Orario_Statico;
                     double    SRif = GTFS->GTFS_Track->at(PA)->Metri;

                     for (int k = PA + 1; k < PB; k++)
                     {
                         Spazio = GTFS->GTFS_Track->at(k)->Metri - SRif;

                         Tempo = Spazio / Veloc;

                         GTFS->GTFS_Track->at(PB)->Orario_Statico = TRif.addSecs(Tempo);
                     }
                 }
             }
         }

         /************************************************
          * Calcolo i tempi di percorrenza di tutte
          * le tratte in funzione dell'orario di
          * passaggio statico per il servizio selezionato
          ************************************************/

         double Dist  = 0;
         double Speed = 0;
         double Km    = 0;
         int StartTime = 0;
         int StopTime  = 0;
         int Elapsed   = 0;
         bool First   = true;

         for (int j = 0; j < GTFS->GTFS_Track->count(); j++)
         {
             GTrack *T = GTFS->GTFS_Track->at(j);

             if (T->Marker != eMarker::Auto)
             {
                 if (First)
                 {
                     First = false;
                     StartTime = T->Arrival_Time;
                 }
                 else
                 {
                     StopTime = T->Arrival_Time;

                     Elapsed = StopTime - StartTime;

                     if (Elapsed == 0) Elapsed = 30;

                     if (Elapsed > 0)
                     {
                         Speed = Dist / Elapsed;

                         Dist = 0;

                         for (int i = j - 1; i >= 0; i--)
                         {
                             GTrack *Tr = GTFS->GTFS_Track->at(i);

                             Tr->Velocita_Media = Speed;

                             if (Tr->Marker != eMarker::Auto)
                                 break;
                         }
                     }

                     StartTime = StopTime;
                 }
             }

             Dist += T->Distance;

             Km += T->Distance;
         }

         if (GTFS->GTFS_Track->count() > 0)
         {
             int Rit = Global::CurrentTime().secsTo( GTFS->GTFS_Track->at(0)->Orario_Statico );
             if (Rit > 7200 ) Rit = 7200;
             if (Rit < -7200) Rit = -7200;

             Global::RitardoCorsa = -Rit;
         }

         Logger::Info( "NAV", QString("Km totali percorso %2: %1 Km")
                      .arg( Km / 1000, 3, 'f',1,'0')
                      .arg( TripID ));

         DutyID  = Turno->DutyID;
         RouteID = Turno->Route_ID;

         Global::DutyID = DutyID;
         Global::TripID  = TripID;
     }

     NavState = eNavState::AttesaPartenza;

     return TripID;
}
/**********************************************************/
int clsNavigator::Localize(int FirstPoint, QGeoCoordinate Loc)
/**********************************************************/
{
    double  DistMax  = 50;
    double  DistNext = 0;
    double  DistPrec = 0;
    int     iNode    = -1;
    float   CurMetri = 0;
    int     WaitTime = 0;
    QDateTime Now;

    QGeoCoordinate A;
    QGeoCoordinate B;

    Now = Global::CurrentTime();

    clsWinner Winner;

    if (CurTrip->count() > 1)
    {
        qDebug() << "Lat=" << Loc.latitude() << "Lng=" << Loc.longitude();

        for (int i = FirstPoint; i< (CurTrip->count() - 1); i++)
        {
            A.setLatitude ( CurTrip->at(i)->Lat);
            A.setLongitude( CurTrip->at(i)->Lng);
            A.setAltitude (0);

            B.setLatitude ( CurTrip->at(i+1)->Lat);
            B.setLongitude( CurTrip->at(i+1)->Lng);
            B.setAltitude (0);

            double a = B.distanceTo(Loc);
            double b = A.distanceTo(Loc);
            double c = B.distanceTo(A);

            if (fabs(a) <= EPS) continue;
            if (fabs(c) <= EPS) continue;

            if (fabs(b) <= EPS)
            {
                DistNext = c;
                DistMax  = 0;
                iNode    = i;
                continue;
            }

            double p = (a + b + c) / 2;

            double AreaCubo = (p * (p - a) * (p - b) * (p - c));

            double H = 0;

            if (AreaCubo > 0)
            {
                double Area = sqrt(AreaCubo);

                H = (2 * Area) / c;
            }

            if (H < 50)
            {
                double AngA = (asin(H / b));
                double AngB = (asin(H / a));

                double d = a * cos(AngB);
                double e = b * cos(AngA);

                if ((d <= c) && (e <= c))
                {
                    Winner.Push(H, i, e, d);

                    if (H < DistMax)
                    {
                        DistPrec = e;
                        DistNext = d;
                        DistMax = H;
                        iNode = i;
                    }
                }
                else
                {
                    if (i == 0 && b <= 50)
                    {
                        DistPrec = b;
                        DistNext = b + c;
                        DistMax = H;
                        iNode = i;
                    }
                }
            }
        }

        if (iNode >= 0)
        {
            if (Winner.Win->count() > 0)
            {
                int iN = -1;

                double Dif_A = Winner.Win->at(0).Value;

                double wMin = 9999999;

                bool Good = false;

                for (int j = 0; j < Winner.Win->count(); j++)
                {
                    Good = true;

                    if (Counter_iNodeOk > 5)
                    {
                        if (Winner.Win->at(j).Node < Last_iNode_Ok)
                        {
                            //Logger.Info(Global.NavTag, "NAV: Skip arbitraggio " + Winner.Win[j].Node.ToString());
                            Good = false;
                        }
                    }

                    if (Good)
                    {
                        QDateTime OS = CurTrip->at(Winner.Win->at(j).Node)->Orario_Statico.addSecs(Global::RitardoCorsa);

                        Dif_A = abs(Now.secsTo(OS));

                        //Logger.Info(Global.NavTag, String.Format("------>{0} Tempo {1}", Winner.Win[j].Node, Dif_A));

                        if (Dif_A < wMin)
                        {
                            wMin = Dif_A;
                            iN = j;
                        }
                        else
                            Good = false;
                    }
                }

                if (iN >= 0)
                {
                    DistPrec = Winner.Win->at(iN).DistPrec;
                    DistNext = Winner.Win->at(iN).DistNext;
                    DistMax  = Winner.Win->at(iN).Value;
                    iNode    = Winner.Win->at(iN).Node;
                }
            }

            //Logger.Info(Global.NavTag, String.Format("Winner {0}", iNode));
        }
    }

    float   DCap    = 0;
    bool    FL_Cap  = false;
    bool    FL_Arr  = false;

    GTrack *sTrack;
    GTrack *eTrack;
    GTrack *cTrack;

    /********************************
     * DEPOSTITO
     ********************************/

    DCap = Deposito.distanceTo(Loc);

    bool FL_Dep = DCap < Global::IntornoDeposito;

    if (CurTrip->count() > 1)
    {
        int n = CurTrip->count() - 1;

        sTrack = CurTrip->at(0);
        eTrack = CurTrip->at(n);

        /********************************
         * Capolinea di partenza
         ********************************/

        A.setLatitude ( sTrack->Lat );
        A.setLongitude( sTrack->Lng );
        A.setAltitude (0);

        DCap = A.distanceTo(Loc);

        FL_Cap = DCap < sTrack->Radius;

        if (FL_Cap)
            FL_Cap_Arm = true;

        /********************************
         * Capolinea di Arrivo
         ********************************/

        A.setLatitude ( eTrack->Lat );
        A.setLongitude( eTrack->Lng );

        DCap = A.distanceTo(Loc);

        FL_Arr = DCap < eTrack->Radius;

        /********************************
         *
         ********************************/

        if (FL_Arr &&  (NavState != eNavState::Navigation) && (NavState != eNavState::AttesaPartenza) )
        {
            double DurataCorsa = eTrack->Orario_Statico.secsTo( sTrack->Orario_Statico );

            if ( Now.secsTo(eTrack->Orario_Statico) > -(DurataCorsa / 2))
            {
                Global::LK_ClearTurni.lock();
                {
                    if ( !Global::TurniFatti->contains( Global::TripID) )
                    {
                        Global::TurniFatti->append(Global::TripID);

                        Logger::Info("NAV", "Corsa bruciata per arrivo a capolinea");
                    }

                    Global::StopID    = eTrack->StopID;
                    Global::TripID    = "";
                    Global::FL_FineCorsa = true;

                    SendEvent( "arrival",
                               eTrack->StopID,
                               eTrack->Lat,
                               eTrack->Lng );

                    NavState = eNavState::FineCorsa;

                    iNode = 0;
                }
                Global::LK_ClearTurni.unlock();
            }
        }
    }

    if ( iNode >= CurTrip->count() ) iNode = -1;

    if (iNode >= 0)
    {
        qDebug() << "iNode = " << iNode;

        cTrack = CurTrip->at(iNode);

        /****** Distanza percorsa dal capolinea ******/

        CurMetri = (float)(cTrack->Metri + DistPrec);

        /*****************************************************
         * Calcolo quante localizzazioni positive consecutive
         * sono state effettuate
         *****************************************************/

        if (CurMetri >= OldMetri + 4)
        {
            PositiveLoc = PositiveLoc + 1;

            OldMetri = CurMetri;

            LastMeterOk = Global::CurrentTime();
        }
        else
        {
            if (CurMetri <= OldMetri - 4)
            {
                PositiveLoc = 0;

                OldMetri = CurMetri;
            }
        }
    }

    //Logger.Info(Global.NavTag, string.Format("NAVSTATE: {0} CurMetri {1:0.00}  OldMetri {2:0.00} PositiveLoc {3}", NavState.ToString(), CurMetri, OldMetri, PositiveLoc));

    if (NavState != oNavState)
    {
        oNavState = NavState;

        LastStateChange = Now;

        Logger::Info( "NAV", QString("Nuovo stato: %1").arg( QVariant::fromValue(NavState).value<QString>() ));
    }

    if (CurTrip->count() > 0)
    {
        int Rit;
        int I;

        switch (NavState)
        {
            case eNavState::AttesaPartenza:

                Rit = Now.secsTo( sTrack->Orario_Statico );

                if (Rit >  86400) Rit =  86400;
                if (Rit < -86400) Rit = -86400;

                Global::RitardoCorsa = -Rit;

                I = 1;

                for (int j=0; j<CurTrip->count(); j++)
                {
                    cTrack = CurTrip->at(j);

                    if (cTrack->Marker != eMarker::Auto)
                    {
                        if (I < BusInfo->Paline->count())
                        {
                            clsPalina *Pal = BusInfo->Paline->at(I);

                            Pal->Visible = true;
                            Pal->StopID  = cTrack->StopID;
                            Pal->oStopID = cTrack->StopID;
                            Pal->TripPtr = 0;
                            Pal->Name    = CurStops->value(Pal->StopID)->Stop_Code;
                            Pal->Desc    = CurStops->value(Pal->StopID)->Stop_Name;

                            Pal->OrarioStatico    = cTrack->Orario_Statico;
                            Pal->PrevisioneArrivo = cTrack->Orario_Statico;

                            I += 1;
                        }
                    }
                }

                for (int j=I; j< BusInfo->Paline->count(); j++)
                {
                    BusInfo->Paline->at(j)->Visible = false;
                }

                if (Loc.speed() >= 5 && !FL_Cap)
                {
                    NavState = eNavState::Waiting;

                    if (FL_Cap_Arm)
                    {
                        SendEvent("departure",
                              CurTrip->at(0)->StopID,
                              CurTrip->at(0)->Lat,
                              CurTrip->at(0)->Lng );

                        FL_Cap_Arm = false;
                    }
                }
                else
                {
                    if (iNode == 0 && FL_Cap)
                    {
                        Global::Proiezione.setLatitude (sTrack->Lat);
                        Global::Proiezione.setLongitude(sTrack->Lng);
                    }
                }

                Counter_iNodeOk = 0;

                break;

            case eNavState::InDeposito:

                if (!FL_Dep)
                {
                    NavState = eNavState::AttesaPartenza;
                    Logger::Info( "NAV", "Esco da Deposito" );
                    Counter_iNodeOk = 0;
                }
                break;

            case eNavState::Lost:

                if (FL_Dep)
                {
                    NavState = eNavState::InDeposito;
                    Logger::Info("NAV", "Entro in deposito");
                }
                else
                {
                    if (iNode >= 0)
                        NavState = eNavState::Waiting;

                    Counter_iNodeOk = 0;
                }

                break;

            case eNavState::Navigation:

                WaitTime = LastLocalizationTime.secsTo(Now);

                if (WaitTime > Global::Seconds_per_Lost)
                {
                    Logger::Info( "NAV", QString("LOST per mancato sinc dopo %1 secondi").arg(WaitTime));

                    NavState = eNavState::Lost;

                    Global::TripID = "";
                }

                WaitTime = LastMeterOk.secsTo(Now);

                if (WaitTime > 30)
                {
                    Logger::Info( "NAV", QString("Vado in waiting per navigazione al contrario").arg(WaitTime));

                    NavState = eNavState::Waiting;
                }
                break;

            case eNavState::Waiting:

                WaitTime = LastStateChange.secsTo(Now);

                if ( WaitTime > Global::OutOfSyncTime)
                {
                    NavState = eNavState::Lost;
                    Logger::Info( "NAV", "Esco per OutOfSyncTime" );
                    Global::TripID = "";
                    break;
                }

                if (FL_Dep)
                {
                    NavState = eNavState::InDeposito;
                    Logger::Info( "NAV", "Entro in deposito" );
                    Global::TripID = "";
                    break;
                }

                if (iNode >= 0)
                {
                    if (PositiveLoc >= 5)
                    {
                        NavState = eNavState::Navigation;

                        LastMetri = CurMetri;

                        LastGoodPoint = iNode;

                        Logger::Info( "NAV", QString("NAV: Sync sul punto %1").arg(iNode) );
                    }
                }

                Counter_iNodeOk = 0;

                break;

            default:

                break;
        }

    }

    /***************************************
     * NAVIGATION
     ***************************************/

    if (NavState == eNavState::Navigation)
    {
        if (iNode >= 0)
        {
            LastLocalizationTime = Now;
            LastLocalizationOdo  = Global::Odometro;
            LastMetri 			 = CurMetri;

            if (iNode >= Last_iNode_Ok)
                Counter_iNodeOk += 1;
            else
                Counter_iNodeOk = 0;

            Last_iNode_Ok = iNode;

            if (CurrentPalina == -1)
            {
                /*************************************************
                 * INDIVIDUO LA FERMATA PRECEDENTE
                 *************************************************/

                for (int j = iNode - 1; j >= 0; j--)
                {
                    cTrack = CurTrip->at(j);

                    if (cTrack->Marker != eMarker::Auto)
                    {
                        clsPalina *Pal = BusInfo->Paline->at(0);

                        Pal->StopID   		  = cTrack->StopID;
                        Pal->Sequence 		  = cTrack->Seq;
                        Pal->OrarioStatico    = cTrack->Orario_Statico;
                        Pal->PrevisioneArrivo = Now.addSecs( cTrack->Prevision_Time );
                        Pal->Name             = CurStops->value(Pal->StopID)->Stop_Code;
                        Pal->Desc             = CurStops->value(Pal->StopID)->Stop_Name;

                        if (Pal->StopID != Pal->oStopID)
                        {
                            Pal->oStopID = Pal->StopID;

                            Global::StopID = cTrack->StopID;

                            Global::FL_Change = true;
                        }

                        break;
                    }
                }

                double 	Dist 	 = 0;
                double 	Tempo 	 = 0;
                int 	Raggio   = 0;
                int 	NextStop = 1;

                Forecast->Data   = Now;
                Forecast->TripID = Global::TripID;
                Forecast->Linea  = Global::LineaSN;
                Forecast->Mezzo  = Global::Mezzo.length() > 0 ? Global::Mezzo : Global::Imei;

                Forecast->Paline->clear();

                for (int j = iNode; j < CurTrip->count() - 1; j++)
                {
                    cTrack = CurTrip->at(j);

                    double vMedia   = cTrack->Velocita_Media;
                    double Distance = cTrack->Distance;

                    if (j == iNode)
                        Distance = DistNext;

                    if (vMedia > 0)
                        Tempo += (Distance / vMedia);

                    Dist += Distance;

                    if (CurTrip->at(j + 1)->Marker != eMarker::Auto)
                    {
                        int Prox = j + 1;

                        if (NextStop == 1)
                        {
                            //if (CurTrip->at(Prox)->Marker != eMarker::Palina)
                            //    Raggio = Global::Distanza_Capolinea;
                            //else
                            //    Raggio = Global::Distanza_Palina;

                            Raggio = CurTrip->at(Prox)->Radius;

                            Global::DistanzaDaFermata = Dist;

                            if (CurrentPalina == -1)
                            {
                                if (Dist < Raggio)
                                {
                                    CurrentPalina = Prox;

                                    Logger::Info( "NAV", QString("InPalina(%4)").arg(CurTrip->at(Prox)->StopID));

                                    SendEvent( "arrival",
                                               CurTrip->at(Prox)->StopID,
                                               CurTrip->at(Prox)->Lat,
                                               CurTrip->at(Prox)->Lng );
                                }
                            }

                            BusInfo->Paline->at(NextStop)->InFermata = (CurrentPalina != -1);
                        }

                        /*******************************************************
                         * VERIFICA ARRIVO A CAPOLINEA
                         *******************************************************/

                        if (CurTrip->at(Prox)->Marker == eMarker::FineLinea)
                        {
                            if (Dist < CurTrip->at(Prox)->Radius)
                            {
                                Logger::Info( "NAV", "Arrivo a capolinea");

                                Global::FL_FineCorsa = true;

                                Global::TripID = "";

                                NavState = eNavState::FineCorsa;

                                iNode = -1;
                            }
                        }

                        /*******************************************************
                         *
                         *******************************************************/

                        QDateTime PrevTime = Now.addSecs(Tempo);

                        CurTrip->at(Prox)->Prevision_Time = (int)Tempo;

                        if (NextStop < BusInfo->Paline->count())
                        {
                            clsPalina *Pal = BusInfo->Paline->at(NextStop);

                            Pal->TripPtr          = Prox;
                            Pal->StopID           = CurTrip->at(Prox)->StopID;
                            Pal->Name             = CurStops->value(Pal->StopID)->Stop_Code;
                            Pal->Desc             = CurStops->value(Pal->StopID)->Stop_Name;
                            Pal->PrevisioneArrivo = PrevTime;
                            Pal->OrarioStatico    = CurTrip->at(Prox)->Orario_Statico;
                            Pal->Visible          = true;
                            Pal->Distanza         = Dist;

                            /**************************************
                             * Calcolo Ritardo
                             **************************************/

                            if (NextStop == 2)
                            {
                                int Rit = Pal->PrevisioneArrivo.secsTo(Pal->OrarioStatico);

                                if (Rit >  86400) Rit =  86400;
                                if (Rit < -86400) Rit = -86400;

                                Global::RitardoCorsa = -Rit;
                            }
                        }

                        NextStop++;

                        Forecast->Paline->append(Info(CurTrip->at(Prox)->StopID, PrevTime, CurTrip->at(Prox)->Orario_Statico));
                    }
                }

                /************************************************
                 * Il prossimo test serve per far sparire
                 * dalla palina virtuale la previsione di arrivo
                 ************************************************/

                if (Global::FL_Change)
                {
                    Forecast->Paline->append(Info(BusInfo->Paline->at(0)->oStopID, QDateTime(), BusInfo->Paline->at(0)->OrarioStatico));
                }

                if (!FL_Cap)
                {
                    if (Forecast->Paline->count() > 0)
                    {
                        if (fabs( Now.secsTo(LastForecast)) >= 15)
                        {
                          //Payload.PushCommand("FORECAST", Forecast);

                            LastForecast = Now;
                        }
                    }
                }
            }

            /**************************************
             * Calcolo del tempo di fermata
             **************************************/

            if (CurrentPalina != -1)
            {
                //if (Loc.Speed <= Global::SogliaSpeed)
                //{
                //    if (Global::InizioSosta == DateTime.MinValue)
                //        Global.InizioSosta = Now;
                //}

                A.setLatitude ( CurTrip->at(CurrentPalina)->Lat );
                A.setLongitude( CurTrip->at(CurrentPalina)->Lng );

                float DistPalina = Loc.distanceTo(A);

                if (DistPalina > CurTrip->at(CurrentPalina)->Radius)
                {
                    Logger::Info( "NAV", QString("OutPalina(%1)").arg(CurTrip->at(CurrentPalina)->StopID));

                    SendEvent( "departure",
                               CurTrip->at(CurrentPalina)->StopID,
                               CurTrip->at(CurrentPalina)->Lat,
                               CurTrip->at(CurrentPalina)->Lng );

                    CurrentPalina = -1;
                }
            }
        }
    }

    BuildMessage( Loc, BusInfo );

    BusInfo->NavState = NavState;

    return iNode;
}

/**************************************************************************/
void clsNavigator::BuildMessage(QGeoCoordinate Loc, clsBusInfo *BusInfo)
/**************************************************************************/
{
    static QDateTime UltimoInvio = Global::CurrentTime();
    static QString   UltimoJS = "";

    QVariantMap Data;
    QDateTime   Now = Global::CurrentTime();

    QString Status = QVariant::fromValue(NavState).value<QString>();

    Data.insert("action"   , "avm-status");
    Data.insert("timestamp", Loc.GpsTime().toString("dd/MM/yyyy HH:mm:ss") );
    Data.insert("status"   , Status   );
    Data.insert("route_id" , RouteID  );
    Data.insert("trip_id"  , Global::TripID );
    Data.insert("duty_id"  , Global::DutyID );
    Data.insert("driver_id", Global::Conducente );
    Data.insert("bus_speed", Loc.speed() );
    Data.insert("gps_dir"  , Loc.course());
    Data.insert("lat"      , Loc.latitude());
    Data.insert("lng"      , Loc.longitude());
    Data.insert("alt"      , Loc.altitude());
    Data.insert("lat_sti"  , Loc.latitude());
    Data.insert("lng_sti"  , Loc.longitude());
    Data.insert("delay"    , Global::RitardoCorsa);

    QVariantMap Info[3];

    for (int j=0; j<3; j++)
    {
        if (NavState != eNavState::FuoriServizio)
        {
            double Dist = BusInfo->Paline->at(j)->Distanza / 1000;

            Info[j].insert( "stop_id"      , BusInfo->Paline->at(j)->StopID );
            Info[j].insert( "stop_name"    , BusInfo->Paline->at(j)->Desc );
            Info[j].insert( "arrival_time" , BusInfo->Paline->at(j)->PrevisioneArrivo.toString("HH:mm:ss") );
            Info[j].insert( "time_table"   , BusInfo->Paline->at(j)->OrarioStatico.toString("HH:mm:ss") );
            Info[j].insert( "distance"     , Dist );

            if (j==1)
            {
                if (NavState == eNavState::Navigation)
                {
                    Global::Fore_Time = Now.secsTo(BusInfo->Paline->at(j)->PrevisioneArrivo );
                    Global::Fore_Stop = BusInfo->Paline->at(j)->StopID;
                }
                else
                {
                    Global::Fore_Time = 0;
                    Global::Fore_Stop = "";
                }
            }
        }
    }

    Data.insert( "forecast_last_stop"    , Info[0] );
    Data.insert( "forecast_next_stop"    , Info[1] );
    Data.insert( "forecast_nextnext_stop", Info[2] );

    bool Ok = false;

    QtJson::setPrettySerialize(true);

    QString JS = QtJson::serialize(Data, Ok) + "\n\n";

    if (Ok)
    {
        int Dif = UltimoInvio.secsTo(Now);

        if ( JS != UltimoJS || Dif > 30 )
        {
            emit SendMessage(-1, JS.toLocal8Bit());

            UltimoInvio = Global::CurrentTime();
            UltimoJS    = JS;
        }
    }
}

/**************************************************************************/
QString clsNavigator::FindTrip( QMap <QString,GTurni*> *Turni, QString TurnoMacchina, eDutyType DutyType )
/**************************************************************************/
{
    QString Candidate = "";
    int Durata;
    int DMin;
    GTurni *T;

    QDateTime Now = Global::CurrentTime();
    //QDateTime Now = QDateTime::fromString("2020-10-07 11:20:10", "yyyy-MM-dd HH:mm:ss");

    if (Turni->keys().count() > 0)
    {
        foreach ( QString Trip, Turni->keys() )
        {
            T = Turni->value(Trip);

            qDebug() << T->TripID;

            if ( T->DutyID == TurnoMacchina || TurnoMacchina.length() == 0)
            {
                if (!Global::TurniFatti->contains( T->TripID) )
                {
                    if ( Now >= T->Data_Partenza && Now <= T->Data_Arrivo )
                    {
                        Candidate = T->TripID;

                        break;
                    }
                }
            }
        }

        /*******************************************
         * Se non ho trovato la corsa mi posiziono
         * su quella più vicina in termini di orario
         * di partenza
         *******************************************/

        if (Candidate.length() == 0)
        {
            DMin = -9999999;

            foreach ( QString Trip, Turni->keys() )
            {
                T = Turni->value(Trip);

                if ( T->DutyID == TurnoMacchina || TurnoMacchina.length() == 0)
                {
                    if (!Global::TurniFatti->contains(T->TripID))
                    {
                        int Sec = T->Data_Partenza.secsTo(Now);

                        if (Sec < 0 && Sec > DMin)
                        {
                            Candidate = Trip;
                            DMin = Sec;
                        }
                    }
                }
            }

            if (Candidate.length() > 0)
            {
                GTurni *T = Turni->value(Candidate);

                Durata = T->Data_Partenza.secsTo(T->Data_Arrivo);

                int TimeLeft = Now.secsTo(T->Data_Partenza);

                if ( TimeLeft > ( Durata / 2) )
                    Candidate = "";
            }
        }
    }

    return Candidate;
}
/*****************************************/
void clsNavigator::SendEvent( QString Evento, QString StopID, double Lat, double Lng )
/*****************************************/
{
    bool Ok = false;
    QVariantMap Data;
    QDateTime   Now = Global::CurrentTime();

    Data.insert("action"   , "avm-event");
    Data.insert("timestamp", Now.toString("dd/MM/yyyy HH:mm:ss") );
    Data.insert("event"    , Evento   );
    Data.insert("lat"      , Lat );
    Data.insert("lng"      , Lng );

    if (StopID != nullptr)
        Data.insert("stop_id"   , StopID   );

    QtJson::setPrettySerialize(true);

    QString JS = QtJson::serialize(Data, Ok) + "\n\n";

    if (Ok)
    {
        emit SendMessage(-1, JS.toLocal8Bit());
        Logger::Info("MSG", JS);
    }
}
