// moved to GpioManager
#ifndef TOGGLEPIN_H
#define TOGGLEPIN_H

#include "gpio.h"
/**
 * @brief Gestione pin di uscita standard
 */
class TogglePin: public GPIO
{
private:

    bool activated;
    int  nBeep;

public:

    TogglePin(const QString &pinName) : GPIO(pinName)
    {
        this->activated = false;
        this->nBeep     = 0;
        this->WavePtr   = 0;
    }

    int  WavePtr;
    int  Wave[6];

    void on();
    void off();
    void toggle();
    bool isOn();
    void Beep(int nBeep);
};

#endif // TOGGLEPIN_H
