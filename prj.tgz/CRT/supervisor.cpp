#include "supervisor.h"
#include "clswebservice.h"

#include "clsgtfs.h"
#include "clspayload.h"
#include "dbmanager.h"
#include "clssimulatore.h"
#include "global.h"

#include <QtMath>

#undef ENABLE_SIMULATORE

using QtJson::JsonObject;
using QtJson::JsonArray;

Supervisor::Supervisor(QObject *parent) : QThread(parent)
{
}

void Supervisor::Start()
{
    /**************************
     * INIT VARS
     **************************/

    LastTrackSendTime = QDateTime::currentDateTime().addDays(-1);
    LastDutyCheck     = QDateTime::currentDateTime();

    LastPosition.setAltitude(14);
    LastPosition.setLongitude(7);
    LastPosition.setAltitude(0);

    Gtfs = new clsGtfs();

    DBManager *DBase = new DBManager(this, "DB_Supervisor");

    bool Ok = DBase->Open();

    if (Ok)
    {
        DBase->Init();

        Global::Agenzia = DBase->GetParam("Agenzia", "");

        /**************************
         * START TCP SERVER
         **************************/

        TCPServer = new TcpServer(this);

        connect(TCPServer, SIGNAL(CommandReceived(int, QByteArray)), this, SLOT(CommandReceived(int, QByteArray)), Qt::QueuedConnection);

        connect( this, SIGNAL(SendMessage(int, QByteArray)), TCPServer, SLOT(SendMessage(int, QByteArray)), Qt::QueuedConnection);

        TCPServer->startServer();

        /**************************
         * LETTURA GTFS
         **************************/

        if (Global::Agenzia.length() > 0)
        {
            Gtfs->Read_Gtfs(false, Global::Agenzia);
        }

        /**************************
         * START SERVER SPOOLER
         **************************/

        ThPay = new clsPayload("Spooler");

        ThPay->start();

        /**************************
         * START SIMULATORE GPS
         **************************/

        qRegisterMetaType<GpsData>();

        #ifdef ENABLE_SIMULATORE

            clsSimulatore *ThSim = new clsSimulatore(this);

            connect( ThSim, SIGNAL(DataReady(GpsData)), this, SLOT(DataReady(GpsData)), Qt::QueuedConnection );

            ThSim->start();

        #else

            connect( this, SIGNAL(LocReceived(GpsData)), this, SLOT(DataReady(GpsData)), Qt::QueuedConnection );

        #endif

        SendProcessStatus("wait");

        //exec();
    }
}

/*************************************/
void Supervisor::BroacastMessage(int ClientID, QByteArray Data)
/*************************************/
{
    emit SendMessage( ClientID, Data );
}

/*************************************/
void Supervisor::BroacastMessage(int ClientID, QString Data)
/*************************************/
{
    emit SendMessage( ClientID, Data.toLocal8Bit() );
}

/*************************************/
void Supervisor::CommandReceived(int ClientID, QByteArray Datagram)
/*************************************/
{
    qDebug() << "Ricevuto messaggio da " << ClientID;

    QString Message = QString::fromLocal8Bit( Datagram );

    int Ptr = 0;

    do
    {
        QString Msg = Message.mid(Ptr);

        qDebug() << Msg;

        bool Ok = false;

        if (Msg.startsWith("#"))
        {
            if (Msg.startsWith("#info"))
            {
                BroacastMessage( ClientID, QString("Agenzia: %1\r\n").arg(Global::Agenzia));
                BroacastMessage( ClientID, QString("Trip: %1\r\n").arg(Global::TripID));
                BroacastMessage( ClientID, QString("Duty: %1\r\n").arg(Global::DutyID));
            }

            if (Msg.startsWith("#agenzia"))
            {
                QString Agenzia = "18";

                if (Agenzia != Global::Agenzia)
                {
                    SendProcessStatus("busy");

                    bool Ok = Gtfs->Read_Gtfs(true, Agenzia);

                    if (Ok)
                    {
                        Global::Agenzia = Agenzia;

                        SendProcessStatus("ready");
                    }
                    else
                        SendProcessStatus("error");
                }
            }

            if (Msg.startsWith("#test"))
            {
                Global::Imei        = "1540918946";
                Global::Mezzo       = "PROVA";
                Global::Conducente  = "";
                QString DutyID      = "309";
                QString TripID      = "";

                if (Global::Agenzia.length() > 0)
                    emit NewTrip(DutyID, TripID);
            }

            if (Msg.startsWith("#emit"))
            {
                GpsData Dati;
                Dati.GpsFix = true;
                Dati.TimeStamp = QDateTime::currentDateTime();
                Dati.Coord.setLatitude(10.0);
                Dati.Coord.setLongitude(7);
                Dati.Coord.setAltitude(236);
                emit DataReady(Dati);
            }

            if (Msg.startsWith("#start_app"))
            {
                Global::DutyID      = "18000";
                Global::TripID      = "20-TEST";
            }

            if (Msg.startsWith("#stop_app"))
            {
                Global::DutyID      = "";
                Global::TripID      = "";
            }

            Ptr += Msg.length();
        }
        else
        {
            QVariantMap Param = QtJson::parse( Msg, Ok).toMap();

            if (Ok)
            {
                QString Action = Param["action"].toString().toUpper();

                /***************************************/
                if (Action == "GPS-POSITION")
                /***************************************/
                {
                    GpsData Dati;

                    float   GpsDir      = Param["gps_dir"].toFloat();
                    float   Lat         = Param["lat"].toFloat();
                    float   Lng         = Param["lng"].toFloat();
                    float   Alt         = Param["alt"].toFloat();
                    float   Speed       = Param["bus_speed"].toFloat();
                    QDateTime TimeStamp = Param["timestamp"].toDateTime();
                    QString Extra       = Param["extra"].toString();
                    QString Door        = Param["door_status"].toString();

                    Global::Door = Door == "true" ? true : false;

                    Dati.TimeStamp = TimeStamp;
                    Dati.GpsFix    = true;
                    Dati.StopID    = "";
                    Dati.Coord.setSpeed(Speed);

                    Dati.Coord.setAltitude(Alt);
                    Dati.Coord.setLatitude(Lat);
                    Dati.Coord.setLongitude(Lng);

                    Dati.Coord.setCourse(GpsDir);

                    Dati.Extra = Extra;

                    if (Global::Agenzia.length() > 0)
                        emit LocReceived( Dati );
                }

                /***************************************/
                if (Action=="APP-CONFIG")
                /***************************************/
                {
                    QDateTime TimeStamp = Param["timestamp"].toDateTime();
                    QString Agenzia     = Param["agency_id"].toString();
                    Global::Imei        = Param["device_id"].toString();
                    Global::Mezzo       = Param["vehicle_id"].toString();

                    bool Reload = (Agenzia != Global::Agenzia);

                    SendProcessStatus("busy");

                    bool Ok = Gtfs->Read_Gtfs(Reload, Agenzia);

                    if (Ok)
                    {
                        Global::Agenzia = Agenzia;

                        SendProcessStatus("ready");
                    }
                    else
                        SendProcessStatus("error");
                }

                /***************************************/
                if (Action=="DUTY-CONFIG")
                /***************************************/
                {

                    QDateTime TimeStamp = Param["timestamp"].toDateTime();
                    Global::Imei        = Param["device_id"].toString();
                    Global::Mezzo       = Param["vehicle_id"].toString();
                    Global::Conducente  = Param["driver_id"].toString();
                    Global::DutyID      = Param["duty_id"].toString();
                    QString TripID      = Param["trip_id"].toString();

                    if (Global::Agenzia.length() > 0)
                        emit NewTrip(Global::DutyID, TripID);
                }

                /***************************************/
                if (Action=="START-APP")
                /***************************************/
                {
                    QDateTime TimeStamp = Param["timestamp"].toDateTime();
                    Global::Imei        = Param["device_id"].toString();
                    Global::Mezzo       = Param["vehicle_id"].toString();
                    Global::Conducente  = Param["driver_id"].toString();
                    Global::DutyID      = Param["duty_id"].toString();
                    Global::TripID      = Param["trip_id"].toString();

                    Nav->NavState = clsNavigator::eNavState::Apprendimento;
                }

                /***************************************/
                if (Action=="STOP-APP")
                /***************************************/
                {
                    QDateTime TimeStamp = Param["timestamp"].toDateTime();
                    Global::Imei        = Param["device_id"].toString();
                    Global::Mezzo       = Param["vehicle_id"].toString();
                    Global::Conducente  = Param["driver_id"].toString();
                    Global::DutyID      = "";
                    Global::TripID      = "";

                    Nav->NavState = clsNavigator::eNavState::FuoriServizio;
                }

                /***************************************/
                if (Action=="DOOR-EVENT")
                /***************************************/
                {
                    // {\"action\":\"door-event\",\"door_status\":\"1\",\"lat\":\"42.268606\",\"lng\":\"14.435947\",\"people_in\":\"8\",\"people_out\":\"2\",\"timestamp\":\"2018-11-22 12:49:55\"}

                    QDateTime TimeStamp = Param["timestamp"].toDateTime();
                    float   Lat         = Param["lat"].toFloat();
                    float   Lng         = Param["lng"].toFloat();
                    QString Door        = Param["door_status"].toString();
                    Global::PeopleIN    = Param["people_in"].toInt();
                    Global::PeopleOUT   = Param["people_out"].toInt();

                    Global::Door = Door == "true" ? true : false;
                }
            }

            Ptr += Msg.indexOf("\n\n") + 2;
        }

    } while ( Ptr < Message.length() );

}

/*****************************************/
void Supervisor::SendProcessStatus( QString Status )
/*****************************************/
{
    bool Ok = false;
    QVariantMap Data;
    QDateTime   Now = QDateTime::currentDateTime();

    Data.insert("action"   , "avm-process-status");
    Data.insert("timestamp", Now.toString("dd/MM/yyyy HH:mm:ss") );
    Data.insert("status"   , Status   );

    QtJson::setPrettySerialize(true);

    QString JS = QtJson::serialize(Data, Ok) + "\n\n";

    if (Ok)
    {
        BroacastMessage( -1, JS.toLocal8Bit() );
    }
}


/*************************************/
void Supervisor::DataReady(GpsData Loc)
/*************************************/
{
    QDateTime Now = QDateTime::currentDateTime();

    /*********************************
     * CONTROLLO INGRESSO IN SERVIZIO
     *********************************/

    if (
        (Nav->NavState == clsNavigator::eNavState::FuoriServizio) ||
        (Nav->NavState == clsNavigator::eNavState::Lost)
       )
    {
        if (Global::Agenzia.length() > 0)
        {
            if (Global::DutyID != "")
            {
                if (LastDutyCheck.secsTo(Now) > 30 )
                {
                    LastDutyCheck = Now;

                    emit NewTrip(Global::DutyID, "");
                }
            }
        }
    }

    /*********************************
     * RICARICO TURNI E VESTIZIONE
     *********************************/

    if (!Gtfs->Busy)
    {
        if (Gtfs->GTFS_Turni->count() == 0)
        {
            if (Global::Agenzia.length() > 0)
            {
                Gtfs->Read_Turni( Global::Agenzia );
            }
        }
    }

    if (Loc.GpsFix)
    {
        emit NewLoc( Loc );

        bool OkSend = LastTrackSendTime.secsTo(Now) >= 60;

        double Dist = LastPosition.distanceTo(Loc.Coord);

        if (!OkSend)
            OkSend = Dist > 30;

        if (!OkSend)
        {
            if (Global::Door != oDoor)
            {
                OkSend = true;
                qDebug() << "Door event";
            }
        }

        if (!OkSend)
            OkSend = qFabs(Loc.Coord.course() - LastPosition.course() ) > 5;

        if (OkSend)
        {
            TrackInfo Data;

            Data.Event  = "POL";
            Data.Imei   = Global::Imei;
            Data.Mezzo  = Global::Mezzo;
            Data.Cond   = Global::Conducente;
            Data.Lat    = Loc.Coord.latitude();
            Data.Lng    = Loc.Coord.longitude();
            Data.Ang    = Loc.Coord.course();
            Data.Speed  = Loc.Coord.speed();
            Data.Odo    = 0;
            Data.Time   = Loc.TimeStamp;
            Data.StopID = Global::StopID;
            Data.TripID = Global::TripID;
            Data.DutyID = Global::DutyID;
            Data.Porte  = Global::Door;
            Data.PassIN = Global::PeopleIN;
            Data.PassOUT= Global::PeopleOUT;
            Data.Extra  = Loc.Extra;
            Data.Rit    = Global::RitardoCorsa;
            Data.StopID    = Global::StopID;

            Data.Fore_Stop = Global::Fore_Stop;
            Data.Fore_Time = Global::Fore_Time;

            ThPay->PushMessage( "LOGGER", Data );

            LastPosition.setAltitude ( Loc.Coord.altitude() );
            LastPosition.setLongitude( Loc.Coord.longitude());
            LastPosition.setLatitude ( Loc.Coord.latitude() );
            LastPosition.setCourse   ( Loc.Coord.course() );

            LastTrackSendTime = Now;

            oDoor = Global::Door;
        }
    }
}
