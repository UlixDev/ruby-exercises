#include "gpio.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <QDebug>

GPIO::GPIO(const QString &pinName)
{
    char path[64];
    int fd;

    // Salva pin
    this->pinName  = pinName;
    this->exported = false;

    if (pinName.length() > 0)
    {
        // Verifica se il GPIO esiste
        snprintf(path, sizeof(path), "/sys/class/gpio/%s/value", this->pinName.toStdString().c_str());
        fd = open(path, O_WRONLY);
        if (fd == -1) {
            qDebug() << "GPIO::GPIO: Unable to open /sys/class/gpio/" << this->pinName;
            this->exported = false;
            return;
        }

        close(fd);
        qDebug() << "GPIO::GPIO: Pin " << this->pinName << " created";
        this->exported = true;
    }
}

int GPIO::setValue(int value)
{
    char path[64];

    if (this->exported)
    {
        // Imposta lo stato del pin, tramite /sys/class/gpio/gpioXX/value
        snprintf(path, sizeof(path), "/sys/class/gpio/%s/value", this->pinName.toStdString().c_str());
        int fd = open(path, O_WRONLY);
        if (fd == -1) {
            //qDebug() << "GPIO::writeValue: Unable to open " << path;
            return -1;
        }

        if (write(fd, value > 0 ? "1" : "0", 1) != 1) {
            //qDebug() << "GPIO::writeValue: Error writing to" << path;
            close(fd);
            return -1;
        }

        close(fd);
        //qDebug() << "GPIO::writeValue: Pin " << this->pinName << " set to " << value;
        return 0;
    } else
    {
        //qDebug() << "GPIO::writeValue: Pin " << this->pinName << " not exported";
        return -1;
    }
}

/********************************************/
int GPIO::setBrightness(int value)
/********************************************/
{
    char OutS[8];

    sprintf(OutS, "%d", value);

    int fd = open("/sys/class/backlight/backlight/brightness", O_WRONLY);

    if (fd == -1)
    {
        return -1;
    }

    if (write(fd, OutS, strlen(OutS)) != 1)
    {
        //qDebug() << "GPIO::writeValue: Error writing to" << path;
        close(fd);
        return -1;
    }

    close(fd);

    return 0;
}

void GPIO::resetBrightness()  // not used
{
    setBrightness(10);
}


