#include "clsDisplayAesys.h"

#include <QTime>
#include <QDebug>
#include <QImage>
#include <QtGui>
#include <QSignalSpy>

#include "global.h"

QT_USE_NAMESPACE

clsDisplayAesys::clsDisplayAesys()
{
}
/*********************************************************/
void clsDisplayAesys::Config(QString Adr, ePanelType nZone, ePanelModel Model, QString Code, QString ID )
/*********************************************************/
{
    this->Adr          = Adr;
    this->nZone        = nZone;
    this->Modello      = Model;
    this->Brand        = 1;
    this->DCode        = Code;
    this->DID          = ID;
}
/*********************************************************/
void clsDisplayAesys::SetPanel(QString Num, QString NumFore, QString NumBack, QString Sup, QString SupFore, QString SupBack, QString Inf, QString InfFore, QString InfBack)
/*********************************************************/
{
    this->Num = Num;
    this->Sup = Sup;
    this->Inf = Inf;

    this->NumFore = NumFore;
    this->SupFore = SupFore;
    this->InfFore = InfFore;

    this->NumBack = NumBack;
    this->SupBack = SupBack;
    this->InfBack = InfBack;

    this->FL_Refresh = true;
}

/**************************************/
void clsDisplayAesys::qSleep(int ms)
/**************************************/
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000 * 1000 };
    nanosleep(&ts, nullptr);
}

/***********************************************/
QByteArray clsDisplayAesys::CopyTo(QString Source, QByteArray Buffer, int Ptr)
/***********************************************/
{
    QByteArray Temp = Source.toLocal8Bit();

    for (int j=0; j<Temp.length(); j++)
        Buffer[Ptr+j] = Temp.at(j);

    return Buffer;
}
/***********************************************/
QByteArray clsDisplayAesys::BuildMessage(QString Dest, QString OpCode, QString Num, QString Sup, QString Inf, QString FC1, QString FC2, QString FC3)
/***********************************************/
{
    QByteArray resultByteArray;

    int bufferLength = 9;

    try
    {
        Num = Num.trimmed();
        Sup = Sup.trimmed();
        Inf = Inf.trimmed();

        if (Num.startsWith(" ")) Num = "!" + Num;
        if (Num.endsWith(" ")) Num = Num + "!";

        if (Sup.startsWith(" ")) Sup = "!" + Sup;
        if (Sup.endsWith(" ")) Sup = Sup + "!";

        if (Inf.startsWith(" ")) Inf = "!" + Inf;
        if (Inf.endsWith(" ")) Inf = Inf + "!";

        int LenN = Num.length();
        int LenS = Sup.length();
        int LenI = Inf.length();


        if (OpCode == "VIS")
        {
            resultByteArray[bufferLength] = 0x00;       //Activation Code 0=Immediate

            bufferLength += 1;
        }

        if (LenN > 0)
        {
            resultByteArray = CopyTo(Num, resultByteArray, bufferLength );
            bufferLength += LenN;
            resultByteArray[bufferLength] = 0x0B;
            bufferLength += 1;
        }

        if (LenS > 0 && LenI > 0)
        {
            resultByteArray = CopyTo(Sup, resultByteArray, bufferLength);
            bufferLength += LenS;

            resultByteArray[bufferLength] = 0x0A;
            bufferLength += 1;

            resultByteArray = CopyTo(Inf, resultByteArray, bufferLength);
            bufferLength += LenI;

            resultByteArray[bufferLength] = 0x0A;
            bufferLength += 1;
        }
        else
        {
            if (LenS > 0)
            {
                resultByteArray = CopyTo(Sup, resultByteArray, bufferLength);
                bufferLength += LenS;

                resultByteArray[bufferLength] = 0x0A;
                bufferLength += 1;
            }

            if (LenI > 0)
            {
                resultByteArray = CopyTo(Inf, resultByteArray, bufferLength);
                bufferLength += LenI;

                resultByteArray[bufferLength] = 0x0A;
                bufferLength += 1;
            }
        }

        resultByteArray[0] = STX;
        resultByteArray = CopyTo(Dest  , resultByteArray, 1);
        resultByteArray = CopyTo(OpCode, resultByteArray, 2);

        int DataLen = bufferLength - 9;

        QString Size = QString("%1").arg(DataLen, 4, 10, QChar('0'));

        resultByteArray = CopyTo(Size, resultByteArray, 5);

        resultByteArray[bufferLength++] = ETX;

        Size = "ZZZZ";

        resultByteArray = CopyTo(Size, resultByteArray, bufferLength);

        bufferLength += Size.length();

        for (int j = 0; j < bufferLength; j++)
        {
            if (resultByteArray.at(j) == '!')
                resultByteArray[j] = 0xB1;
        }
    }
    catch (...)
    {
        //Logger.Error(this, $"BuilMessage error: {ex.Message}");
    }

    return resultByteArray;
}


