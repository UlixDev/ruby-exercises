#include "logger.h"
#include "global.h"

#include <QFile>
#include <QDir>
#include <QTextStream>
#include <QDateTime>
#include <QUdpSocket>
#include <QCoreApplication>

QString Logger::RemoteLogIP   = "192.168.1.10";
int     Logger::RemoteLogPort = 4000;
QString Logger::Root          = "./Log";
bool    Logger::EnUDP         = true;

Logger::Logger()
{
}

/*****************************************************/
void Logger::Info( QString Cat, QString Message )
/*****************************************************/
{
    QString Name = QDate::currentDate().toString("yyyy-MM-dd.txt");

    QString Filename = QCoreApplication::applicationDirPath()+ "/" + Name;

    QString Txt = QString("%1 - %2 - %3 - %4\n").arg( Global::CurrentTime().toString("dd/MM/yyyy HH:mm:ss") )
                                                .arg(Global::Imei)
                                                .arg(Cat)
                                                .arg(Message);

    qDebug() << Txt;

    QFile Out(Filename);

    if (Out.open( QIODevice::WriteOnly | QIODevice::Append ))
    {
        QTextStream OutS(&Out);

        OutS << Txt;

        Out.close();
    }

    if (EnUDP)
    {
        QUdpSocket Socket;

        QByteArray Data = Txt.toLocal8Bit();

        Socket.writeDatagram(Data, QHostAddress(RemoteLogIP), RemoteLogPort );
    }
}

/*****************************************************/
void Logger::Purge(int nDay)
/*****************************************************/
{
    QDir directory(QCoreApplication::applicationDirPath());

    QStringList Files = directory.entryList(QStringList() << "*.txt" , QDir::Files);

    foreach(QString filename, Files)
    {
        QDate DataFile = QDate::fromString( filename.mid(0, 10), "yyyy-MM-dd");

        if (DataFile.isValid())
        {
            int d = DataFile.daysTo(QDate::currentDate());

            if ( d > nDay )
            {
                QFile file (QCoreApplication::applicationDirPath() + "/" + filename);

                file.remove();
            }
        }
    }
}
