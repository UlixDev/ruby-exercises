//moved to forms/ui renamed in smthg more self-explanatory
#ifndef FRMSELECTDUTY_H
#define FRMSELECTDUTY_H

#include <QWidget>
#include <QLabel>

#include "clsdutyinfo.h"
#include "clsgtfs.h"

class DutyInfo;

// Moved to enumerations.h in the new prj
enum eViewMode
{
    Duty,
    Trip
};

namespace Ui
{
    class frmSelectDuty;
}

class frmSelectDuty : public QWidget
{
    Q_OBJECT

public:
    explicit frmSelectDuty(QWidget *parent = nullptr);
    ~frmSelectDuty();

private:

    Ui::frmSelectDuty *ui;

    void ShowDuty();
    void ShowTrip(QString DutyID);
    void ResizeFont(QLabel *Lab, QString Text);

    clsDutyInfo *Slot[12];
    clsGtfs     *Gtfs;

    QMap<QString, DutyInfo*> *Duty;

    eViewMode ViewMode;
    QString CurrentDuty;

    int Ptr = 0;

    const int nSlot = 12;

signals:

    void NewTrips( QString DutyID, QString TripID );

private slots:

     void on_cmd_Duty();

     void on_cmd_Back_clicked();
     void on_cmd_Next_clicked();
     void on_cmd_Close_clicked();
};

//move to structs.h
class DutyInfo
{
public:

    QString   DutyID;
    QString   DutyDesc;
    QDateTime DutyStart;
    QDateTime DutyEnd;
};

#endif // FRMSELECTDUTY_H
