#include "clsbusinfo.h"
#include "global.h"

clsBusInfo::clsBusInfo()
{
    Paline = new QList<clsPalina*>();

    for (int j=0; j<MAX_PALINE; j++)
    {
        clsPalina *Pal = new clsPalina("");

        Paline->append(Pal);
    }
}
