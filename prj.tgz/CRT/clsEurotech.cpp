#include <qmath.h>

#include "clsEurotech.h"
#include "logger.h"

/*************************************************************************************************************************************
 * EUROTECH MAIN
 *************************************************************************************************************************************/

Eurotechs::Eurotechs()
{

}

/*****************************************************************/
void Eurotechs::Config (QList<QString> Pax, int Port)
/*****************************************************************/
{
    PaxOft = 0;

    int Index = 1;

    foreach(QString IP, Pax)
    {
        clsEurotech *Euro = new clsEurotech();

        Euro->Config(IP, Port, Index++);

        ContaPax.append(Euro);

        Euro->start();
    }
}

/*****************************************************************/
void Eurotechs::run()
/*****************************************************************/
{
    QDateTime OpenDoorTime = QDateTime::fromMSecsSinceEpoch(0);

    int oTotale  = -1;
    int oPassIn  = -1;
    int oPassOut = -1;

    while (Global::Running)
    {
        /***********************************
         * CALCOLO TOTALI E STATO GENERALE
         ***********************************/

        PassIn  = 0;
        PassOut = 0;
        Totale  = 0;

        StatoPorte = eDoorStatus::Closed;

        Status = eStatus::Up;

        foreach(clsEurotech *Client, ContaPax)
        {
            if (Client->Status == eStatus::Up)
            {
                PassIn  += Client->PassIn;
                PassOut += Client->PassOut;

                if (Client->StatoPorte != eDoorStatus::Unknow)
                {
                    if (Client->StatoPorte == eDoorStatus::Opened)
                        StatoPorte = eDoorStatus::Opened;
                }
            }
            else
                Status = eStatus::Down;
        }

        /****************************
         * CONTROLLO FUNZIONAMENTO
         ****************************/

        if (Status != oStatus)
        {
            oStatus = Status;

            qDebug() << "CPX Status: " << (Status==eStatus::Up ? "UP" : "DOWN");

            emit CpxStatusChanged(Status);
        }

        /**********************************
         * VARIAZIONE SALITI/DISCESI
         **********************************/

        if (PassOut > (PassIn + PaxOft))
        {
            PaxOft += (PassOut - PassIn);

            Logger::Info("EUROTECH", QString("CONTAPAX: Saliti=%1 Discesi=%2 Correttore=%3").arg(PassIn).arg(PassOut).arg(PaxOft));
        }

        Global::PeopleIN  = PassIn + PaxOft;
        Global::PeopleOUT = PassOut;

        Totale = (Global::PeopleIN - Global::PeopleOUT);

        if (Totale != oTotale)
        {
            Global::ABordo += (Totale - oTotale);

            Logger::Info("HELLANEW", QString("  RUN in: %1 out: %2, abordo:%3").arg(Global::PeopleIN).arg(Global::PeopleOUT).arg(Global::ABordo));

            oTotale = Totale;

            if (Global::ABordo < 0)
                Global::ABordo = 0;
        }

        if (Global::PeopleIN != oPassIn || Global::PeopleOUT != oPassOut)
        {
            oPassIn  = Global::PeopleIN;
            oPassOut = Global::PeopleOUT;

            emit PeopleCountChange(oPassIn, oPassOut, Global::ABordo);

            qDebug() << QString("CONTAPAX: Saliti=%1 Discesi=%2 aBordo=%3").arg(oPassIn).arg(oPassOut).arg(Global::ABordo);

        }

        /**********************************
         * APERTURA/CHIUSURA PORTE
         **********************************/

        if (oStatoPorte != StatoPorte)
        {
            if (StatoPorte == eDoorStatus::Opened)
            {
                Logger::Info("EUROTECH", "Apertura porte");

                qDebug() << "Apertura porte";

                OpenDoorTime = Global::CurrentTime();
            }
            else if (StatoPorte == eDoorStatus::Closed)
            {
                Logger::Info("EUROTECH", "Chiusura porte");

                qDebug() << "Chiusura porte";

                if (OpenDoorTime != QDateTime::fromMSecsSinceEpoch(0) )
                    Global::TempoAperturaPorte = Global::CurrentTime().toMSecsSinceEpoch() - OpenDoorTime.toMSecsSinceEpoch();
            }

            oStatoPorte = StatoPorte;

            emit DoorStatusChanged((int)StatoPorte);
        }

        QThread::msleep(100);
    }
}

/*************************************************************************************************************************************
 * EUROTECH CLIENTS
 *************************************************************************************************************************************/

clsEurotech::clsEurotech()
{

}
/*****************************************************************/
void clsEurotech::Config (QString IP, int Port, int ID)
/*****************************************************************/
{
    this->IP     = IP;
    this->Port   = Port;
    this->ID     = ID;

    this->LastEuroRes = QDateTime::fromMSecsSinceEpoch(0);

    EuroClient = new TcpClient(this);

    EuroClient->StartConnection(IP, Port);
}

/*****************************************************************/
void   clsEurotech::run()
/*****************************************************************/
{
    PassIn  = 0;
    PassOut = 0;
    Totale  = 0;

    QDateTime LastQuery = QDateTime::fromSecsSinceEpoch(0);

    while (Global::Running)
    {
        QDateTime Now = Global::CurrentTime();

        if (qFabs(Now.msecsTo(LastQuery)) >= 1000 )
        {
            LastQuery = Now;

            /*************************************
            * LETTURA STATO PORTE
            *************************************/

            bool Ok = ReadPortStatus( &StatoPorte );

            if (Ok)
            {
                Status = eStatus::Up;

                /********************
                 * CONTA PASSEGGERI
                 ********************/

                if (Status == eStatus::Up)
                {
                    Ok = Read_InOut( &PassIn, &PassOut );

                    if (Ok)
                        Totale = (PassIn - PassOut);
                    else
                        Status = eStatus::Down;
                }

                /*************************************
                * RESET
                *************************************/

                if (Status == eStatus::Up)
                {
                    if (DoReset || (ResetDay != Now.date().dayOfYear()))
                    {
                        Ok = Reset_InOut();

                        if (Ok)
                        {
                            DoReset = false;

                            ResetDay = Now.date().dayOfYear();
                        }
                    }
                }
            }
            else
                Status = eStatus::Down;
        }

        QThread::msleep(10);
    }
}

/*********************************************/
bool clsEurotech::ReadPortStatus( eDoorStatus *Door )
/*********************************************/
{
    bool Ret = false;

    int nByte = EuroClient->SendMessage("gdoorstatus\0", 12, 2000);

    if (nByte == 1)
    {
        if (EuroClient->RxBuffer[0] != 0)
            *Door = eDoorStatus::Opened;
        else
            *Door = eDoorStatus::Closed;

        qDebug() << "Porte:" << *Door;

        Ret = true;
    }
    else
        qDebug() << "Err: nb " << nByte;

    return Ret;
}

/*********************************************/
bool clsEurotech::Read_InOut( int *PassIn, int *PassOut)
/*********************************************/
{
    bool result = false;

    try
    {
        int nByte = EuroClient->Eurotech_SendMessage("gcounters\0", 10, 8, 5000);

        if (nByte == 8)
        {
            *PassIn  = EuroClient->EuroBuf[0] | (EuroClient->EuroBuf[1] << 8) | (EuroClient->EuroBuf[2] << 16) | (EuroClient->EuroBuf[3] << 24);

            *PassOut = EuroClient->EuroBuf[4] | (EuroClient->EuroBuf[5] << 8) | (EuroClient->EuroBuf[6] << 16) | (EuroClient->EuroBuf[7] << 24);

            qDebug() << "PassIn: " << *PassIn << "PassOut: " << *PassOut;

            result = true;
        }
        else
            qDebug() << "Err: nb " << nByte;
    }
    catch (...)
    {
    }

    return result;
}

/*********************************************/
void clsEurotech::Reset()
/*********************************************/
{
    DoReset = true;
}

/*********************************************/
bool clsEurotech::Reset_InOut()
/*********************************************/
{
    EuroClient->SendMessage("reset\0", 6, 0);

    return true;
}
