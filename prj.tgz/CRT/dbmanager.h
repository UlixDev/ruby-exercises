// moved
#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDateTime>
#include <QObject>

class DBManager : QObject
{
     Q_OBJECT

public:

    explicit DBManager(QObject *parent, QString ConnectionName = "");

    bool CreateTable_Config();
    bool CreateTable_TurniMacchina();
    bool CreateTable_Repo();
    bool CreateTable_Store();
    bool CreateTable_Trips();
    bool CreateTable_Vestizione();
    bool CreateTable_StopsTime();
    bool CreateTable_Stops();
    bool CreateTable_Shapes();
    bool CreateTable_Routes();
    bool CreateTable_Payload();
    bool CreateTable_Cartelli();
    bool CreateTable_Velette();

    bool Modify_Table();

    bool Init();
    bool Open();

    QString GetParam (QString Param, QString Default);
    int     GetParam (QString Param, int Default);

    bool WriteParam (QString Param, int Value);
    bool WriteParam (QString Param, QString Value);

    QSqlQuery GetRecord   (QString Sql);

    bool      GetBFromName(QSqlQuery Qry, QString Name);
    int       GetIFromName(QSqlQuery Qry, QString Name);
    QString   GetSFromName(QSqlQuery Qry, QString Name);
    float     GetFFromName(QSqlQuery Qry, QString Name);
    QDateTime GetDFromName(QSqlQuery Qry, QString Name);

    bool ExecuteQuery(QString Sql );

    QSqlDatabase m_db;

    bool DBaseOk = false;

private:

    QSqlDatabase GetDatabase();

    QString ConnectioName;

};

#endif // DBMANAGER_H
