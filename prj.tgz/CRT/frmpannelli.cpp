#include "frmpannelli.h"
#include "ui_frmpannelli.h"
#include "global.h"
#include <QDebug>

frmPannelli::frmPannelli(QWidget *parent, int Brand) : QWidget(parent), ui(new Ui::frmPannelli)
{
    ui->setupUi(this);

    setWindowFlags(Qt::Widget | Qt::FramelessWindowHint | Qt::NoDropShadowWindowHint );

    setStyleSheet( "QGraphicsView { border-style: none; }" );

    QString Style = QString("background-color: rgb(16,16,16)");

    this->setStyleSheet(Style);

    this->Brand = Brand;

    Filtro = "";

    Num[0] = ui->Num_1;
    Num[1] = ui->Num_2;
    Num[2] = ui->Num_3;

    Sup[0] = ui->Sup_1;
    Sup[1] = ui->Sup_2;
    Sup[2] = ui->Sup_3;

    Inf[0] = ui->Inf_1;
    Inf[1] = ui->Inf_2;
    Inf[2] = ui->Inf_3;

    Cod[0] = ui->Cod_1;
    Cod[1] = ui->Cod_2;
    Cod[2] = ui->Cod_3;

    GTFS = new clsGtfs();

#ifdef USE_TABLE

    /************************************
     * TABLE
     ************************************/

    int wCol1 = 80;

    ui->Table->setSelectionBehavior(QAbstractItemView::SelectRows);

    ui->Table->setColumnWidth( 0, wCol1);

    ui->Table->setColumnWidth( 1, ui->Table->width() - wCol1 - 5);

    ui->Table->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);

    ui->Table->verticalHeader()->setDefaultSectionSize(32);

    ui->Table->setStyleSheet("QTableWidget::item { padding: 5px }");

    //connect( ui->Table, SIGNAL(cellClicked(int,int)), this, SLOT(onCellPal_Clicked(int,int)));

    //connect( ui->Table, SIGNAL(cellDoubleClicked(int,int)), this, SLOT(onCellPal_DoubleClicked(int,int)));

    RefreshTable(ui->Table);

#endif

    RefreshData();
}

/*******************************************************/
void frmPannelli::RefreshData(void)
/*******************************************************/
{
    int Row = 0;

    QString sCode;
    QString sNum;
    QString sSup;
    QString sInf;

    GTFS->Load_Velette(Filtro + "%", Brand, 1 );

    for (int j=0; j < GTFS->GTFS_Velette->count(); j++)
    {
        if ( (j+OffSet) >= GTFS->GTFS_Velette->count())
            continue;

        clsPanel *S = GTFS->GTFS_Velette->at(j + OffSet);

        if (Row < 3)
        {
            sCode = S->code;

            if (S->rowTypeId == 1) sNum = S->panelText;
            if (S->rowTypeId == 2) sSup = S->panelText;
            if (S->rowTypeId == 3) sInf = S->panelText;

            if (S->rowTypeId == 3)
            {
                Cod[Row]->setText(sCode);
                Sup[Row]->setText(sSup);
                Inf[Row]->setText(sInf);

                if (sNum.contains("|"))
                {
                    Num[Row]->setText(sNum.replace("|", "\n"));
                }
                else
                {
                    Num[Row]->setText(sNum);
                }


                Num[Row]->setProperty("Code", S->code);

                Row++;
            }
        }
    }

    for (int j=Row; j<3; j++)
    {
        Cod[j]->setText("");
        Num[j]->setText("");
        Sup[j]->setText("");
        Inf[j]->setText("");
    }
}

/*******************************************************/
void frmPannelli::RefreshTable( QTableWidget *Table)
/*******************************************************/
{
    Table->blockSignals(true);

    Table->setRowCount(0);

    QTableWidgetItem* item;

    int Row = 0;

    QFont FontCodice;
    QFont FontDesc;

    FontCodice.setPointSize(16);
    FontDesc.setPointSize(12);

    for (int j=0; j < GTFS->GTFS_Pannelli->count(); j++)
    {
        GPannelli *S = GTFS->GTFS_Pannelli->values().at(j);

        if (Filtro.length() > 0)
        {
            if (!S->Codice.startsWith(Filtro))
                continue;
        }

        Table->insertRow(Row);

        /*************************/

        item = new QTableWidgetItem(S->Codice);

        item->setTextAlignment( Qt::AlignHCenter );

        item->setBackground(Qt::red);
        item->setForeground(Qt::white);
        item->setFont(FontCodice);

        Table->setItem( Row, 0, item );

        /*************************/

        QString Text = QString("[%1]-[%2]-[%3]").arg(S->Num).arg(S->Sup).arg(S->Inf);

        item = new QTableWidgetItem( Text );

        item->setTextAlignment( Qt::AlignLeft );

        item->setBackground(Qt::blue);
        item->setForeground(Qt::white);
        item->setFont(FontDesc);

        Table->setItem( Row, 1, item );

        Row++;
    }

  //Table->resizeRowsToContents();

    Table->blockSignals(false);
}


frmPannelli::~frmPannelli()
{
    delete ui;
}

void frmPannelli::on_cmd_1_clicked()
{
    KeyPress(1);
}

void frmPannelli::on_cmd_2_clicked()
{
    KeyPress(2);
}

void frmPannelli::on_cmd_3_clicked()
{
    KeyPress(3);
}

void frmPannelli::on_cmd_4_clicked()
{
    KeyPress(4);
}

void frmPannelli::on_cmd_5_clicked()
{
    KeyPress(5);
}

void frmPannelli::on_cmd_6_clicked()
{
    KeyPress(6);
}

void frmPannelli::on_cmd_7_clicked()
{
    KeyPress(7);
}

void frmPannelli::on_cmd_8_clicked()
{
    KeyPress(8);
}
void frmPannelli::on_cmd_9_clicked()
{
    KeyPress(9);
}
void frmPannelli::on_cmd_0_clicked()
{
    KeyPress(0);
}

/***************************************************/
void frmPannelli::on_cmd_Ok_clicked()
/***************************************************/
{
    KeyPress(11);
}
/***************************************************/
void frmPannelli::on_cmd_Cancel_clicked()
/***************************************************/
{
    KeyPress(10);
}
/***************************************************/
void frmPannelli::on_cmd_Exit_clicked()
/***************************************************/
{
    emit BeepSignal();

    this->close();
}
/***************************************************/
void frmPannelli::KeyPress(int Key)
/***************************************************/
{
    emit BeepSignal();

    OffSet = 0;

    LastClick = Global::CurrentTime();

    if (Key >= 0 && Key <=9)
    {
        switch (kSwitch)
        {
            case 0:
                Filtro += QString::number(Key);
                break;
            case 1:
                Filtro += QChar(64+Key+(Key==0 ? 10 : 0));
                break;
            case 2:
                Filtro += QChar(74+Key+(Key==0 ? 10 : 0));
                break;
            case 3:
                if ( Key < 7)
                    Filtro += QChar(84+Key+(Key==0 ? 10 : 0));
                break;
        }

        ui->L_Filtro->setText(Filtro);

        RefreshData();
    }

    if (Key == 10)
    {
        if (Filtro.length() > 0)
        {
            Filtro = Filtro.mid(0, Filtro.length() - 1);

            ui->L_Filtro->setText(Filtro);

            RefreshData();
        }
    }

    if (Key == 11)
    {
        kSwitch = (kSwitch + 1) % 4;

        switch (kSwitch)
        {
            case 0:
                ui->cmd_1->setIcon(QIcon(":/Icone/one.png"));
                ui->cmd_2->setIcon(QIcon(":/Icone/two.png"));
                ui->cmd_3->setIcon(QIcon(":/Icone/three.png"));
                ui->cmd_4->setIcon(QIcon(":/Icone/four.png"));
                ui->cmd_5->setIcon(QIcon(":/Icone/five.png"));
                ui->cmd_6->setIcon(QIcon(":/Icone/six.png"));
                ui->cmd_7->setIcon(QIcon(":/Icone/seven.png"));
                ui->cmd_8->setIcon(QIcon(":/Icone/eight.png"));
                ui->cmd_9->setIcon(QIcon(":/Icone/nine.png"));
                ui->cmd_0->setIcon(QIcon(":/Icone/zero.png"));
                break;
            case 1:
                ui->cmd_1->setIcon(QIcon(":/Icone/letter-a.png"));
                ui->cmd_2->setIcon(QIcon(":/Icone/letter-b.png"));
                ui->cmd_3->setIcon(QIcon(":/Icone/letter-c.png"));
                ui->cmd_4->setIcon(QIcon(":/Icone/letter-d.png"));
                ui->cmd_5->setIcon(QIcon(":/Icone/letter-e.png"));
                ui->cmd_6->setIcon(QIcon(":/Icone/letter-f.png"));
                ui->cmd_7->setIcon(QIcon(":/Icone/letter-g.png"));
                ui->cmd_8->setIcon(QIcon(":/Icone/letter-h.png"));
                ui->cmd_9->setIcon(QIcon(":/Icone/letter-i.png"));
                ui->cmd_0->setIcon(QIcon(":/Icone/letter-j.png"));
                break;
            case 2:
                ui->cmd_1->setIcon(QIcon(":/Icone/letter-k.png"));
                ui->cmd_2->setIcon(QIcon(":/Icone/letter-l.png"));
                ui->cmd_3->setIcon(QIcon(":/Icone/letter-m.png"));
                ui->cmd_4->setIcon(QIcon(":/Icone/letter-n.png"));
                ui->cmd_5->setIcon(QIcon(":/Icone/letter-o.png"));
                ui->cmd_6->setIcon(QIcon(":/Icone/letter-p.png"));
                ui->cmd_7->setIcon(QIcon(":/Icone/letter-q.png"));
                ui->cmd_8->setIcon(QIcon(":/Icone/letter-r.png"));
                ui->cmd_9->setIcon(QIcon(":/Icone/letter-s.png"));
                ui->cmd_0->setIcon(QIcon(":/Icone/letter-t.png"));
                break;
            case 3:
                ui->cmd_1->setIcon(QIcon(":/Icone/letter-u.png"));
                ui->cmd_2->setIcon(QIcon(":/Icone/letter-v.png"));
                ui->cmd_3->setIcon(QIcon(":/Icone/letter-w.png"));
                ui->cmd_4->setIcon(QIcon(":/Icone/letter-x.png"));
                ui->cmd_5->setIcon(QIcon(":/Icone/letter-y.png"));
                ui->cmd_6->setIcon(QIcon(":/Icone/letter-z.png"));
                ui->cmd_7->setIcon(QIcon(":/Icone/vuoto.png"));
                ui->cmd_8->setIcon(QIcon(":/Icone/vuoto.png"));
                ui->cmd_9->setIcon(QIcon(":/Icone/vuoto.png"));
                ui->cmd_0->setIcon(QIcon(":/Icone/vuoto.png"));
            break;
        }

    }
}

/***************************************************/
void frmPannelli::ViewData(void)
/***************************************************/
{
    #if false
    Gtfs.Read_Cartelli(Filtro + "%");

    nCode = 0;

    foreach (GTFS_Panel Panel in Gtfs.Cartelli)
    {
        if (nCode < 8)
        {
            cmd_Code[nCode].SetText(Panel.Codice, TextView.BufferType.Normal);

            String T = "";

            if (Panel.Num.Trim().Length > 0) T += Panel.Num + " / ";
            if (Panel.Sup.Trim().Length > 0) T += Panel.Sup;
            if (Panel.Inf.Trim().Length > 0) T += " / " + Panel.Inf;

            cmd_Line[nCode].SetText(T, TextView.BufferType.Normal);

            nCode++;
        }
        else
            break;
    }

    for (int j = nCode; j < 8; j++)
    {
        cmd_Code[j].SetText("", TextView.BufferType.Normal);
        cmd_Line[j].SetText("", TextView.BufferType.Normal);
    }
    #endif
}


void frmPannelli::on_cmd_Send_clicked()
{
    emit BeepSignal();

    int Row = ui->Table->currentRow();

    QTableWidgetItem *item = ui->Table->item(Row, 0);

    Global::PanelCode = item->text();

    emit SendMessage(Global::PanelCode);
}

void frmPannelli::on_cmd_Up_clicked()
{
    emit BeepSignal();

    if (OffSet > 3)
        OffSet -= 3;

    RefreshData();
}

void frmPannelli::on_cmd_Down_clicked()
{
    emit BeepSignal();

    if (OffSet < GTFS->GTFS_Velette->count() - 3)
        OffSet += 3;

    RefreshData();
}

void frmPannelli::on_Num_1_clicked()
{
    emit BeepSignal();

    Global::PanelCode = Num[0]->property("Code").toString();

    emit SendMessage(Global::PanelCode);
}

void frmPannelli::on_Num_2_clicked()
{
    emit BeepSignal();

    Global::PanelCode = Num[1]->property("Code").toString();

    emit SendMessage(Global::PanelCode);
}

void frmPannelli::on_Num_3_clicked()
{
    emit BeepSignal();

    Global::PanelCode = Num[2]->property("Code").toString();

    emit SendMessage(Global::PanelCode);
}
