//Moved to ElmecDriver Maybe part of this code must be slpit to a ElmecManager
#ifndef CLSDISPLAYELMEC_H
#define CLSDISPLAYELMEC_H

#include <QObject>
#include <QThread>
#include <QDateTime>
#include "tcpclient.h"
#include "global.h"

class clsDisplayElmec : public QThread
{
    Q_OBJECT

public:

    // Already moved to enumerations.h in the new prj
    enum eStatus
    {
        Init = 2,
        Up   = 1,
        Down = 0
    };

    Q_ENUM(eStatus)

    explicit clsDisplayElmec(QObject *parent = nullptr);

    ~clsDisplayElmec();

    void run() Q_DECL_OVERRIDE;
    void StartThread();
    void StopThread();
    bool Quit;


    void Config      (QString IP, int Port, ePanelType Tipo, ePanelModel Model , QString Code, QString ID);
    void SetPanel    (QString Num, QString NumFore, QString NumBack, QString Sup, QString SupFore, QString SupBack, QString Inf, QString InfFore, QString InfBack);
    int  ConvertColor(QString Rgb);
    void qSleep      (int ms);

    QString IP;
    int     Port;
    QString DID;
    QString DCode;
    int     TipoPannello;
    int     Modello;
    int     Brand;
    eStatus Status;
    bool    Refresh = true;
    QString Velette = "";
    QString JS = "";
    QDateTime LastPoll;

    TcpClient    *ElmecClient;

private:

    void Loop();

signals:

public slots:

};

#endif // CLSDISPLAYELMEC_H
