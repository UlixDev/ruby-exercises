// Moved
#ifndef CLSVTEC_H
#define CLSVTEC_H

#include <QObject>
#include <QThread>
#include <QDateTime>
#include "tcpclient.h"

class clsVTec : public QThread
{
    Q_OBJECT

public:

    // Better leave it here
    enum eVTecModel
    {
        VTec17 = 1,
        VTecS  = 2,
        Ob108  = 3
    };

    // Already exist an eStatus enum class in enumerations.h in the new prj
    // Use that
    enum eVTecStatus
    {
        Init = 2,
        Up   = 1,
        Down = 0
    };

    Q_ENUM(eVTecStatus)

    explicit clsVTec(QObject *parent = nullptr);

    ~clsVTec();

    void run() Q_DECL_OVERRIDE;
    void StartThread();
    void StopThread();
    bool Quit;


    void Config      (QString IP, int Port, int ID);
    void BuildRequest(bool DesStatus, bool Ref);
    void qSleep      (int ms);

    QString     IP;
    int         Port;
    int         ID;
    eVTecStatus Status;
    int         VTecMode   = 1;
    int         CounterTot = 0;
    int         CounterPar = 0;
    bool        Refresh = true;
    QString     JS = "";
    QDateTime   LastPoll;

    TcpClient   *VTecClient;

private:

    void Loop();

signals:

public slots:

};

#endif // CLSVTEC_H
