#include <QDebug>

#include <QFile>
#include <QDir>
#include <QCryptographicHash>
#include <QDirIterator>
#include <QSignalSpy>
#include <QThread>
#include <QJsonArray>
#include <QJsonObject>
#include <QSettings>
#include <QDateTime>
#include <QProcess>
#include <QtMath>
#include <QHostAddress>

#include "clswebservice.h"
#include "global.h"

clsWebService::clsWebService( QObject *parent ) : QObject(parent)
{
    TimeSocket = new QTcpSocket();

    connect(TimeSocket, SIGNAL(readyRead()), this, SLOT( onTimeReadyRead() ));
}

/******************************************/
bool clsWebService::SincTime(void)
/******************************************/
{
    TimeSocket->connectToHost(QHostAddress("193.204.114.105"), 13);

    return true;
}

/*******************************************************************/
void clsWebService::onTimeReadyRead(void)
/*******************************************************************/
{
    QByteArray datas = TimeSocket->readAll();

    // "17 NOV 2021 13:53:15 CET"

    QDateTime b = QDateTime::fromString(datas.mid(0, 20), "dd MMM yyyy HH:mm:ss");

    if (Global::FL_Utc)
        Global::TimeOffset = datas.contains("CEST") ? 7200 : 3600;
    else
        Global::TimeOffset = 0;

    emit Signal_TimeOffset(Global::TimeOffset);

    /*****************************************************/

    b = b.addSecs(-Global::TimeOffset);

    QString Cmd = "date -s \"" + b.toString("yyyy-MM-dd HH:mm:ss") + "\"";

    QProcess process;

    process.start(Cmd);
    process.waitForFinished(5000);

    process.start("hwclock -w");
    process.waitForFinished(5000);

    qDebug() << "TIMESINC: " << datas;
    qDebug() << "TIMESINC: " << Global::CurrentTime();
}

/*******************************************************************/
bool clsWebService::WSCall(QString Path, QString ApiKey)
/*******************************************************************/
{
    QUrl Url(Path);

    qDebug() << Path;

    ApiKey = ApiKey.isEmpty() || ApiKey.isNull() || ApiKey.compare("") == 0 ? Global::ApiKey : ApiKey;

    QNetworkRequest Request(Url);

    QSslConfiguration sslConfig = Request.sslConfiguration();

    sslConfig.setPeerVerifyMode(QSslSocket::VerifyNone);

    sslConfig.setProtocol(QSsl::TlsV1_0OrLater);

    QNetworkAccessManager *Manager = new QNetworkAccessManager();

    connect( Manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(onResult(QNetworkReply*)));

    Request.setSslConfiguration(sslConfig);

    Request.setRawHeader( QByteArray("ApiKey"), ApiKey.toLocal8Bit() );

    QSignalSpy Spy ( this, SIGNAL(Success()));

    QDateTime T0 = Global::CurrentTime();

    Manager->get(Request);

    bool Ok = Spy.wait(10000);

    // qDebug() << QString("APITIME: %1 - Path:%2").arg(T0.msecsTo(Global::CurrentTime())).arg(Path);

    if (!Ok)
        qDebug() << "ERROR: " << Path;

    delete Manager;

    return Ok;
}

/*******************************************************************/
bool clsWebService::WSPostCall(QString Path, QUrlQuery PostData )
/*******************************************************************/
{
#ifdef DEBUG
    QDateTime start = Global::CurrentTime();
    qDebug() << start.toString("HH:mm:ss");
#endif

    QUrl Url(Path);

    QNetworkRequest Request(Url);

    QSslConfiguration sslConfig = Request.sslConfiguration();

        sslConfig.setPeerVerifyMode(QSslSocket::VerifyNone);

        sslConfig.setProtocol(QSsl::TlsV1_0OrLater);

        Request.setSslConfiguration(sslConfig);

    Request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");

    QNetworkAccessManager *Manager = new QNetworkAccessManager();

    QSignalSpy Spy ( this, SIGNAL(Success()));

    connect( Manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(onResult(QNetworkReply*)));

    QByteArray Temp = PostData.toString(QUrl::FullyEncoded).toUtf8();

    Manager->post( Request,  Temp);

    bool Ok = Spy.wait(5000);

    if (!Ok)
       Logger(QString("WSPostCall Error: %1 - %2").arg(Path).arg(QString(Web_Response)));

    delete Manager;

#ifdef DEBUG
    qDebug() << "Chiamata: " << Path;
    qDebug() << Global::CurrentTime().msecsTo(start);
    qDebug() << "Chiamata: " << Web_Response;
#endif

    return Ok;

}
/*******************************************************************/
bool clsWebService::WSPostCall_Api(QString Path, QByteArray PostData, QString ApiKey)
/*******************************************************************/
{
    QDateTime T0 = Global::CurrentTime();

    QUrl Url(Path);

    qDebug() << Path;

    QNetworkRequest Request(Url);

    ApiKey = ApiKey.isEmpty() || ApiKey.isNull() || ApiKey.compare("") == 0 ? Global::ApiKey : ApiKey;

    QSslConfiguration sslConfig = Request.sslConfiguration();

    sslConfig.setPeerVerifyMode(QSslSocket::VerifyNone);

    sslConfig.setProtocol(QSsl::TlsV1_0OrLater);

    QNetworkAccessManager *Manager = new QNetworkAccessManager();

    connect( Manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(onResult(QNetworkReply*)));

    Request.setSslConfiguration(sslConfig);

    Request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    Request.setRawHeader( QByteArray("ApiKey"), ApiKey.toLocal8Bit() );

    QSignalSpy Spy ( this, SIGNAL(Success()));

    Manager->post( Request, PostData );

    bool Ok = Spy.wait(5000);

    qDebug() << QString("APITIME: %1 - Path:%2").arg(T0.msecsTo(Global::CurrentTime())).arg(Path);

    if (!Ok)
    {
        qDebug() << "ERROR: " << Path;
        qDebug() << "JS   : " << PostData;
        qDebug() << "RESP : " << Web_Response;
    }

    delete Manager;

    return Ok;
}

/*******************************************************************/
void clsWebService::onResult(QNetworkReply *Reply)
/*******************************************************************/
{
    if (Reply->error() != QNetworkReply::NoError)
    {
        Logger("Reply error: " + Reply->errorString());

        return;
    }

    Web_Response = Reply->readAll();

    if (Web_Response.startsWith("<?xml version"))
    {
        int S = Web_Response.indexOf("[");

        if (S > 0)
        {
            Web_Response = Web_Response.mid(S);
            Web_Response = Web_Response.left( Web_Response.length() - 9);
        }

    }

    Reply->deleteLater();

    emit Success();
}

/*******************************************************************/
void clsWebService::Logger(QString Message)
/*******************************************************************/
{
    QString Name = QDate::currentDate().toString("yyyy-MM-dd.txt");

    QString Filename = QCoreApplication::applicationDirPath()+ "/" + Name;

    QFile file(Filename);

    if (file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
    {
        QTextStream stream(&file);

        stream << Global::CurrentTime().toString("dd.MM.yyyy HH:mm:ss") << " " << Message << "\n";

        file.close();
    }

    qDebug() << Message;
}
