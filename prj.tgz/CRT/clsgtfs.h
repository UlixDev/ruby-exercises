// moved to GTFSManager
// enum moved to enumerations.h directory
// All other classes moved to protocols directory
// GTFS stands for General Transit Feed Specification
#ifndef CLSGTFS_H
#define CLSGTFS_H

#include <QString>
#include <QDateTime>
#include <QMap>
#include <QMutex>
#include "dbmanager.h"

class GShape;
class GStops;
class GTrips;
class GRoute;
class GStopTimes;
class GTurni;
class GTrack;
class GRepo;
class GPannelli;
class clsPanel;

// Moved in enumerations.h in the new prj
enum eMarker : int
{
    Capolinea = 53,
    FineLinea = 54,
    Palina    = 49,
    Auto      = 51
};

class clsGtfs
{
public:

    clsGtfs();

    bool Read_Gtfs(bool FL_New, QString Agenzia);

    bool Read_Repo(QString Agenzia, int Tipo);
    bool Read_StopsTime(QString Agenzia);
    bool Read_Stops(QString Agenzia);
    bool Read_Trips(QString Agenzia);
    bool Read_Routes(QString Agenzia);
    bool Read_Shapes(bool FL_All, QString ShapeID, QString Agenzia);
    bool Read_Turni     (QString Agenzia);
    bool Read_Cartelli  (QString Agenzia);
    bool Read_Velette   (QString Agenzia, int Brand);

    bool Save_Stops ();
    bool Save_StopsTime();
    bool Save_Trips ();
    bool Save_Routes();
    bool Save_Shape (QString ShapeID);
    bool Save_Turni ();
    bool Save_Cartelli();
    bool Save_Velette ();

    int  Load_Repo      ();
    bool Load_Stops     ();
    bool Load_StopsTime (QString TripID);
    int  Load_Trips     (QString TripID);
    bool Load_Routes    ();
    bool Load_Shapes    (QString ShapeID);
    bool Load_Turni     (QString Duty, QDateTime Data);
    bool Load_Track     (QString ShapeID);
    bool Load_Cartelli  ();
    int  Load_Velette   (QString Filtro, int Brand, int Model);

    QList<QString> *Load_ElencoTurni( QDateTime Data );

    bool Write_Stops();

    QMap <QString,GRepo*>       *GTFS_MyRepo = nullptr;
    QMap <QString,GRepo*>       *GTFS_Repo   = nullptr;
    QMap <QString,GStops*>      *GTFS_Stops  = nullptr;
    QMap <QString,GTrips*>      *GTFS_Trips  = nullptr;
    QMap <QString,GRoute*>      *GTFS_Routes = nullptr;
    QMap <QString,GTurni*>      *GTFS_Turni  = nullptr;
    QMap <QString,GPannelli*>   *GTFS_Pannelli = nullptr;

    QList<clsPanel*>            *GTFS_Velette   = nullptr;
    QList<GStopTimes*>          *GTFS_StopTimes = nullptr;
    QList<GShape*>              *GTFS_Shapes    = nullptr;
    QList<GTrack*>              *GTFS_Track     = nullptr;

    QString Rev;
    QString Agenzia;
    bool    Busy = false;

private:

    DBManager *DBase;

};

class GRepo
{

public:

    // Moved in enumerations.h in the new prj
    enum eAction : int
    {
        None   = 0,
        Update = 1,
        Delete = 2,
        Insert = 3
    };

    int       ID;
    QString   Object;
    QString   Rev;
    QDateTime LastUpdate;

    eAction   Action;

};

class GStops
{
public:
    QString Stop_ID;
    QString Location_Type;
    QString Parent_Station;
    QString Stop_Code;
    QString Stop_Desc;
    QString Stop_Name;
    QString Stop_TimeZone;
    QString Stop_Url;
    QString Wheelchair_Boarding;
    QString Zone_ID;
    float   Lat;
    float   Lng;
    int     StopIndex;
    int     Radius;
};

class GPannelli
{
public:
    QString Codice;
    QString Descrizione;
    QString Num;
    QString Sup;
    QString Inf;
};

class clsPanel
{
public:
    QString code;
    int     brandId;
    int     modelId;
    int     rowTypeId;
    int     fontId;
    bool    slide;
    QString panelText;
    QString color;
    QString bgColor;
};

class GVelette
{
public:
    QString     code;
    int         brandId;
    clsPanel    rowPanels[10];
};

class GStopTimes
{
public:
    QString Trip_Id;
    QString Stop_Id;
    QString Arrival_Time;
    QString Departure_Time;
    int     Stop_Sequence;

    int 	TrackPtr;
    bool    Enabled;
};

class GCalendar
{
public:

    QString     Service_Id;
    bool        Week[7];
    QDateTime   Start_Date;
    QDateTime   End_Date;
};

class GTrips
{
public:

     QString	Route_ID;
     QString 	Service_Id;
     QString 	Trip_Id;
     QString 	Trip_Headsign;
     QString 	Trip_Short_Name;
     QString 	Direction_Id;
     QString 	Block_Id;
     QString 	Shape_Id;
     QString 	Wheelchair_Accessible;
     QString 	Bikes_Allowed;
     int        nStop;
};

class GRoute
{
public:

     QString routeId;
     QString routeShortName;
     QString routeLongName;
     QString agencyId;
     QString routeDesc;
     QString routeUrl;
     QString routeColor;
     QString routeTextColor;
     QString routeType;
     int    trips;
};

class GShape
{
public:
    QString ShapeID;
    int     Seq;
    float   Lat;
    float   Lng;
    int     Marker;

    float   Metri;  //da togliere
    float   Course; //da togliere
};

class GTurni
{
public:

    int    	ID;
    QString DutyID;
    QString DutyName;
    QString TripID;
    QString Loc_Partenza;
    QString Loc_Arrivo;
    QString Route_ID;
    QString ShapeID;
    QString Route_Long_Name;
    QString ServiceID;
    QString BColor;
    QString Activity_Type;
    int    	Activity;
    float   Planned_Length;
    float  	Km_Reali;
    bool 	Done;
    int     nFermate;
    bool	SingleTrip;
    QDateTime Data_Partenza;
    QDateTime Data_Arrivo;
};

class GTrack
{
public:

    QString     ShapeID;
    QString     StopID;

    int         Seq;
    float       Lat;
    float       Lng;
    eMarker     Marker;

    int         TripSeq;
    float   	Velocita_Media;
    float   	Angolo;
    float   	Distance;
    float       Metri;
    int         Radius;
    int 		Stop_Index;
    int 		Arrival_Time;
    int 		Departure_Time;
    int 		Prevision_Time;
    QDateTime   Orario_Statico;

    GTrack()
    {

    }

    GTrack( eMarker Marker, float Lat, float Long, int TripSeq, QString StopID, int Stop_Index, int StopSeq, int Radius)
    {
        this->Marker  = Marker;
        this->Lat     = Lat;
        this->Lng     = Long;
        this->TripSeq = TripSeq;
        this->StopID  = StopID;
        this->Stop_Index = Stop_Index;
        this->Seq     = StopSeq;
        this->Radius  = Radius;

        this->Velocita_Media = 0;
        this->Angolo         = 0;
        this->Distance       = 0;
    }
};


#endif // CLSGTFS_H
