#include "tcpclientman.h"

#include <QCoreApplication>
#include <QHostAddress>
#include <QSignalMapper>
#include <QTimer>
#include <QDateTime>

#include "json.h"
#include "global.h"

TcpClientMan::TcpClientMan(qintptr ID, QObject *parent) : QThread(parent)
{
    this->socketDescriptor = ID;

    OldThread = QThread::currentThread();

    moveToThread(this);
}

void TcpClientMan::Init()
{
}

/*****************************************/
void TcpClientMan::run()
/*****************************************/
{
    socket = new QTcpSocket;

    if(!socket->setSocketDescriptor(this->socketDescriptor))
    {
        emit error(socket->error());
        return;
    }

    qDebug() << QString("Client %1 connected").arg( socket->peerAddress().toString() );

    connect(socket, SIGNAL(readyRead()), this, SLOT(readyRead()), Qt::DirectConnection);

    connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()));

    connect(socket, SIGNAL(destroyed(QObject*)), this, SLOT(deleteLater()));

    if (Global::Agenzia.length() > 0)
        SendProcessStatus("ready");
    else
        SendProcessStatus("wait");

    exec();
}

/*****************************************/
void TcpClientMan::WriteMessage(int ClientID, QByteArray Data)
/*****************************************/
{
    if (ClientID == this->socketDescriptor || ClientID==-1 )
    {
        qDebug() << "TxWorker thread id: " << QThread::currentThreadId() << " " << socket->state();

        socket->write(Data, Data.length());

    }
}

/*****************************************/
void TcpClientMan::WriteMessage2 (const QString &Data)
/*****************************************/
{
    qDebug() << "TxWorker thread id: " << QThread::currentThreadId() << " " << socket->state();

    QByteArray Msg = Data.toLocal8Bit();

    socket->write(Msg);
}

/*****************************************/
void TcpClientMan::readyRead()
/*****************************************/
{
    qDebug() << "RxWorker thread id:" << QThread::currentThreadId();

    QByteArray Data = socket->readAll();

//    socket->write( ">" );

    emit MessageReceived(this->socketDescriptor, Data);
}

/*****************************************/
void TcpClientMan::disconnected()
/*****************************************/
{
    qDebug() << socketDescriptor << " Disconnected";

    moveToThread(OldThread);

    socket->deleteLater();

    exit(0);
}

/*****************************************/
void TcpClientMan::sendMsgDelayed(int ClientID, const QString &Data)
/*****************************************/
{
    if (ClientID == this->socketDescriptor || ClientID==-1 )
    {
        QSignalMapper* signalMapper = new QSignalMapper(this);

        connect(signalMapper, SIGNAL(mapped(QString)), this, SLOT(WriteMessage2(QString)));

        QTimer* timer = new QTimer(this);

        timer->moveToThread(this);

        timer->setInterval(10);
        timer->setSingleShot(true);

        signalMapper->setMapping(timer, Data);
        connect(timer, SIGNAL(timeout()), signalMapper, SLOT(map()));
        connect(timer, SIGNAL(timeout()), timer, SLOT(deleteLater()));

        timer->start();
    }
}

/*****************************************/
void TcpClientMan::SendProcessStatus( QString Status )
/*****************************************/
{
    bool Ok = false;
    QVariantMap Data;
    QDateTime   Now = Global::CurrentTime();

    Data.insert("action"   , "avm-process-status");
    Data.insert("timestamp", Now.toString("dd/MM/yyyy HH:mm:ss") );
    Data.insert("status"   , Status   );

    QtJson::setPrettySerialize(true);

    QString JS = QtJson::serialize(Data, Ok) + "\n\n";

    if (Ok)
    {
        WriteMessage2( JS.toLocal8Bit() );
    }
}
