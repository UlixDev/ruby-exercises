//moved to GpsSimulator
// other classes moved to types directory
#ifndef CLSSIMULATORE_H
#define CLSSIMULATORE_H

#include <QThread>
#include <QList>
#include <QDateTime>

#include "Positioning/qgeocoordinate.h"

class GpsData;

class clsSimulatore : public QThread
{
    Q_OBJECT

public:

    explicit clsSimulatore(QObject *parent = nullptr);
    ~clsSimulatore();

    void run() Q_DECL_OVERRIDE;

signals:

    void DataReady( GpsData Data );

private:

    QList<GpsData> *Gps;

    int LoadFile(QString FileName);

};

class GpsData
{
public:

    QDateTime       TimeStamp;
    long            mTime;
    bool            GpsFix;
    QGeoCoordinate  Coord;
    int             PassIN;
    int             PassOUT;
    QString         StopID;
};

Q_DECLARE_METATYPE(GpsData)


#endif // CLSSIMULATORE_H
