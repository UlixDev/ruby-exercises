#include "clsinfobus.h"
#include "ui_clsinfobus.h"

clsInfoBus::clsInfoBus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::clsInfoBus)
{
    ui->setupUi(this);
}

clsInfoBus::~clsInfoBus()
{
    delete ui;
}
