// moved to forms/ui renamed in Panels
#ifndef FRMPANNELLI_H
#define FRMPANNELLI_H

#include <QWidget>
#include <QDateTime>
#include <QLabel>
#include <QPushButton>
#include <QTableWidget>

#include "clsgtfs.h"

namespace Ui
{
    class frmPannelli;
}

class frmPannelli : public QWidget
{
    Q_OBJECT

public:
    explicit frmPannelli(QWidget *parent = nullptr, int Brand = 0);
    ~frmPannelli();

private slots:

    void on_cmd_1_clicked();
    void on_cmd_2_clicked();
    void on_cmd_3_clicked();
    void on_cmd_4_clicked();
    void on_cmd_5_clicked();
    void on_cmd_6_clicked();
    void on_cmd_7_clicked();
    void on_cmd_8_clicked();
    void on_cmd_9_clicked();
    void on_cmd_0_clicked();

    void on_cmd_Ok_clicked();
    void on_cmd_Cancel_clicked();
    void on_cmd_Exit_clicked();

    void on_cmd_Send_clicked();

    void on_cmd_Up_clicked();

    void on_cmd_Down_clicked();

    void on_Num_1_clicked();

    void on_Num_2_clicked();

    void on_Num_3_clicked();

private:

    Ui::frmPannelli *ui;

    QDateTime LastClick;
    QString   Filtro;
    clsGtfs   *GTFS;

    void KeyPress       (int Key);
    void ViewData       (void);
    void RefreshTable   (QTableWidget *Table);
    void RefreshData    (void);

    QPushButton *Num[3];
    QLabel      *Sup[3];
    QLabel      *Inf[3];
    QLabel      *Cod[3];

    int OffSet  = 0;
    int kSwitch = 0;
    int Brand   = 0;

signals:

    void SendMessage(QString Codice);
    void BeepSignal();
};

#endif // FRMPANNELLI_H
