//moved
#ifndef CLSWEBSERVICE_H
#define CLSWEBSERVICE_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrlQuery>

class clsWebService : public QObject
{
    Q_OBJECT

public:

    explicit clsWebService(QObject *parent = nullptr);

    bool WSCall         (QString Path, QString ApiKey = "");
    bool WSPostCall     (QString Path, QUrlQuery PostData);
    bool WSPostCall_Api (QString Path, QByteArray PostData, QString ApiKey = "");
    bool SincTime   (void);

    QByteArray             Web_Response;

private:

    void Logger (QString Message);

    QTcpSocket *TimeSocket;

private slots:

    void onResult(QNetworkReply *Reply);

    void onTimeReadyRead(void);

signals:

    void Success();
    void Signal_TimeOffset(int offset);

};

#endif // CLSWEBSERVICE_H
