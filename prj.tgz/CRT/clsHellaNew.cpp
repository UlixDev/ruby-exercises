// Moved
#include <qmath.h>

#include "clsHellaNew.h"
#include "logger.h"

clsHellaNew::clsHellaNew()
{
    Lista = new QMap<QString, HellaInfo *>();
}

/*****************************************************************/
void clsHellaNew::Config (QList<QString> Pax, int Port)
/*****************************************************************/
{
    HellaPort = Port;

    for (int j=0; j<Pax.count(); j++)
        Lista->insert(Pax.at(j), new HellaInfo(Pax.at(j), j+1));

    this->LastHellaRes = QDateTime::fromMSecsSinceEpoch(0);

    if (Lista->keys().count() > 0)
    {
        PaxOft = 0;

        Socket = new QUdpSocket(this);

        connect(Socket, SIGNAL(readyRead()), this, SLOT(ReadyRead()));

        Socket->bind(QHostAddress::Any, HellaPort);
    }
}

/*****************************************************************/
void clsHellaNew::ReadyRead(void)
/*****************************************************************/
{
   QByteArray Buffer;

   Buffer.resize(Socket->pendingDatagramSize());

   QHostAddress Sender;

   quint16 SenderPort;

   Socket->readDatagram(Buffer.data(), Buffer.size(), &Sender, &SenderPort);

   QString ipAddress = Sender.toString().mid(7);

   //qDebug() << "Hella Rx from " << ipAddress;

   for (int j=0; j < Lista->count(); j++)
   {
       HellaInfo *Hella = Lista->values().at(j);

       // se l'ip corrisponde al dispositivo Hella

       if (Hella->IP.compare(ipAddress) == 0)
       {
           //qDebug() << "HELLA: receive message " << QString(Buffer) << " from " << Sender  << " " << QDateTime::currentMSecsSinceEpoch();;

           //Logger::Info("HELLA", QString("Receiving message: %1").arg(QString(Buffer)));

           Hella->LastRx = Global::CurrentTime();

           Hella->Pending = true;

           /*
            * se la risposta è per l'apertura delle porte
            */

           if (QString(Buffer).startsWith(READ_DOOR) && Buffer.length() == READ_DOOR.length() + 1)
           {
               if (QString(Buffer).mid(READ_DOOR.length(), 1) == "0")    
                   Hella->StatoPorte = eDoorStatus::Opened;

               else if (QString(Buffer).mid(READ_DOOR.length(), 1) == "1")
                   Hella->StatoPorte = eDoorStatus::Closed;

               else               
                   Hella->StatoPorte = eDoorStatus::Unknow;

               //qDebug() << "Hella StatoPorte: " << Hella->ID << " " << ((Hella->StatoPorte == eDoorStatus::Opened) ? "APERTE" : "CHIUSE");
           }

           // se la risposta è per i passeggeri

           if (QString(Buffer).startsWith(READ_COUNTER) && Buffer.length() == READ_COUNTER.length() + 16)
           {
               QString TempS = QString(Buffer).mid(READ_COUNTER.length(), 8);
               QString TempD = QString(Buffer).mid(READ_COUNTER.length() + 8, 8);

               TempS = TempS.replace(":", "A");
               TempS = TempS.replace(";", "B");
               TempS = TempS.replace("<", "C");
               TempS = TempS.replace("=", "D");
               TempS = TempS.replace(">", "E");
               TempS = TempS.replace("?", "F");

               Hella->PassIn = TempS.toInt(nullptr, 16);

               TempD = TempD.replace(":", "A");
               TempD = TempD.replace(";", "B");
               TempD = TempD.replace("<", "C");
               TempD = TempD.replace("=", "D");
               TempD = TempD.replace(">", "E");
               TempD = TempD.replace("?", "F");

               Hella->PassOut = TempD.toInt(nullptr, 16);

               //qDebug() << "Hella PassIn: " << QString::number(Hella->PassIn) << " PassOut: " << QString::number(Hella->PassOut);
           }

           if (QString(Buffer).startsWith(READ_COUNTER) && Buffer.length() == READ_COUNTER.length() + 4)
           {
               QString TempS = QString(Buffer).mid(READ_COUNTER.length(), 2);
               QString TempD = QString(Buffer).mid(READ_COUNTER.length() + 2, 2);

               TempS = TempS.replace(":", "A");
               TempS = TempS.replace(";", "B");
               TempS = TempS.replace("<", "C");
               TempS = TempS.replace("=", "D");
               TempS = TempS.replace(">", "E");
               TempS = TempS.replace("?", "F");

               Hella->PassIn = TempS.toInt(nullptr, 4);

               TempD = TempD.replace(":", "A");
               TempD = TempD.replace(";", "B");
               TempD = TempD.replace("<", "C");
               TempD = TempD.replace("=", "D");
               TempD = TempD.replace(">", "E");
               TempD = TempD.replace("?", "F");

               Hella->PassOut = TempD.toInt(nullptr, 4);

               //qDebug() << "Hella PassIn: " << QString::number(Hella->PassIn) << " PassOut: " << QString::number(Hella->PassOut);
           }
       }
   }
}

/*****************************************************************/
void   clsHellaNew::run()
/*****************************************************************/
{
    QDateTime   OpenDoorTime  = QDateTime::fromMSecsSinceEpoch(0);
    QString     RequestData;
    QDateTime   LastBroadCast = QDateTime::fromMSecsSinceEpoch(0);


    int TWait = 1000;
    int PSal;
    int PDis;
    int oTot = 0;

    int oPSal = -1;
    int oPDis = -1;

    if (Lista->keys().count() == 0) return;

    while (Global::Running)
    {
        QDateTime Now = Global::CurrentTime();

        bool OkSend = (fabs(Now.msecsTo(LastBroadCast)) >= TWait);

        if (OkSend)
        {
            LastBroadCast = Now;

            if(Flip)
                RequestData = QString("%1%2").arg(READ_COUNTER).arg("U1");
            else
                RequestData = QString("%1%2").arg(READ_DOOR).arg("1");

            Flip = !Flip;

            try
            {
                SendMessageBroadcast(RequestData);
            }
            catch (...)
            {
                Logger::Info("HELLA", " ERROR sending data");
            }

            /****************************
             * CONTROLLO FUNZIONAMENTO
             ****************************/

            Status = eStatus::Up;

            for (int j=0; j < Lista->count(); j++)
            {
                HellaInfo *Hella = Lista->values().at(j);

                if (fabs(Now.msecsTo(Hella->LastRx)) >= TWait * 3)
                {
                    Hella->Stato = eStatus::Down;
                    Status = eStatus::Down;
                }
                else
                    Hella->Stato = eStatus::Up;
            }

            if (Status != oStatus)
            {
                oStatus = Status;

                emit CpxStatusChanged(Status);
            }
        }

        PSal = 0;
        PDis = 0;

        StatoPorte = eDoorStatus::Closed;

        for (int j=0; j < Lista->count(); j++)
        {
            HellaInfo *Hella = Lista->values().at(j);

            PSal += Hella->PassIn;
            PDis += Hella->PassOut;

            if (Hella->StatoPorte != eDoorStatus::Unknow)
            {
                if (Hella->StatoPorte == eDoorStatus::Opened)
                    StatoPorte = eDoorStatus::Opened;
            }

            if (Hella->Pending)
            {
                Hella->Pending = false;

                FL_SalDis = true;

                LastHellaRes = Global::CurrentTime();
            }
        }

        if (PDis > (PSal + PaxOft))
        {
            PaxOft += (PDis - PSal);

            Logger::Info("HELLA", QString("CONTAPAX: Saliti=%1 Discesi=%2 Correttore=%3").arg(PSal).arg(PDis).arg(PaxOft));

            // DBase->WriteParam("PaxOft", PaxOft);
        }

        Global::PeopleIN  = PSal + PaxOft;

        Global::PeopleOUT = PDis;

        int Tot = (Global::PeopleIN - Global::PeopleOUT);

        if (Tot != oTot)
        {
            Global::ABordo += (Tot - oTot);
            Logger::Info("HELLANEW", QString("  RUN in: %1 out: %2, abordo:%3").arg(Global::PeopleIN).arg(Global::PeopleOUT).arg(Global::ABordo));
            oTot = Tot;

            if (Global::ABordo < 0)
                Global::ABordo = 0;
        }

        if (Global::PeopleIN != oPSal || Global::PeopleOUT != oPDis)
        {
            oPSal = Global::PeopleIN;
            oPDis = Global::PeopleOUT;

            emit PeopleCountChange(oPSal, oPDis, Global::ABordo);
        }

        if (oStatoPorte != StatoPorte)
        {
            if (StatoPorte == eDoorStatus::Opened)
            {
                Logger::Info("HELLA", "Apertura porte");

                OpenDoorTime = Global::CurrentTime();
            }
            else if (StatoPorte == eDoorStatus::Closed)
            {
                Logger::Info("HELLA", "Chiusura porte");

                if (OpenDoorTime != QDateTime::fromMSecsSinceEpoch(0) )
                    Global::TempoAperturaPorte = Global::CurrentTime().toMSecsSinceEpoch() - OpenDoorTime.toMSecsSinceEpoch();

                Flip = 4;
            }

            oStatoPorte = StatoPorte;

            emit DoorStatusChanged((int)StatoPorte);
        }

        QThread::msleep(10);
    }

    Logger::Info("HELLA", "EXIT Thread Hella");
}

/*****************************************************************/
void clsHellaNew::SendMessageBroadcast(QString Command)
/*****************************************************************/
{
     QByteArray Data = Command.toLocal8Bit();

     for (int j=0; j < Lista->count(); j++)
     {
         HellaInfo *Hella = Lista->values().at(j);

         Hella->LastTx = Global::CurrentTime();
     }

     Socket->writeDatagram(Data, QHostAddress::Broadcast, HellaPort);

     //qDebug() << "HELLA: Send broadcast message " << Command << " " << QDateTime::currentMSecsSinceEpoch();
}

/**************************************/
void clsHellaNew::qSleep(int ms)
/**************************************/
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000 * 1000 };
    nanosleep(&ts, nullptr);
}
