#include "mainwindow.h"

#include <QApplication>

#include <QtPlugin>
#include "qsqldriverplugin.h"

//Q_IMPORT_PLUGIN(QSqlDriverPlugin)

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    w.show();
    return a.exec();
}
