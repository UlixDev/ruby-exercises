// moved to protocols folder
#ifndef CLSBUSINFO_H
#define CLSBUSINFO_H

#include <QString>
#include <QDateTime>
#include <QList>

class clsPalina;

class clsBusInfo
{
public:

    clsBusInfo();

    QString     Targa = "";
    int         NavState;

    QList<clsPalina *> *Paline;
};

class clsPalina
{
public:

    QString StopID;
    QString oStopID;
    QString Name = "";
    QString Desc = "";
    float   Distanza;
    int 	Sequence;
    int     TripPtr;
    bool    Visible = false;
    bool    InFermata = false;

    QDateTime PrevisioneArrivo;
    QDateTime OrarioStatico;

    clsPalina(QString Nome)
    {
        this->Name = Nome;
        this->StopID  = "";
        this->oStopID = "";
        this->TripPtr = 0;
        this->Visible = true;
    }
};


#endif // CLSBUSINFO_H
