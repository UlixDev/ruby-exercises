QT       += core gui sql network testlib serialport qmqtt

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11
CONFIG -= app_bundle
CONFIG += QMQTT_NO_SSL

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    clsGps.cpp \
    clsbusinfo.cpp \
    clsdutyinfo.cpp \
    clsforecast.cpp \
    clsgtfs.cpp \
    clsinfobus.cpp \
    clsnavigator.cpp \
    clspayload.cpp \
    clssimulatore.cpp \
    clstools.cpp \
    clswebservice.cpp \
    dbmanager.cpp \
    frmpannelli.cpp \
    frmselectduty.cpp \
    global.cpp \
    json.cpp \
    logger.cpp \
    main.cpp \
    mainwindow.cpp \
    tcpclient.cpp \
    tcpclientman.cpp \
    tcpserver.cpp \
    Positioning/qgeocoordinate.cpp \
    gpio.cpp \
    togglepin.cpp \
    clsdisplayelmec.cpp \
    clsrepository.cpp \
    clsVTec.cpp \
    clsHellaNew.cpp \
    clsAesys.cpp \
    clsDisplayAesys.cpp \
    clsEurotech.cpp \
    clsNFC.cpp

HEADERS += \
    clsGps.h \
    clsbusinfo.h \
    clsdutyinfo.h \
    clsforecast.h \
    clsgtfs.h \
    clsinfobus.h \
    clsnavigator.h \
    clspayload.h \
    clssimulatore.h \
    clstools.h \
    clswebservice.h \
    dbmanager.h \
    frmpannelli.h \
    frmselectduty.h \
    global.h \
    json.h \
    logger.h \
    mainwindow.h \
    tcpclient.h \
    tcpclientman.h \
    tcpserver.h \
    Positioning/qgeocoordinate.h \
    Positioning/qgeocoordinate_p.h \
    Positioning/qgeolocation.h \
    Positioning/qgeolocation_p.h \
    Positioning/qgeopositioninfo.h \
    Positioning/qgeopositioninfo_p.h \
    gpio.h \
    togglepin.h \
    clsdisplayelmec.h \
    clsrepository.h \
    clsVTec.h \
    clsHellaNew.h \
    clsAesys.h \
    clsDisplayAesys.h \
    clsEurotech.h \
    clsNFC.h

FORMS += \
    clsdutyinfo.ui \
    clsinfobus.ui \
    frmnavigator.ui \
    frmpannelli.ui \
    frmselectduty.ui \
    mainwindow.ui

INCLUDEPATH += ../qmqtt-master/src/mqtt

#target.path = /app
target.path = /home/root/

!isEmpty(target.path): INSTALLS += target

DISTFILES +=

RESOURCES += \
    icone.qrc
