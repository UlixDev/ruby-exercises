#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>

#include "logger.h"
#include "clsGps.h"
#include "tcpclient.h"
#include "clsHellaNew.h"
#include "clssimulatore.h"
#include "clsgtfs.h"
#include "clspayload.h"
#include "tcpserver.h"
#include "clsnavigator.h"
#include "clsbusinfo.h"
#include "togglepin.h"
#include "clsrepository.h"
#include "global.h"
#include "qmqtt.h"
#include "clsVTec.h"
#include "clsAesys.h"
#include "clsDisplayAesys.h"
#include "clsdisplayelmec.h"
#include "clsEurotech.h"
#include "clsNFC.h"

//#include "supervisor.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    int Read_ConfigurazioneAgenzia( int CodiceAgenzia, QString CodicePiastra );

private slots:

    void onBeepSignal();
    void on_cmd_Panel_clicked();
    void Elmec_SendMessage(QString Codice);
    void on_CpxStatusChanged (int Stato);
    void on_PeopleCountChange(int PassIn, int PossOut, int aBordo);
    void on_DoorStatusChanged(int DoorStatus);

    void on_cmd_Navigator_clicked();

    void onLocation(QGeoCoordinate Geo);

    void onTimerRefresh();
    void BuzzerTimerClick();
    void DownloadTimerClick();

    void ResetBrightness(void);

    void on_Download();

    /*******************
     * MQTT
     *******************/
#ifdef ENABLE_MQTT
    void onMqttConnected    (void);
    void onMqttDisconnected (void);
    void onMqttSubscribed   (QString Topic, quint8 qos);
    void onMqttReceived     (QMQTT::Message message);

    int MqttSendMessage(QString Topics, QString Text);
#endif

    /*********
     * SUPER
     *********/
    // void DataReady      ( GpsData Data );
    void CommandReceived( int ClientID, QByteArray Datagram );
    void BroacastMessage( int ClientID, QByteArray Datagram );
    void BroacastMessage( int ClientID, QString    Datagram );

    void on_cmd_Duty_clicked();

    void on_cmd_VTec1_clicked();
    void on_cmd_VTec2_clicked();

signals:

    void SendMessage( int ClientID, QByteArray Data);
    void NewTrip(QString DutyID, QString TripID);
    void NewLoc (QGeoCoordinate Loc);
    void LocReceived (GpsData Loc);

private:

    void SendProcessStatus  ( QString Status );
    void SendLocMessage     (QString Evento , bool Forza);
    int  Panel_ReadConfig   (void);
    int  VTec_ReadConfig    (void);
    void SendDiagnostic     (void);

    int Config_Read ( void );
    int Config_Write( void );

    QString CP_Read (void);
    bool    CP_Write(QString Codice);

    QList<QString> ContaPax_ReadConfig( void );

    DBManager    *DBase;

    TogglePin    *buzzer;
    clsNfc       *Nfc = nullptr;
    clsGps       *Gps = nullptr;
    clsGtfs      *Gtfs;
    clsNavigator *Nav;

    Eurotechs    *Eurotech;
    clsHellaNew  *Hella;
    TcpServer    *TCPServer;
    clsPayload   *ThPay;

    clsAesys     *Aesys;

    QList<clsDisplayElmec *> *DisplayElmec;
    QList<clsDisplayAesys *> *DisplayAesys;

    QList<clsVTec *> *VTecDevice;

    QDateTime       LastTrackSendTime;
    QDateTime       LastDutyCheck;
    QGeoCoordinate  LastPosition;
    QVariantList    ListDev;

    QTimer *SecTimer;
    QTimer *BuzzerTimer;
    QTimer *LumTimer;

    QTimer        *DownloadTimer;
    QtDownload     Repo;

#ifdef ENABLE_MQTT
    QMQTT::Client *MqttClient;
    QDateTime      LastMqttKeepAlive;
#endif

    bool oDoor = false;

    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
