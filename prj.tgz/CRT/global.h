// moved to constants.h
// Moved enum to enumerations.h in constants
#ifndef GLOBAL_H
#define GLOBAL_H

#include <QString>
#include <QList>
#include <QMutex>

#include "Positioning/qgeocoordinate.h"

#define PORTAL_BIGO     "https://portal.bigosolutions.it"
#define APIKEY_BIGO     "492AFDCC-2C94-4121-9CC0-C3202A2822C3"

#define MAX_PALINE      5
#define ENABLE_MQTT
#define ENABLE_UDPGPS
#undef  ENABLE_RFID

// <moved>
enum eDoorStatus
{
    Opened,
    Closed,
    Unknow
};

enum ePanelType
{
    UnaZona = 1,
    DueZone = 2,
    TreZone = 3
};

enum ePanelModel
{
    Anteriore  = 1,
    Laterale   = 2,
    Posteriore = 3,
    Interno    = 4
};

enum eStatus
{
    Init = 2,
    Up   = 1,
    Down = 0
};
// </moved>

class Global
{

public:

    Global();

    static QDateTime CurrentTime(void);
    static int TimeOffset;  // RW mutex
    static bool FL_Utc;     // RW

    static QString      MqttUser;   //RW
    static QString      MqttPsw;    //RW
    static QString      MqttServer; //RW
    static int          MqttPort;   //RW

    static QString PortalBigo;      //CONST
    static QString PortalApiKey;    //CONST

    static QString Versione;        //CONST
    static QString BigoPoint;       //RW
    static QString EndPoint;        //CONST
    static QString ApiKey;          //RW maybe mutex
    static QString Imei;            //RW
    static QString Mezzo;           //RW mutex
    static QString Conducente;      //RW
    static QString StopID;          //RW
    static QString TripID;          //RW mutex
    static QString DutyID;          //RW mutex
    static QString LineaSN;         //CONST
    static QString PanelCode;       //RW mutex
    static QString ElmecStatus;     //RW
    static QString AesysStatus;     //RW
    static QString VTecStatus;      //RW
    static QString Fore_Stop;       //RW maybe mutex

    static int     IDAgenzia;       //RW
    static int     nAgenzia;        //RW
    static QString Agenzia;         //RW
    static QString Rev;             //CONST

    static QString ContaPaxModel;   //RW
    static int     ContaPaxPort;    //RW

    static int     XiboStatus;      //RW mutex
    static QString XiboIP;          //RW

    static QGeoCoordinate Proiezione;   //RW maybe mutex
    static QGeoCoordinate Posizione;    //RW maybe mutex

    static bool  EnableSimulatore;      //CONST
    static bool  FL_FineCorsa;          //RW
    static bool  FL_Change;             //RW
    static bool  Door;                  //CONST
    static bool  Running;               //RW mutex
    static bool  VTecMaster;            //RW
    static bool  EnableVTec1;           //RW mutex
    static bool  EnableVTec2;           //RW mutex
    static bool  SpegniLCD;             //RW

    /*******************
     * DIAGNOSTICA
     *******************/

    static bool  GpsStatus;             //RW
    static bool  NetStatus;             //RW
    static bool  DoorStatus;            //RW maybe not used
    static bool  PanelStatus;           //RW maybe not used

    /********************/

    static float IntornoDeposito;       //CONST
    static float Distanza_Capolinea;    //CONST
    static float Distanza_Palina;       //CONST
    static float DistanzaDaFermata;     //RW
    static float SogliaSpeed;           //CONST
    static int   TempoAperturaPorte;    //RW

    static int   RitardoCorsa;          //RW mutex
    static int   OutOfSyncTime;         //CONST
    static int   Seconds_per_Lost;      //CONST
    static int   Odometro;              //CONST
    static int   PeopleIN;              //RW mutex
    static int   PeopleOUT;             //RW mutex
    static int   ABordo;                //RW mutex
    static int   Fore_Time;             //RW maybe mutex
    static int   Lumin;                 //RW

    static QMutex LK_ClearTurni;

    static QList<QString> *TurniFatti;
};

#endif // GLOBAL_H
