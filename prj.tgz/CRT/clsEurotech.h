// moved Check why there exist TWO distinct classes that change in onloy ONE letter!!!!
#ifndef CLSEUROTECH_H
#define CLSEUROTECH_H

#include <QObject>
#include <QDateTime>
#include <QThread>
#include <QList>

#include "global.h"
#include "dbmanager.h"
#include "tcpclient.h"

class clsEurotech : public QThread
{
    Q_OBJECT

public:

    explicit clsEurotech();
    void     run();

    void     Config (QString IP, int Port, int ID);

    QDateTime LastEuroRes;

    eDoorStatus StatoPorte = eDoorStatus::Unknow;

    eDoorStatus oStatoPorte = eDoorStatus::Unknow;

    eStatus  Status = eStatus::Init;

    eStatus oStatus = eStatus::Init;

    bool    DoReset = false;
    int     ID;
    int     PassIn;
    int     PassOut;
    int     Totale;

private:

    TcpClient    *EuroClient;

    QString   IP;
    int       Port = 10000;

    bool Pending   = false;
    int  ResetDay  = -1;

    QString DeviceType = "CPX";

    bool ReadPortStatus (eDoorStatus *Door);
    bool Read_InOut     (int *PassIn, int *PassOut);
    bool Reset_InOut    ();

public slots:

    void Reset    ();

signals:

};

class Eurotechs : public QThread
{
    Q_OBJECT

public:

    explicit Eurotechs();
    void     run();

    void Config(QList<QString> Pax, int Port);

    QDateTime LastEuroRes;

    eDoorStatus StatoPorte = eDoorStatus::Unknow;

    eDoorStatus oStatoPorte = eDoorStatus::Unknow;

    eStatus  Status = eStatus::Init;

    eStatus oStatus = eStatus::Init;

    bool    DoReset = false;
    int     ID;
    int     PassIn;
    int     PassOut;
    int     Totale;
    int     PaxOft;

    QList<clsEurotech *> ContaPax;

private:

    int  ResetDay  = -1;

    QString DeviceType = "CPX";

public slots:

signals:

    void DoorStatusChanged( int DoorStatus );
    void CpxStatusChanged ( int Status );
    void PeopleCountChange( int PassIn, int PassOut, int ABordo );
};


#endif // CLSEUROTECH_H
