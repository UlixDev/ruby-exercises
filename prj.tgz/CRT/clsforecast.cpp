#include "clsforecast.h"

clsForecast::clsForecast()
{
    Paline = new QList<Info>();
}
