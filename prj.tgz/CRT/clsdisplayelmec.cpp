#include "clsdisplayelmec.h"
#include "json.h"
#include <QtMath>

using QtJson::JsonObject;
using QtJson::JsonArray;

/*********************************************************/
clsDisplayElmec::clsDisplayElmec(QObject *parent) : QThread(parent), Quit(false)
/*********************************************************/
{
    this->Port  = 3200;
    this->IP    = "192.168.1.10";
    this->Brand = 2;

    Status = Init;

    JS = "";
}
/*********************************************************/
clsDisplayElmec::~clsDisplayElmec()
/*********************************************************/
{
    Quit = true;

    wait();
}

/*********************************************************/
void clsDisplayElmec::StopThread()
/*********************************************************/
{
    Quit = true;
}

/*********************************************************/
void clsDisplayElmec::Config(QString IP, int Port, ePanelType Tipo, ePanelModel Model, QString Code, QString ID )
/*********************************************************/
{
    this->IP   = IP;
    this->Port = Port;
    this->TipoPannello = Tipo;
    this->Modello = Model;
    this->DCode = Code;
    this->DID = ID;

    ElmecClient = new TcpClient(this);

    ElmecClient->StartConnection(IP, Port);
}

/*********************************************************/
void clsDisplayElmec::SetPanel(QString Num, QString NumFore, QString NumBack, QString Sup, QString SupFore, QString SupBack, QString Inf, QString InfFore, QString InfBack)
/*********************************************************/
{
    int NFore = ConvertColor(NumFore);
    int NBack = ConvertColor(NumBack);
    int SFore = ConvertColor(SupFore);
    int SBack = ConvertColor(SupBack);
    int IFore = ConvertColor(InfFore);
    int IBack = ConvertColor(InfBack);

    QVariantMap Buf;

    Buf["Num"] = Num;
    Buf["Sup"] = Sup;
    Buf["Inf"] = Inf;

    Buf["NumFore"] = NFore;
    Buf["NumBack"] = NBack;

    Buf["SupFore"] = SFore;
    Buf["SupBack"] = SBack;

    Buf["InfFore"] = IFore;
    Buf["InfBack"] = IBack;

    Buf["Lumin" ] = Global::Lumin;
    Buf["Scroll"] = 0;

    bool Ok = false;

    QtJson::setPrettySerialize(false);

    JS  = QtJson::serialize( Buf, Ok);

    if (!Ok)
        JS = "";

    Refresh = true;
}

/*******************************************/
int clsDisplayElmec::ConvertColor(QString Rgb)
/*******************************************/
{
    int Colore = 0;

    if (Rgb.length() == 4)
    {
        if (Rgb.mid(1, 1) != "0") Colore |= 0x01;
        if (Rgb.mid(2, 1) != "0") Colore |= 0x02;
        if (Rgb.mid(3, 1) != "0") Colore |= 0x04;
    }

    return Colore;
}

/*******************************************/
void clsDisplayElmec::run()
/*******************************************/
{
    qDebug() << "Start thread Elemec IP :" << IP;

    while (!Quit)
    {
        if (JS.length() > 0)
        {
            QDateTime Now = Global::CurrentTime();

            bool OkSend = Refresh;

            if (!OkSend)
            {
                OkSend = (fabs(Now.msecsTo(LastPoll)) >= 60000);
            }

            if ( OkSend )
            {
                if (ElmecClient->GetState() == QAbstractSocket::SocketState::ConnectedState)
                {
                    LastPoll = Now;

                    Refresh = false;

                    qDebug() << "Send message :" << JS;

                    int Ret = ElmecClient->SendMessage( JS + "\r", JS.length() + 1, 10000);

                    Status = ((Ret==2) && (ElmecClient->RxBuffer=="OK")) ? Up : Down;

                    qDebug() << "Send message return " << Ret << "Status = " << Status;
                }
                else
                    Status = Init;
            }
        }

        qSleep(100);
    }
}

/**************************************/
void clsDisplayElmec::qSleep(int ms)
/**************************************/
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000 * 1000 };
    nanosleep(&ts, nullptr);
}
