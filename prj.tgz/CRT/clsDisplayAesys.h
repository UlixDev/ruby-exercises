//moved to AesysManager
#ifndef CLSDISPLAYAESYS_H
#define CLSDISPLAYAESYS_H

#include "logger.h"
#include "dbmanager.h"
#include "global.h"

#define STX 0x02
#define ETX 0x03

class clsDisplayAesys
{
public:

    explicit clsDisplayAesys();

    // Already moved to enumerations.h in the new prj
    enum eMargin
    {
        SX,
        DX,
        CX
    };



    void qSleep      (int ms);
    void SetPanel    (QString Num, QString NumFore, QString NumBack, QString Sup, QString SupFore, QString SupBack, QString Inf, QString InfFore, QString InfBack);
    void Config      (QString Adr, ePanelType nZone, ePanelModel Model, QString Code, QString ID );

    QByteArray  BuildMessage(QString Dest, QString OpCode, QString Num, QString Sup, QString Inf, QString FC1, QString FC2, QString FC3);
    QByteArray  CopyTo      (QString Source, QByteArray Buffer, int Ptr);

    QString DID;
    QString DCode;
    int     Modello;
    int     Brand;
    int     nZone;
    int     Status;
    bool    FL_Refresh = false;

    QString Adr;

    QString Num;
    QString Sup;
    QString Inf;

    QString NumFore;
    QString SupFore;
    QString InfFore;

    QString NumBack;
    QString SupBack;
    QString InfBack;

signals:

    void SignalLog  (quint32 Event, QString Msg);

private:

public slots:

private slots:

};

#endif
