// moved to downloadManager
#ifndef CLSREPOSITORY_H
#define CLSREPOSITORY_H

#include <QObject>
#include <QString>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>


class QtDownload : public QObject {
    Q_OBJECT

public:
    explicit QtDownload();
    ~QtDownload();

    void setTarget(const QString& t, const QString &FileName, const QString &md5);
    QString File_ReadMd5(QString FileName);

private:
    QNetworkAccessManager manager;
    QString target;
    QString RemoteMd5;
    QString LocalFile;

signals:
    void done();

public slots:
    void download();
    void downloadFinished(QNetworkReply* data);
    void downloadProgress(qint64 recieved, qint64 total);
};

#endif // CLSREPOSITORY_H
