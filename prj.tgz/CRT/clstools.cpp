#include "clstools.h"

clsTools::clsTools()
{

}

int clsTools::ConvertMTime2Sec( QString MTime )
{
    int Ore = QString(MTime.mid( 0, 2)).toInt();
    int Min = QString(MTime.mid( 3, 2)).toInt();
    int Sec = QString(MTime.mid( 6, 2)).toInt();

    return Ore * 3600 + Min * 60 + Sec;
}

