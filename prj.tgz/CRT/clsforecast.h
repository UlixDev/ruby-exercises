// moved to protocols folder
#ifndef CLSFORECAST_H
#define CLSFORECAST_H

#include <QString>
#include <QDateTime>
#include <QList>

class Info;

class clsForecast
{
public:

    clsForecast();

    QDateTime Data;
    QString   Linea;
    QString   Mezzo;
    QString   TripID;

    QList<Info> *Paline;

};

class Info
{
public:

    QString   StopID;
    QDateTime Forecast;
    QDateTime Orario;

    Info(QString StopID, QDateTime Forecast, QDateTime Orario)
    {
        this->StopID   = StopID;
        this->Forecast = Forecast;
        this->Orario   = Orario;
    }
};

#endif // CLSFORECAST_H
