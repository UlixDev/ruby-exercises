#include "clsdutyinfo.h"
#include "ui_clsdutyinfo.h"

clsDutyInfo::clsDutyInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::clsDutyInfo)
{
    ui->setupUi(this);
}

clsDutyInfo::~clsDutyInfo()
{
    delete ui;
}
